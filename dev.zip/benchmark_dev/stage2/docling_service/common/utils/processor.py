import base64
import os
import tempfile
import uuid
from enum import Enum
from typing import Any, Dict, List, Optional

from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.document_converter import (
    DocumentConverter,
    PdfFormatOption,
)
from docling_core.transforms.chunker.hybrid_chunker import HybridChunker
from utils.logger import get_logger
from utils.text_preprocessing import ChunkProcessor

# Configure logging
logger = get_logger(__name__)

class ApiVersion(str, Enum):
    """API version enumeration."""
    V1 = "v1"
    
    @classmethod
    def latest(cls) -> str:
        """Get the latest API version."""
        return cls.V1.value

class DocumentProcessor:
    """
    Core document processor for Docling API.
    """
    
    def __init__(self, tokenizer: str = "BAAI/bge-small-en-v1.5", api_version: str = ApiVersion.V1):
        """
        Initialize the DocumentProcessor.
        
        Args:
            tokenizer: The model tokenizer to use for counting tokens
            api_version: API version
        """
        self.tokenizer = tokenizer
        self.api_version = api_version
        self.chunker = HybridChunker(tokenizer=self.tokenizer)
        self.chunk_processor = ChunkProcessor()
        
        # Initialize converters
        self.pdf_converter = self._initialize_pdf_standard_converter()
        self.excel_converter = self._initialize_excel_converter()
        self.pdf_ppt_converter = self._initialize_pdfppt_converter()
        
        logger.info(f"Document processor initialized with API version {api_version}")
    
    def _initialize_pdf_standard_converter(self) -> DocumentConverter:
        """Initialize standard PDF converter."""
        pipeline_options = PdfPipelineOptions(
            do_table_structure=True,
            table_structure_options=dict(
                do_cell_matching=False,
                mode="accurate"
            )
        )
        
        format_options = {
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
        }
        
        return DocumentConverter(
            format_options=format_options
        )
    
    def _initialize_excel_converter(self) -> DocumentConverter:
        """Initialize Excel converter."""
        
        return DocumentConverter()
    
    def _initialize_pdfppt_converter(self) -> DocumentConverter:
        """Initialize PDF converter for PowerPoint slides."""
        pipeline_options = PdfPipelineOptions(
            do_table_structure=True,
            table_structure_options=dict(
                do_cell_matching=False,
                mode="accurate"
            )
        )
        
        # Set image options for slide processing
        image_resolution_scale = float(os.environ.get("IMAGE_RESOLUTION_SCALE", "1.0"))
        pipeline_options.images_scale = image_resolution_scale
        pipeline_options.generate_page_images = True
        
        format_options = {
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
        }
        
        return DocumentConverter(
            format_options=format_options
        )
    
    def _extract_headings(self, document) -> List[str]:
        """
        Extract headings from document.
        
        Args:
            document: Document object
            
        Returns:
            List[str]: List of headings
        """
        headings = []
        if hasattr(document, "headings"):
            headings = document.headings
        return headings
    
    def _extract_sections(self, document) -> List[Dict[str, Any]]:
        """
        Extract sections from document.
        
        Args:
            document: Document object
            
        Returns:
            List[Dict[str, Any]]: List of sections
        """
        sections = []
        if hasattr(document, "sections"):
            for section in document.sections:
                sections.append({
                    "heading": section.heading,
                    "level": section.level,
                    "text": section.text
                })
        return sections
    
    def _extract_chunk_metadata(self, chunk) -> Dict[str, Any]:
        """
        Extract essential metadata from a chunk.
        
        Args:
            chunk: Chunk object
            
        Returns:
            Dict[str, Any]: Chunk metadata
        """
        # Generate a unique ID for the chunk
        chunk_id = str(uuid.uuid4())
        
        metadata = {
            "chunk_id": chunk_id,
            "text": chunk.text,
            "headings": [],
            "page_info": None,
            "content_type": None,
            "token_count": 0
        }
        
        if hasattr(chunk, 'meta'):
            # Extract headings
            if hasattr(chunk.meta, 'headings') and chunk.meta.headings:
                metadata["headings"] = chunk.meta.headings
            
            # Extract page information and content type
            if hasattr(chunk.meta, 'doc_items'):
                for item in chunk.meta.doc_items:
                    if hasattr(item, 'label'):
                        metadata["content_type"] = str(item.label)
                    
                    if hasattr(item, 'prov') and item.prov:
                        for prov in item.prov:
                            if hasattr(prov, 'page_no'):
                                metadata["page_info"] = prov.page_no  

        # Add text_to_embed and count_tokens
        metadata = self.chunk_processor.process_chunk(chunk=metadata)      
        
        return metadata


    def process_document(
        self, 
        document_bytes: bytes, 
        file_type: str,
    ) -> Dict[str, Any]:
        """
        Process a document for text extraction.
        
        Args:
            document_bytes: Document content as bytes
            file_type: File type (pdf, excel, ppt)
            
        Returns:
            Dict[str, Any]: Document content and metadata
        """
        try:
            # Save document bytes to a temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_type}") as temp_file:
                temp_file.write(document_bytes)
                temp_path = temp_file.name
            
            logger.info(f"Processing {file_type} document")
            
            # Select appropriate converter based on file type
            converter = None
            if file_type == "pdf":
                converter = self.pdf_converter   
            elif file_type in ["ppt"]:
                converter = self.pdf_ppt_converter
            elif file_type in ["excel", "xlsx"]:
                converter = self.excel_converter
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            # Convert document
            result = converter.convert(temp_path)
            
            # Extract document content
            pages = None
            title = None
            try:
                pages = result.document.num_pages()
                title = result.document.name
            except:
                pass

            document_content = {
                "text": result.document.export_to_markdown(),
                "metadata": {
                    "pages": pages if pages is not None else 1,
                    "title": title if title is not None else "",
                }
            }            
            # Store the document object for chunking
            document_content["_document_obj"] = result.document
            
            # Clean up temporary file
            os.unlink(temp_path)
            
            return {
                "api_version": self.api_version,
                "document": document_content
            }
        except Exception as e:
            logger.error(f"Error processing document: {e}")
            raise
    
    def chunk_document(
        self, 
        document_content: Dict[str, Any],
        file_type: str
    ) -> Dict[str, Any]:
        """
        Chunk a document into smaller segments.
        
        Args:
            document_content: Document content
            file_type: File type (pdf, excel, ppt)
            
        Returns:
            Dict[str, Any]: Chunks with metadata
        """       
        pages = int(document_content["document"]["metadata"]["pages"])
        document_obj = document_content["document"]["_document_obj"]

        if file_type == "excel":
            try:
                # Extract sheet content
                sheet_names = [gp.name for gp in document_obj.groups]

                if len(sheet_names) != pages:
                    logger.warning("Some sheet may be missing!")

                processed_chunks = []
                for page_no in range(1, pages + 1):
                    chunk_id = str(uuid.uuid4())
                        
                    metadata = {
                        "chunk_id": chunk_id,
                        "text": document_obj.export_to_markdown(page_no=page_no),
                        "headings": [sheet_names[page_no -1]],
                        "page_info": page_no,
                        "content_type": "text",
                        "token_count": 0
                    }
                    processed_chunks.append(metadata)

                return {
                    "api_version": self.api_version,
                    "chunks": processed_chunks
                }
            except Exception as e:
                logger.error(f"Error chunking document: {e}")
                raise
        else:
            try:
                # Extract document object
                doc = document_content.get("document", {}).get("_document_obj")
                
                if not doc:
                    raise ValueError("Document object not found in document content")
                            
                # Create chunks using HybridChunker
                raw_chunks = list(self.chunker.chunk(doc))
                
                logger.info(f"Generated {len(raw_chunks)} chunks")
                
                # Process chunks to extract metadata
                processed_chunks = []
                for chunk in raw_chunks:
                    metadata = self._extract_chunk_metadata(chunk)
                    processed_chunks.append(metadata)
                
                return {
                    "api_version": self.api_version,
                    "chunks": processed_chunks
                }
            except Exception as e:
                logger.error(f"Error chunking document: {e}")
                raise
    
    def process_and_chunk(
        self,
        document_bytes: bytes,
        file_type: str,
        chunk_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Process and chunk a document in one operation.
        
        Args:
            document_bytes: Document content as bytes
            file_type: File type (pdf, excel, ppt)
            max_chunk_size: Maximum chunk size in tokens
            chunk_overlap: Chunk overlap in tokens
            chunk_config: Chunking configuration
            
        Returns:
            Dict[str, Any]: Document content and chunks
        """
        # Process document
        document_result = self.process_document(document_bytes, file_type)
        
        # Chunk document
        chunk_result = self.chunk_document(document_result, file_type)
        
        # Remove document object before returning
        document_content = document_result.get("document", {})
        if "_document_obj" in document_content:
            del document_content["_document_obj"]
        
        # Combine results
        return {
            "api_version": self.api_version,
            "document": document_content,
            "chunks": chunk_result.get("chunks", [])
        }
    
    def extract_images(
        self,
        document_content: Dict[str, Any],
        with_captions: bool = True,
        image_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Extract images from a document.
        
        Args:
            document_content: Document content
            with_captions: Whether to generate captions for images
            image_config: Image extraction configuration
            
        Returns:
            Dict[str, Any]: Extracted images with metadata
        """
        try:
            # Extract document object
            doc = document_content.get("document", {}).get("_document_obj")
            
            if not doc:
                raise ValueError("Document object not found in document content")
            
            # Extract images
            images = []
            
            # Logic to extract images from document
            if hasattr(doc, "images"):
                for i, img in enumerate(doc.images):
                    image_data = {
                        "id": str(uuid.uuid4()),
                        "page": img.page if hasattr(img, "page") else None,
                        "width": img.width if hasattr(img, "width") else None,
                        "height": img.height if hasattr(img, "height") else None,
                        "base64_data": base64.b64encode(img.data).decode("utf-8") if hasattr(img, "data") else None,
                        "caption": img.caption if hasattr(img, "caption") and img.caption else f"Image {i+1}"
                    }
                    
                    images.append(image_data)
            
            return {
                "api_version": self.api_version,
                "images": images
            }
        except Exception as e:
            logger.error(f"Error extracting images: {e}")
            raise

    