#!/bin/bash

# Set the output file
OUTPUT_FILE="project_contents.txt"
# Clear the output file if it exists
> "$OUTPUT_FILE"

# Find all files in the current directory and subdirectories
# Skip .git directory, binary files, and the specified extensions
find . -type f \
    -not -path "*/\.*" \
    -not -path "*/node_modules/*" \
    -not -path "*/venv/*" \
    -not -path "*/__pycache__/*" \
    -not -name "*.toml" \
    -not -name "*.lock" \
    -not -name "*.sh" \
    -not -path "*/deployment/*" \
    -not -path "*/tests/*" \
    -not -path "*/docs/*" \
    | sort \
    | while read -r file_path; do
    
    # Skip binary files using the file command
    if file "$file_path" | grep -q "binary"; then
        echo "Skipping binary file: $file_path"
        continue
    fi
    
    echo "Processing: $file_path"
    
    # Append the file path as a comment and then the content
    echo "# FILE PATH: $file_path" >> "$OUTPUT_FILE"
    echo "" >> "$OUTPUT_FILE"
    
    # Append file content
    cat "$file_path" >> "$OUTPUT_FILE"
    
    # Add separator
    echo -e "\n---------------\n" >> "$OUTPUT_FILE"
done

echo "All file contents have been written to $OUTPUT_FILE"
