import json
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import boto3

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.analyze_status_checker import AnalyzeStatusChecker
from common.utils.dynamodb_utils import get_item, put_item, scan_items, update_item
from common.utils.logger import LogContext, get_logger
from common.utils.s3_utils import upload_json_to_s3

logger = get_logger(__name__)


def parse_sqs_message(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Parse SQS messages from the event.

    Args:
        event: Lambda event

    Returns:
        List[Dict[str, Any]]: List of parsed messages
    """
    messages = []

    for record in event.get("Records", []):
        if record.get("eventSource") != "aws:sqs":
            continue

        body = record.get("body")
        if not body:
            continue

        try:
            message = json.loads(body)
            messages.append(
                {"message": message, "receipt_handle": record.get("receiptHandle")}
            )
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing message body: {e}")

    return messages


def get_all_kpi_responses(analyze_id: str) -> List[Dict[str, Any]]:
    """
    Retrieve all KPI responses for analyze_id from kpi_responses table.

    Args:
        analyze_id: Analyze identifier

    Returns:
        List[Dict[str, Any]]: List of KPI responses
    """
    try:
        kpi_responses = scan_items(
            EnvVars.KPI_RESPONSES_TABLE,
            filter_expression="analyze_id = :analyze_id",
            expression_attribute_values={":analyze_id": analyze_id},
        )

        logger.info(
            f"Retrieved {len(kpi_responses)} KPI responses for analyze {analyze_id}"
        )
        return kpi_responses

    except Exception as e:
        logger.error(f"Error retrieving KPI responses: {e}")
        return []


def merge_kpi_extractions(
    kpi_responses: List[Dict[str, Any]],
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Merge KPI extractions from multiple files, organizing by KPI name.

    Args:
        kpi_responses: List of KPI response records

    Returns:
        Dict[str, List[Dict[str, Any]]]: KPIs organized by name with all extractions
    """
    try:
        merged_kpis = {}

        for response_record in kpi_responses:
            file_id = response_record.get("file_id", "")
            parsed_response = response_record.get("parsed_response", {})
            extractions = parsed_response.get("kpi_extractions", [])

            for extraction in extractions:
                kpi_name = extraction.get("kpi_name", "")
                if not kpi_name:
                    continue

                # Add file context to extraction
                extraction_with_context = extraction.copy()
                extraction_with_context["source_file_id"] = file_id
                extraction_with_context["extraction_timestamp"] = response_record.get(
                    "created_at", ""
                )

                if kpi_name not in merged_kpis:
                    merged_kpis[kpi_name] = []

                merged_kpis[kpi_name].append(extraction_with_context)

        # Sort extractions by confidence score (highest first)
        for kpi_name in merged_kpis:
            merged_kpis[kpi_name].sort(
                key=lambda x: x.get("confidence_score", 0), reverse=True
            )

        logger.info(f"Merged extractions for {len(merged_kpis)} unique KPIs")
        return merged_kpis

    except Exception as e:
        logger.error(f"Error merging KPI extractions: {e}")
        return {}


def resolve_duplicate_kpis(
    merged_kpis: Dict[str, List[Dict[str, Any]]],
) -> Dict[str, Dict[str, Any]]:
    """
    Resolve duplicate KPIs using confidence scores and cross-file validation.

    Args:
        merged_kpis: KPIs organized by name with all extractions

    Returns:
        Dict[str, Dict[str, Any]]: Final resolved KPIs with metadata
    """
    try:
        resolved_kpis = {}

        for kpi_name, extractions in merged_kpis.items():
            if not extractions:
                continue

            # Primary extraction (highest confidence)
            primary_extraction = extractions[0]

            # Calculate consensus and validation metrics
            all_values = [ext.get("value") for ext in extractions if ext.get("value")]
            confidence_scores = [ext.get("confidence_score", 0) for ext in extractions]

            # Check for value consistency across files
            unique_values = list(set(str(val) for val in all_values))
            value_consistency = len(unique_values) == 1 if unique_values else False

            # Calculate aggregate confidence
            avg_confidence = (
                sum(confidence_scores) / len(confidence_scores)
                if confidence_scores
                else 0
            )
            max_confidence = max(confidence_scores) if confidence_scores else 0

            # Determine final confidence based on consistency and individual scores
            if value_consistency and len(extractions) > 1:
                # Boost confidence if multiple files agree
                final_confidence = min(1.0, max_confidence * 1.1)
            elif len(extractions) > 1 and not value_consistency:
                # Reduce confidence if files disagree
                final_confidence = max_confidence * 0.8
            else:
                # Single extraction
                final_confidence = max_confidence

            # Create resolved KPI
            resolved_kpi = {
                "kpi_name": kpi_name,
                "primary_value": primary_extraction.get("value"),
                "unit": primary_extraction.get("unit", ""),
                "period": primary_extraction.get("period", ""),
                "confidence_score": final_confidence,
                "source_text": primary_extraction.get("source_text", ""),
                "detail_level": primary_extraction.get("detail_level", ""),
                "metadata": primary_extraction.get("metadata", {}),
                "validation_info": {
                    "total_extractions": len(extractions),
                    "value_consistency": value_consistency,
                    "all_values": all_values,
                    "average_confidence": avg_confidence,
                    "source_files": [ext.get("source_file_id") for ext in extractions],
                    "cross_file_agreement": value_consistency and len(extractions) > 1,
                },
                "alternative_extractions": (
                    extractions[1:] if len(extractions) > 1 else []
                ),
            }

            resolved_kpis[kpi_name] = resolved_kpi

        logger.info(f"Resolved {len(resolved_kpis)} KPIs with duplicate handling")
        return resolved_kpis

    except Exception as e:
        logger.error(f"Error resolving duplicate KPIs: {e}")
        return {}


def organize_results_by_file_category(
    resolved_kpis: Dict[str, Dict[str, Any]],
    kpi_responses: List[Dict[str, Any]],
    analyze_params: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Organize results by file_category as per API schema.

    Args:
        resolved_kpis: Final resolved KPIs
        kpi_responses: Original KPI response records
        analyze_params: Analyze parameters

    Returns:
        Dict[str, Any]: Results organized by file category
    """
    try:
        # Map file IDs to categories
        file_id_to_category = {}
        for response in kpi_responses:
            file_id = response.get("file_id", "")
            # Get file record to determine category
            file_record = get_item(
                EnvVars.KPI_FILE_STATUS_TABLE,
                {
                    "file_id": file_id,
                    "analyze_id": analyze_params.get("analyze_id", ""),
                },
            )
            file_category = (
                file_record.get("file_category", "uncategorized")
                if file_record
                else "uncategorized"
            )
            file_id_to_category[file_id] = file_category

        # Organize KPIs by file category
        results_by_category = {}

        for kpi_name, kpi_data in resolved_kpis.items():
            source_files = kpi_data.get("validation_info", {}).get("source_files", [])

            # Determine primary category (category of highest confidence source)
            primary_file = source_files[0] if source_files else ""
            primary_category = file_id_to_category.get(primary_file, "uncategorized")

            if primary_category not in results_by_category:
                results_by_category[primary_category] = {
                    "category": primary_category,
                    "kpis": {},
                    "file_ids": set(),
                    "statistics": {
                        "total_kpis": 0,
                        "high_confidence_kpis": 0,
                        "cross_validated_kpis": 0,
                    },
                }

            # Add KPI to category
            results_by_category[primary_category]["kpis"][kpi_name] = kpi_data
            results_by_category[primary_category]["file_ids"].update(source_files)

            # Update statistics
            stats = results_by_category[primary_category]["statistics"]
            stats["total_kpis"] += 1
            if kpi_data.get("confidence_score", 0) >= 0.8:
                stats["high_confidence_kpis"] += 1
            if kpi_data.get("validation_info", {}).get("cross_file_agreement", False):
                stats["cross_validated_kpis"] += 1

        # Convert file_ids sets to lists for JSON serialization
        for category_data in results_by_category.values():
            category_data["file_ids"] = list(category_data["file_ids"])

        logger.info(
            f"Organized results into {len(results_by_category)} file categories"
        )
        return results_by_category

    except Exception as e:
        logger.error(f"Error organizing results by file category: {e}")
        return {}


def calculate_processing_statistics(
    analyze_params: Dict[str, Any],
    resolved_kpis: Dict[str, Dict[str, Any]],
    kpi_responses: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Calculate processing statistics and metrics.

    Args:
        analyze_params: Analyze parameters
        resolved_kpis: Final resolved KPIs
        kpi_responses: KPI response records

    Returns:
        Dict[str, Any]: Processing statistics
    """
    try:
        requested_kpis = analyze_params.get("kpi_list", [])
        total_files = analyze_params.get("total_files", 0)

        # Basic statistics
        stats = {
            "processing_summary": {
                "total_kpis_requested": len(requested_kpis),
                "total_kpis_found": len(resolved_kpis),
                "total_files_processed": len(kpi_responses),
                "total_files_expected": total_files,
                "coverage_percentage": (
                    (len(resolved_kpis) / len(requested_kpis) * 100)
                    if requested_kpis
                    else 0
                ),
            },
            "confidence_metrics": {
                "average_confidence": 0,
                "high_confidence_count": 0,
                "medium_confidence_count": 0,
                "low_confidence_count": 0,
            },
            "validation_metrics": {
                "cross_validated_kpis": 0,
                "single_source_kpis": 0,
                "conflicting_values_count": 0,
            },
            "file_processing_details": [],
        }

        # Calculate confidence metrics
        confidence_scores = [
            kpi.get("confidence_score", 0) for kpi in resolved_kpis.values()
        ]
        if confidence_scores:
            stats["confidence_metrics"]["average_confidence"] = sum(
                confidence_scores
            ) / len(confidence_scores)

            for score in confidence_scores:
                if score >= 0.8:
                    stats["confidence_metrics"]["high_confidence_count"] += 1
                elif score >= 0.5:
                    stats["confidence_metrics"]["medium_confidence_count"] += 1
                else:
                    stats["confidence_metrics"]["low_confidence_count"] += 1

        # Calculate validation metrics
        for kpi_data in resolved_kpis.values():
            validation_info = kpi_data.get("validation_info", {})
            if validation_info.get("cross_file_agreement", False):
                stats["validation_metrics"]["cross_validated_kpis"] += 1
            elif validation_info.get("total_extractions", 0) == 1:
                stats["validation_metrics"]["single_source_kpis"] += 1

            if not validation_info.get("value_consistency", True):
                stats["validation_metrics"]["conflicting_values_count"] += 1

        # File processing details
        for response in kpi_responses:
            file_id = response.get("file_id", "")
            parsed_response = response.get("parsed_response", {})
            processing_metadata = parsed_response.get("processing_metadata", {})

            file_detail = {
                "file_id": file_id,
                "kpis_extracted": processing_metadata.get("kpis_found", 0),
                "average_confidence": processing_metadata.get("confidence_average", 0),
                "processing_timestamp": response.get("created_at", ""),
                "validation_errors": len(response.get("validation_errors", [])),
            }
            stats["file_processing_details"].append(file_detail)

        # Missing KPIs
        found_kpi_names = set(resolved_kpis.keys())
        requested_kpi_names = set(requested_kpis)
        missing_kpis = list(requested_kpi_names - found_kpi_names)
        stats["missing_kpis"] = missing_kpis

        logger.info(
            f"Calculated processing statistics: {stats['processing_summary']['coverage_percentage']:.1f}% coverage"
        )
        return stats

    except Exception as e:
        logger.error(f"Error calculating processing statistics: {e}")
        return {}


def format_final_output_according_to_api_spec(
    analyze_params: Dict[str, Any],
    results_by_category: Dict[str, Any],
    processing_stats: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Format final output according to API specification.

    Args:
        analyze_params: Analyze parameters
        results_by_category: Results organized by file category
        processing_stats: Processing statistics

    Returns:
        Dict[str, Any]: Final output according to API spec
    """
    try:
        final_output = {
            "analyze_id": analyze_params.get("analyze_id", ""),
            "bank_id": analyze_params.get("bank_id", ""),
            "processing_timestamp": datetime.now(timezone.utc).isoformat(),
            "status": "complete",
            "request_parameters": {
                "kpi_list": analyze_params.get("kpi_list", []),
                "detail_level": analyze_params.get("detail_level", ""),
                "bank_is_french": analyze_params.get("bank_is_french", False),
                "total_files": analyze_params.get("total_files", 0),
                "file_categories": analyze_params.get("file_categories", []),
            },
            "results": {
                "by_category": results_by_category,
                "summary": {
                    "total_kpis_extracted": len(
                        [
                            kpi
                            for category in results_by_category.values()
                            for kpi in category.get("kpis", {}).keys()
                        ]
                    ),
                    "categories_processed": list(results_by_category.keys()),
                    "highest_confidence_kpis": [],
                    "cross_validated_kpis": [],
                },
            },
            "processing_statistics": processing_stats,
            "quality_assessment": {
                "overall_confidence": processing_stats.get(
                    "confidence_metrics", {}
                ).get("average_confidence", 0),
                "data_completeness": processing_stats.get("processing_summary", {}).get(
                    "coverage_percentage", 0
                ),
                "cross_validation_rate": 0,
                "quality_score": 0,
            },
        }

        # Extract highest confidence KPIs
        all_kpis = []
        for category_data in results_by_category.values():
            for kpi_name, kpi_data in category_data.get("kpis", {}).items():
                all_kpis.append(
                    {
                        "kpi_name": kpi_name,
                        "confidence": kpi_data.get("confidence_score", 0),
                        "category": category_data.get("category", ""),
                    }
                )

        # Sort by confidence and take top 5
        all_kpis.sort(key=lambda x: x["confidence"], reverse=True)
        final_output["results"]["summary"]["highest_confidence_kpis"] = all_kpis[:5]

        # Extract cross-validated KPIs
        cross_validated = []
        for category_data in results_by_category.values():
            for kpi_name, kpi_data in category_data.get("kpis", {}).items():
                if kpi_data.get("validation_info", {}).get(
                    "cross_file_agreement", False
                ):
                    cross_validated.append(
                        {
                            "kpi_name": kpi_name,
                            "sources": len(
                                kpi_data.get("validation_info", {}).get(
                                    "source_files", []
                                )
                            ),
                            "category": category_data.get("category", ""),
                        }
                    )

        final_output["results"]["summary"]["cross_validated_kpis"] = cross_validated

        # Calculate quality assessment
        quality = final_output["quality_assessment"]
        total_kpis = len(all_kpis)
        if total_kpis > 0:
            quality["cross_validation_rate"] = len(cross_validated) / total_kpis * 100

            # Overall quality score (0-100)
            confidence_factor = quality["overall_confidence"] * 40  # 40% weight
            completeness_factor = quality["data_completeness"] * 0.4  # 40% weight
            validation_factor = quality["cross_validation_rate"] * 0.2  # 20% weight
            quality["quality_score"] = (
                confidence_factor + completeness_factor + validation_factor
            )

        logger.info(
            f"Formatted final output with quality score: {quality['quality_score']:.1f}"
        )
        return final_output

    except Exception as e:
        logger.error(f"Error formatting final output: {e}")
        return {}


def store_output_in_s3(
    analyze_id: str, bank_id: str, final_output: Dict[str, Any]
) -> Optional[str]:
    """
    Store complete JSON result in S3 document bucket at results path.

    Args:
        analyze_id: Analyze identifier
        bank_id: Bank identifier
        final_output: Complete final output

    Returns:
        Optional[str]: S3 path or None if failed
    """
    try:
        # Construct S3 path
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        s3_key = f"results/{bank_id}/{analyze_id}/final_output_{timestamp}.json"

        success = upload_json_to_s3(
            EnvVars.DOCUMENTS_BUCKET,
            s3_key,
            final_output,
            metadata={
                "analyze_id": analyze_id,
                "bank_id": bank_id,
                "output_type": "final_kpi_extraction",
                "timestamp": timestamp,
            },
        )

        if success:
            s3_path = f"s3://{EnvVars.DOCUMENTS_BUCKET}/{s3_key}"
            logger.info(f"Stored final output at: {s3_path}")
            return s3_path
        else:
            logger.error(f"Failed to store final output in S3")
            return None

    except Exception as e:
        logger.error(f"Error storing output in S3: {e}")
        return None


def store_output_metadata(
    analyze_id: str, output_path: str, final_output: Dict[str, Any]
) -> bool:
    """
    Store output metadata in kpi_final_output table.

    Args:
        analyze_id: Analyze identifier
        output_path: S3 path to the stored output
        final_output: Complete final output

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        quality_assessment = final_output.get("quality_assessment", {})
        processing_stats = final_output.get("processing_statistics", {})

        metadata_record = {
            "analyze_id": analyze_id,
            "output_path": output_path,
            "completion_timestamp": datetime.now(timezone.utc).isoformat(),
            "status": "complete",
            "quality_metrics": {
                "overall_confidence": quality_assessment.get("overall_confidence", 0),
                "data_completeness": quality_assessment.get("data_completeness", 0),
                "quality_score": quality_assessment.get("quality_score", 0),
                "cross_validation_rate": quality_assessment.get(
                    "cross_validation_rate", 0
                ),
            },
            "processing_summary": processing_stats.get("processing_summary", {}),
            "output_size_bytes": len(json.dumps(final_output)),
            "categories_processed": final_output.get("results", {})
            .get("summary", {})
            .get("categories_processed", []),
        }

        success = put_item(EnvVars.KPI_FINAL_OUTPUT_TABLE, metadata_record)

        if success:
            logger.info(f"Stored output metadata for analyze {analyze_id}")
        else:
            logger.error(f"Failed to store output metadata for analyze {analyze_id}")

        return success

    except Exception as e:
        logger.error(f"Error storing output metadata: {e}")
        return False


def mark_analyze_as_complete(analyze_id: str) -> bool:
    """
    Mark analyze status as "complete".

    Args:
        analyze_id: Analyze identifier

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        update_expression = """
        SET #status = :status,
            completion_timestamp = :timestamp,
            updated_at = :updated_at
        """

        expression_values = {
            ":status": "complete",
            ":timestamp": datetime.now(timezone.utc).isoformat(),
            ":updated_at": datetime.now(timezone.utc).isoformat(),
        }

        expression_names = {"#status": "status"}

        success = update_item(
            EnvVars.KPI_ANALYZE_STATUS_TABLE,
            {"analyze_id": analyze_id},
            update_expression,
            expression_values,
            expression_names,
        )

        if success:
            logger.info(f"Marked analyze {analyze_id} as complete")
        else:
            logger.error(f"Failed to mark analyze {analyze_id} as complete")

        return success

    except Exception as e:
        logger.error(f"Error marking analyze as complete: {e}")
        return False


def process_message(message_data: Dict[str, Any]) -> bool:
    """
    Process a message from the queue.

    Args:
        message_data: Message data

    Returns:
        bool: True if successful, False otherwise
    """
    message = message_data["message"]
    analyze_id = message.get("analyze_id")

    if not analyze_id:
        logger.error(f"Missing analyze_id in message: {message}")
        return False

    with LogContext(
        logger, f"Processing final output generation for analyze {analyze_id}"
    ):
        try:
            # Critical Check: Query analyze_id status → If "failed", skip processing and stop
            can_continue, analyze_record = AnalyzeStatusChecker.check_analyze_status(
                analyze_id
            )
            if not can_continue:
                logger.info(
                    f"Skipping output generation for failed analyze: {analyze_id}"
                )
                return True

            # Retrieve all KPI responses for analyze_id from kpi_responses table
            kpi_responses = get_all_kpi_responses(analyze_id)
            if not kpi_responses:
                logger.error(f"No KPI responses found for analyze {analyze_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "No KPI responses found", "output_generation"
                )
                return False

            # Retrieve original parameters and metadata from kpi_analyze_status table
            analyze_params = AnalyzeStatusChecker.get_analyze_parameters(analyze_id)
            if not analyze_params:
                logger.error(f"Failed to get analyze parameters for {analyze_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to get analyze parameters", "output_generation"
                )
                return False

            # Process and combine results
            logger.info("Merging KPI extractions from multiple files...")
            merged_kpis = merge_kpi_extractions(kpi_responses)

            if not merged_kpis:
                logger.error(f"No valid KPI extractions found for analyze {analyze_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "No valid KPI extractions found", "output_generation"
                )
                return False

            logger.info("Resolving duplicate KPIs using confidence scores...")
            resolved_kpis = resolve_duplicate_kpis(merged_kpis)

            logger.info("Organizing results by file_category...")
            results_by_category = organize_results_by_file_category(
                resolved_kpis, kpi_responses, analyze_params
            )

            logger.info("Calculating processing statistics and metrics...")
            processing_stats = calculate_processing_statistics(
                analyze_params, resolved_kpis, kpi_responses
            )

            # Format final output according to API specification
            logger.info("Formatting final output according to API specification...")
            final_output = format_final_output_according_to_api_spec(
                analyze_params, results_by_category, processing_stats
            )

            if not final_output:
                logger.error(f"Failed to format final output for analyze {analyze_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to format final output", "output_generation"
                )
                return False

            # Store complete JSON result in S3 document bucket at results path
            bank_id = analyze_params.get("bank_id", "")
            output_path = store_output_in_s3(analyze_id, bank_id, final_output)

            if not output_path:
                logger.error(f"Failed to store output in S3 for analyze {analyze_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to store output in S3", "output_generation"
                )
                return False

            # Store output metadata in kpi_final_output table
            if not store_output_metadata(analyze_id, output_path, final_output):
                logger.error(
                    f"Failed to store output metadata for analyze {analyze_id}"
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to store output metadata", "output_generation"
                )
                return False

            # Mark analyze status as "complete"
            if not mark_analyze_as_complete(analyze_id):
                logger.error(f"Failed to mark analyze {analyze_id} as complete")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to mark as complete", "output_generation"
                )
                return False

            quality_score = final_output.get("quality_assessment", {}).get(
                "quality_score", 0
            )
            total_kpis = len(resolved_kpis)

            logger.info(
                f"Successfully completed output generation for analyze {analyze_id}"
            )
            logger.info(
                f"Quality metrics: {total_kpis} KPIs extracted, quality score: {quality_score:.1f}"
            )

            return True

        except Exception as e:
            logger.error(f"Error processing output generation: {e}")
            logger.error(f"Stack trace: {traceback.format_exc()}")
            AnalyzeStatusChecker.mark_analyze_as_failed(
                analyze_id, f"Output generation error: {str(e)}", "output_generation"
            )
            return False


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for final output generation.

    Args:
        event: Lambda event
        context: Lambda context

    Returns:
        Dict[str, Any]: Response
    """
    logger.info(f"🚀 Starting Stage 6: Final Output Generation")
    logger.info(f"📥 Received event: {json.dumps(event)}")

    # Parse SQS messages
    messages = parse_sqs_message(event)
    if not messages:
        logger.warning("⚠️  No valid messages found")
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "No valid messages found"}),
        }

    logger.info(f"📋 Processing {len(messages)} messages")

    # Process each message
    results = []
    for i, message_data in enumerate(messages):
        logger.info(f"🔄 Processing message {i+1}/{len(messages)}")

        success = process_message(message_data)
        analyze_id = message_data["message"].get("analyze_id", "unknown")

        result = {
            "analyze_id": analyze_id,
            "success": success,
        }

        if success:
            logger.info(
                f"✅ Message {i+1} processed successfully: analyze {analyze_id}"
            )
        else:
            logger.error(f"❌ Message {i+1} failed: analyze {analyze_id}")

        results.append(result)

    # Summary
    success_count = sum(1 for r in results if r["success"])
    failure_count = len(results) - success_count

    logger.info(f"📊 SUMMARY: {success_count} successful, {failure_count} failed")

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "message": "Stage 6 final output generation completed",
                "results": results,
                "summary": {
                    "total_processed": len(results),
                    "successful": success_count,
                    "failed": failure_count,
                },
            }
        ),
    }
