# FILE PATH: ./common/utils/prompt_store_manager.py

import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.dynamodb_utils import get_item, put_item, query_items, scan_items
from common.utils.logger import get_logger

logger = get_logger(__name__)


class PromptStoreManager:
    """
    Centralized manager for prompt templates stored in DynamoDB.
    Handles template retrieval, caching, and selection logic.
    """

    def __init__(self):
        self.table_name = EnvVars.PROMPT_STORE_TABLE
        self._cache = {}
        self._cache_ttl = 300  # 5 minutes cache TTL

    def get_prompt_template(
        self,
        bank_id: str,
        document_category: str,
        template_type: str = "kpi_extraction",
        language: str = "en",
    ) -> Optional[str]:
        """
        Get the best matching prompt template using hierarchical lookup.

        Args:
            bank_id: Bank identifier
            document_category: Document category or template type
            template_type: Type of template needed (default: kpi_extraction)
            language: Language preference (default: en)

        Returns:
            Optional[str]: Best matching prompt template or None if not found
        """
        try:
            # Try hierarchical lookup with caching
            template = self._get_cached_template(
                bank_id, document_category, template_type, language
            )
            if template:
                return template

            # 1. Try bank-specific + category + language specific
            template = self._fetch_template(
                bank_id, f"{document_category}_{language}", template_type
            )
            if template:
                self._cache_template(
                    bank_id, document_category, template_type, language, template
                )
                return template

            # 2. Try bank-specific + category (any language)
            template = self._fetch_template(bank_id, document_category, template_type)
            if template:
                self._cache_template(
                    bank_id, document_category, template_type, language, template
                )
                return template

            # 3. Try bank-specific default for template type
            template = self._fetch_template(
                bank_id, f"{template_type}_default", template_type
            )
            if template:
                self._cache_template(
                    bank_id, document_category, template_type, language, template
                )
                return template

            # 4. Try global category + language specific
            template = self._fetch_template(
                "default", f"{document_category}_{language}", template_type
            )
            if template:
                self._cache_template(
                    bank_id, document_category, template_type, language, template
                )
                return template

            # 5. Try global category (any language)
            template = self._fetch_template("default", document_category, template_type)
            if template:
                self._cache_template(
                    bank_id, document_category, template_type, language, template
                )
                return template

            # 6. Try global default for template type + language
            template = self._fetch_template(
                "default", f"{template_type}_{language}", template_type
            )
            if template:
                self._cache_template(
                    bank_id, document_category, template_type, language, template
                )
                return template

            # 7. Try global default for template type
            template = self._fetch_template(
                "default", f"{template_type}_default", template_type
            )
            if template:
                self._cache_template(
                    bank_id, document_category, template_type, language, template
                )
                return template

            logger.warning(
                f"No prompt template found for {bank_id}/{document_category}/{template_type}"
            )
            return None

        except Exception as e:
            logger.error(f"Error retrieving prompt template: {e}")
            return None

    def _fetch_template(
        self, bank_id: str, document_category: str, template_type: str
    ) -> Optional[str]:
        """Fetch template from DynamoDB."""
        try:
            record = get_item(
                self.table_name,
                {"bank_id": bank_id, "document_category": document_category},
            )

            if not record or not record.get("is_active", True):
                return None

            # Get the appropriate template field based on type
            template_field = f"{template_type}_template"
            template = record.get(template_field)

            if template:
                logger.debug(
                    f"Found template: {bank_id}/{document_category}/{template_type}"
                )
                return template

            return None

        except Exception as e:
            logger.error(f"Error fetching template from DynamoDB: {e}")
            return None

    def _get_cached_template(
        self, bank_id: str, document_category: str, template_type: str, language: str
    ) -> Optional[str]:
        """Get template from cache if available and not expired."""
        cache_key = f"{bank_id}:{document_category}:{template_type}:{language}"

        if cache_key in self._cache:
            cached_entry = self._cache[cache_key]
            if (
                datetime.now(timezone.utc).timestamp() - cached_entry["timestamp"]
                < self._cache_ttl
            ):
                logger.debug(f"Cache hit for template: {cache_key}")
                return cached_entry["template"]
            else:
                # Remove expired entry
                del self._cache[cache_key]

        return None

    def _cache_template(
        self,
        bank_id: str,
        document_category: str,
        template_type: str,
        language: str,
        template: str,
    ):
        """Cache template for future use."""
        cache_key = f"{bank_id}:{document_category}:{template_type}:{language}"
        self._cache[cache_key] = {
            "template": template,
            "timestamp": datetime.now(timezone.utc).timestamp(),
        }
        logger.debug(f"Cached template: {cache_key}")

    def get_template_with_metadata(
        self,
        bank_id: str,
        document_category: str,
        template_type: str = "kpi_extraction",
    ) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
        """
        Get template along with its metadata and configuration.

        Returns:
            Tuple[Optional[str], Optional[Dict[str, Any]]]: (template, metadata)
        """
        try:
            # Use same hierarchical lookup
            lookup_orders = [
                (bank_id, document_category),
                (bank_id, f"{template_type}_default"),
                ("default", document_category),
                ("default", f"{template_type}_default"),
            ]

            for lookup_bank_id, lookup_category in lookup_orders:
                record = get_item(
                    self.table_name,
                    {"bank_id": lookup_bank_id, "document_category": lookup_category},
                )

                if record and record.get("is_active", True):
                    template_field = f"{template_type}_template"
                    template = record.get(template_field)

                    if template:
                        metadata = {
                            "template_name": record.get("template_name", ""),
                            "version": record.get("version", "1.0"),
                            "language": record.get("language", "en"),
                            "model_specific_config": record.get(
                                "model_specific_config", {}
                            ),
                            "parameters": record.get("parameters", {}),
                            "priority": record.get("priority", 100),
                            "tags": record.get("tags", []),
                            "description": record.get("description", ""),
                        }
                        return template, metadata

            return None, None

        except Exception as e:
            logger.error(f"Error retrieving template with metadata: {e}")
            return None, None

    def list_available_templates(
        self,
        bank_id: Optional[str] = None,
        template_type: Optional[str] = None,
        language: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        List available templates with optional filtering.

        Args:
            bank_id: Filter by bank ID (optional)
            template_type: Filter by template type (optional)
            language: Filter by language (optional)

        Returns:
            List[Dict[str, Any]]: List of available templates with metadata
        """
        try:
            # Build filter conditions
            filter_parts = ["is_active = :is_active"]
            expression_values = {":is_active": True}

            if language:
                filter_parts.append("#lang = :language")
                expression_values[":language"] = language

            if template_type:
                filter_parts.append("contains(template_type, :template_type)")
                expression_values[":template_type"] = template_type

            filter_expression = " AND ".join(filter_parts)
            expression_names = {"#lang": "language"} if language else None

            # Query or scan based on bank_id filter
            if bank_id:
                templates = query_items(
                    self.table_name,
                    "bank_id = :bank_id",
                    {":bank_id": bank_id, **expression_values},
                    filter_expression=filter_expression,
                    expression_attribute_names=expression_names,
                )
            else:
                templates = scan_items(
                    self.table_name,
                    filter_expression=filter_expression,
                    expression_attribute_values=expression_values,
                    expression_attribute_names=expression_names,
                )

            # Sort by priority (lower number = higher priority)
            templates.sort(key=lambda x: x.get("priority", 100))

            return templates

        except Exception as e:
            logger.error(f"Error listing templates: {e}")
            return []

    def create_template(self, template_data: Dict[str, Any]) -> bool:
        """
        Create a new prompt template.

        Args:
            template_data: Template data dictionary

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Add metadata
            template_data.update(
                {
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                    "is_active": template_data.get("is_active", True),
                }
            )

            # Validate required fields
            required_fields = [
                "bank_id",
                "document_category",
                "template_name",
                "template_type",
            ]
            for field in required_fields:
                if field not in template_data:
                    logger.error(f"Missing required field: {field}")
                    return False

            success = put_item(self.table_name, template_data)

            if success:
                logger.info(
                    f"Created template: {template_data['bank_id']}/{template_data['document_category']}"
                )
                # Clear cache for this bank to force refresh
                self._clear_cache_for_bank(template_data["bank_id"])

            return success

        except Exception as e:
            logger.error(f"Error creating template: {e}")
            return False

    def update_template(
        self, bank_id: str, document_category: str, updates: Dict[str, Any]
    ) -> bool:
        """
        Update an existing template.

        Args:
            bank_id: Bank identifier
            document_category: Document category
            updates: Dictionary of fields to update

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Get existing template
            existing = get_item(
                self.table_name,
                {"bank_id": bank_id, "document_category": document_category},
            )

            if not existing:
                logger.error(f"Template not found: {bank_id}/{document_category}")
                return False

            # Merge updates
            existing.update(updates)
            existing["updated_at"] = datetime.now(timezone.utc).isoformat()

            success = put_item(self.table_name, existing)

            if success:
                logger.info(f"Updated template: {bank_id}/{document_category}")
                self._clear_cache_for_bank(bank_id)

            return success

        except Exception as e:
            logger.error(f"Error updating template: {e}")
            return False

    def delete_template(self, bank_id: str, document_category: str) -> bool:
        """
        Soft delete a template by setting is_active to False.

        Args:
            bank_id: Bank identifier
            document_category: Document category

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            return self.update_template(
                bank_id, document_category, {"is_active": False}
            )
        except Exception as e:
            logger.error(f"Error deleting template: {e}")
            return False

    def _clear_cache_for_bank(self, bank_id: str):
        """Clear cache entries for a specific bank."""
        keys_to_remove = [
            key for key in self._cache.keys() if key.startswith(f"{bank_id}:")
        ]
        for key in keys_to_remove:
            del self._cache[key]
        logger.debug(f"Cleared cache for bank: {bank_id}")

    def validate_template_syntax(
        self, template: str, template_type: str
    ) -> Tuple[bool, List[str]]:
        """
        Validate template syntax and structure.

        Args:
            template: Template content
            template_type: Type of template

        Returns:
            Tuple[bool, List[str]]: (is_valid, list_of_errors)
        """
        errors = []

        try:
            # Basic validation
            if not template or not template.strip():
                errors.append("Template content is empty")
                return False, errors

            # Check minimum length
            if len(template.strip()) < 50:
                errors.append("Template content is too short (minimum 50 characters)")

            # Template type specific validation
            if template_type == "kpi_extraction":
                # Check for key sections
                required_sections = ["task", "instructions", "output"]
                for section in required_sections:
                    if section.lower() not in template.lower():
                        errors.append(f"Missing recommended section: {section}")

                # Check for JSON output instruction
                if "json" not in template.lower():
                    errors.append(
                        "KPI extraction templates should include JSON output instructions"
                    )

            # Check for potential issues
            if len(template) > 50000:  # Very long templates
                errors.append(
                    "Template is very long (>50k chars) - may hit token limits"
                )

            return len(errors) == 0, errors

        except Exception as e:
            errors.append(f"Validation error: {str(e)}")
            return False, errors

    def get_template_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about templates in the store.

        Returns:
            Dict[str, Any]: Template statistics
        """
        try:
            all_templates = scan_items(self.table_name)

            stats = {
                "total_templates": len(all_templates),
                "active_templates": len(
                    [t for t in all_templates if t.get("is_active", True)]
                ),
                "templates_by_bank": {},
                "templates_by_type": {},
                "templates_by_language": {},
                "average_template_length": 0,
                "last_updated": None,
            }

            active_templates = [t for t in all_templates if t.get("is_active", True)]

            if not active_templates:
                return stats

            # Analyze active templates
            total_length = 0
            latest_update = None

            for template in active_templates:
                # Bank distribution
                bank_id = template.get("bank_id", "unknown")
                stats["templates_by_bank"][bank_id] = (
                    stats["templates_by_bank"].get(bank_id, 0) + 1
                )

                # Type distribution
                template_type = template.get("template_type", "unknown")
                stats["templates_by_type"][template_type] = (
                    stats["templates_by_type"].get(template_type, 0) + 1
                )

                # Language distribution
                language = template.get("language", "unknown")
                stats["templates_by_language"][language] = (
                    stats["templates_by_language"].get(language, 0) + 1
                )

                # Length calculation
                for field_name in template:
                    if field_name.endswith("_template") and template[field_name]:
                        total_length += len(template[field_name])

                # Latest update
                updated_at = template.get("updated_at")
                if updated_at and (not latest_update or updated_at > latest_update):
                    latest_update = updated_at

            stats["average_template_length"] = (
                total_length // len(active_templates) if active_templates else 0
            )
            stats["last_updated"] = latest_update

            return stats

        except Exception as e:
            logger.error(f"Error getting template statistics: {e}")
            return {"error": str(e)}


# Global instance for easy access
prompt_store = PromptStoreManager()
