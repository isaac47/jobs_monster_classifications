from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AnalyzeStatus(str, Enum):
    """Analysis processing status."""

    PROCESSING = "processing"
    COMPLETE = "complete"
    FAILED = "failed"


class FileStatus(str, Enum):
    """File processing status through the pipeline."""

    UPLOADED = "uploaded"
    DOCLING_PROCESSING = "docling_processing"
    DOCLING_COMPLETE = "docling_complete"
    FAILED = "failed"


class FileCategory(str, Enum):
    """File category types for KPI extraction."""

    QUARTERLY_SERIES = "serie_trimestrielle"
    PRESS_RELEASE = "communique_presse"
    RESULTS_PRESENTATION = "slide_resultat"


class DocumentType(str, Enum):
    """Document file types."""

    PDF = "pdf"
    EXCEL = "excel"


class KPIAnalyzeStatus(BaseModel):
    """Model for KPI analyze status records."""

    analyze_id: str = Field(..., description="Unique analyze identifier")
    bank_id: str = Field(..., description="Bank identifier")
    bank_is_french: bool = Field(..., description="Whether bank reports in French")
    status: AnalyzeStatus = Field(..., description="Overall analyze status")
    kpi_list: List[str] = Field(..., description="List of KPIs to extract")
    taxonomy: Dict[str, Any] = Field(
        default_factory=dict, description="KPI taxonomy and synonyms"
    )
    kpi_detail_levels: Dict[str, List[str]] = Field(
        default_factory=dict, description="KPI detail level hierarchy"
    )
    expected_files: List[str] = Field(..., description="Expected file categories")
    total_files: int = Field(..., description="Total number of expected files")
    files_uploaded: int = Field(default=0, description="Number of files uploaded")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    error_message: Optional[str] = Field(None, description="Error message if failed")
    current_step: str = Field(
        default="file_validation", description="Current processing step"
    )

    class Config:
        use_enum_values = True


class KPIFileStatus(BaseModel):
    """Model for individual file status tracking."""

    file_id: str = Field(..., description="Unique file identifier")
    analyze_id: str = Field(..., description="Parent analyze identifier")
    bank_id: str = Field(..., description="Bank identifier")
    file_name: str = Field(..., description="Original file name")
    file_category: FileCategory = Field(..., description="File category")
    file_type: DocumentType = Field(..., description="File type")
    s3_path: str = Field(..., description="S3 storage path")
    status: FileStatus = Field(..., description="Current processing status")
    file_size: int = Field(..., description="File size in bytes")
    checksum: Optional[str] = Field(None, description="File checksum")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    error_message: Optional[str] = Field(None, description="Error message if failed")

    class Config:
        use_enum_values = True


def create_analyze_record(
    analyze_id: str,
    bank_id: str,
    bank_is_french: bool,
    kpi_list: List[str],
    taxonomy: Dict[str, Any],
    kpi_detail_levels: Dict[str, List[str]],
    expected_files: List[str],
) -> KPIAnalyzeStatus:
    """Create a new analyze status record."""
    return KPIAnalyzeStatus(
        analyze_id=analyze_id,
        bank_id=bank_id,
        bank_is_french=bank_is_french,
        status=AnalyzeStatus.PROCESSING,
        kpi_list=kpi_list,
        taxonomy=taxonomy,
        kpi_detail_levels=kpi_detail_levels,
        expected_files=expected_files,
        total_files=len(expected_files),
    )


def create_file_record(
    file_id: str,
    analyze_id: str,
    bank_id: str,
    file_name: str,
    file_category: str,
    file_type: str,
    s3_path: str,
    file_size: int,
    checksum: Optional[str] = None,
) -> KPIFileStatus:
    """Create a new file status record."""
    return KPIFileStatus(
        file_id=file_id,
        analyze_id=analyze_id,
        bank_id=bank_id,
        file_name=file_name,
        file_category=FileCategory(file_category),
        file_type=DocumentType(file_type),
        s3_path=s3_path,
        status=FileStatus.UPLOADED,
        file_size=file_size,
        checksum=checksum,
    )
