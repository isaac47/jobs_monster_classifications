import json
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


class EnvironmentVariables:
    """
    STANDARDIZED Environment variable configuration for KPI extraction workflow.
    This configuration must be used by ALL stages to ensure consistency.
    """
    STACK_NAME = "benchmark-sb-"

    # S3 configuration
    DOCUMENTS_BUCKET = os.environ.get("DOCUMENTS_BUCKET", f"{STACK_NAME}documents")

    # DynamoDB tables - STANDARDIZED NAMES across all stages
    KPI_ANALYZE_STATUS_TABLE = os.environ.get(
        "KPI_ANALYZE_STATUS_TABLE", f"{STACK_NAME}kpi-analyze-status"
    )
    KPI_FILE_STATUS_TABLE = os.environ.get(
        "KPI_FILE_STATUS_TABLE", f"{STACK_NAME}kpi-file-status"
    )
    KPI_DOCUMENT_CHUNKS_TABLE = os.environ.get(
        "KPI_DOCUMENT_CHUNKS_TABLE", f"{STACK_NAME}kpi-document-chunks"
    )
    KPI_RETRIEVAL_CONTEXT_TABLE = os.environ.get(
        "KPI_RETRIEVAL_CONTEXT_TABLE", f"{STACK_NAME}kpi-retrieval-context"
    )
    KPI_RESPONSES_TABLE = os.environ.get(
        "KPI_RESPONSES_TABLE", f"{STACK_NAME}kpi-responses"
    )
    KPI_FINAL_OUTPUT_TABLE = os.environ.get(
        "KPI_FINAL_OUTPUT_TABLE", f"{STACK_NAME}kpi-final-output"
    )
    PROMPT_STORE_TABLE = os.environ.get(
        "PROMPT_STORE_TABLE", f"{STACK_NAME}kpi-prompt-store"
    )

    # SQS queues - STANDARDIZED NAMES across all stages
    EMBEDDING_QUEUE_NAME = os.environ.get(
        "EMBEDDING_QUEUE_NAME", f"{STACK_NAME}embedding-queue"
    )
    RETRIEVAL_QUEUE_NAME = os.environ.get(
        "RETRIEVAL_QUEUE_NAME", f"{STACK_NAME}retrieval-queue"
    )
    KPI_GENERATION_QUEUE_NAME = os.environ.get(
        "KPI_GENERATION_QUEUE_NAME", f"{STACK_NAME}kpi-generation-queue"
    )
    OUTPUT_GENERATION_QUEUE_NAME = os.environ.get(
        "OUTPUT_GENERATION_QUEUE_NAME", f"{STACK_NAME}output-generation-queue"
    )

    # Bedrock configurations
    BEDROCK_REGION = os.environ.get("BEDROCK_REGION", "us-east-1")

    # Embedding models for different locales - STANDARDIZED
    BEDROCK_EMBEDDING_MODEL_EN = os.environ.get(
        "BEDROCK_EMBEDDING_MODEL_EN", "amazon.titan-embed-text-v1"
    )
    BEDROCK_EMBEDDING_MODEL_FR = os.environ.get(
        "BEDROCK_EMBEDDING_MODEL_FR", "amazon.titan-embed-text-v2"
    )
    BEDROCK_LLM_MODEL = os.environ.get(
        "BEDROCK_LLM_MODEL", "anthropic.claude-3-5-sonnet-20241022-v2:0"
    )

    # Vision model for image processing (Stage 2)
    BEDROCK_VISION_MODEL = os.environ.get(
        "BEDROCK_VISION_MODEL", "anthropic.claude-3-sonnet-20240229-v1:0"
    )

    # Processing configurations - STANDARDIZED
    MAX_EMBEDDING_BATCH_SIZE = int(os.environ.get("MAX_EMBEDDING_BATCH_SIZE", "20"))
    TOP_K_CHUNKS = int(os.environ.get("TOP_K_CHUNKS", "10"))
    PER_KPI_TOP_K = int(os.environ.get("PER_KPI_TOP_K", "5"))

    # Hybrid search weights - STANDARDIZED
    BM25_WEIGHT = float(os.environ.get("BM25_WEIGHT", "0.3"))
    VECTOR_WEIGHT = float(os.environ.get("VECTOR_WEIGHT", "0.7"))
    BM25_FACTOR = float(os.environ.get("BM25_FACTOR", "1.0"))

    # File processing configurations
    MAX_FILE_SIZE_MB = int(os.environ.get("MAX_FILE_SIZE_MB", "100"))
    SUPPORTED_FILE_TYPES = os.environ.get("SUPPORTED_FILE_TYPES", "pdf,xlsx,xls").split(
        ","
    )
    MAX_IMAGES_PER_DOCUMENT = int(os.environ.get("MAX_IMAGES_PER_DOCUMENT", "50"))

    # Retry and timeout configurations
    MAX_RETRIES = int(os.environ.get("MAX_RETRIES", "3"))
    DOCLING_TIMEOUT = int(os.environ.get("DOCLING_TIMEOUT", "600"))
    BEDROCK_TIMEOUT = int(os.environ.get("BEDROCK_TIMEOUT", "300"))

    # Logging
    LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
    AWS_LAMBDA_FUNCTION_NAME = os.environ.get("AWS_LAMBDA_FUNCTION_NAME", "")

    # External service endpoints
    DOCLING_ENDPOINT_URL = os.environ.get("DOCLING_ENDPOINT_URL", "")

    # AWS Configuration
    AWS_REGION = os.environ.get("AWS_REGION", "eu-west-3")
    AWS_ACCOUNT_ID = os.environ.get("AWS_ACCOUNT_ID", "")

    # Runtime Environment
    ENVIRONMENT = os.environ.get(
        "ENVIRONMENT", "development"
    )  # development, staging, production
    STACK_NAME = os.environ.get("STACK_NAME", "benchmark")

    # Security and Encryption
    KMS_KEY_ID = os.environ.get("KMS_KEY_ID", "")
    ENABLE_ENCRYPTION = os.environ.get("ENABLE_ENCRYPTION", "true").lower() == "true"

    # Performance Tuning
    LAMBDA_MEMORY_SIZE = int(os.environ.get("LAMBDA_MEMORY_SIZE", "1024"))
    LAMBDA_TIMEOUT = int(os.environ.get("LAMBDA_TIMEOUT", "900"))

    # Monitoring and Alerting
    ENABLE_CLOUDWATCH_METRICS = (
        os.environ.get("ENABLE_CLOUDWATCH_METRICS", "true").lower() == "true"
    )
    ENABLE_XRAY_TRACING = (
        os.environ.get("ENABLE_XRAY_TRACING", "true").lower() == "true"
    )

    # Cost Optimization
    LAMBDA_RESERVED_CONCURRENCY = int(
        os.environ.get("LAMBDA_RESERVED_CONCURRENCY", "100")
    )

    @classmethod
    def get_embedding_model(cls, bank_is_french: bool = False) -> str:
        """
        Get appropriate embedding model based on bank locale.

        Args:
            bank_is_french: Whether the bank is French

        Returns:
            str: Embedding model ID
        """
        return (
            cls.BEDROCK_EMBEDDING_MODEL_FR
            if bank_is_french
            else cls.BEDROCK_EMBEDDING_MODEL_EN
        )

    @classmethod
    def get_all(cls) -> Dict[str, Any]:
        """Get all environment variables as a dictionary."""
        return {
            # Core Infrastructure
            "DOCUMENTS_BUCKET": cls.DOCUMENTS_BUCKET,
            "AWS_REGION": cls.AWS_REGION,
            "AWS_ACCOUNT_ID": cls.AWS_ACCOUNT_ID,
            "ENVIRONMENT": cls.ENVIRONMENT,
            "STACK_NAME": cls.STACK_NAME,
            # DynamoDB Tables
            "KPI_ANALYZE_STATUS_TABLE": cls.KPI_ANALYZE_STATUS_TABLE,
            "KPI_FILE_STATUS_TABLE": cls.KPI_FILE_STATUS_TABLE,
            "KPI_DOCUMENT_CHUNKS_TABLE": cls.KPI_DOCUMENT_CHUNKS_TABLE,
            "KPI_RETRIEVAL_CONTEXT_TABLE": cls.KPI_RETRIEVAL_CONTEXT_TABLE,
            "KPI_RESPONSES_TABLE": cls.KPI_RESPONSES_TABLE,
            "KPI_FINAL_OUTPUT_TABLE": cls.KPI_FINAL_OUTPUT_TABLE,
            "PROMPT_STORE_TABLE": cls.PROMPT_STORE_TABLE,
            # SQS Queues
            "EMBEDDING_QUEUE_NAME": cls.EMBEDDING_QUEUE_NAME,
            "RETRIEVAL_QUEUE_NAME": cls.RETRIEVAL_QUEUE_NAME,
            "KPI_GENERATION_QUEUE_NAME": cls.KPI_GENERATION_QUEUE_NAME,
            "OUTPUT_GENERATION_QUEUE_NAME": cls.OUTPUT_GENERATION_QUEUE_NAME,
            # Bedrock Models
            "BEDROCK_REGION": cls.BEDROCK_REGION,
            "BEDROCK_EMBEDDING_MODEL_EN": cls.BEDROCK_EMBEDDING_MODEL_EN,
            "BEDROCK_EMBEDDING_MODEL_FR": cls.BEDROCK_EMBEDDING_MODEL_FR,
            "BEDROCK_LLM_MODEL": cls.BEDROCK_LLM_MODEL,
            "BEDROCK_VISION_MODEL": cls.BEDROCK_VISION_MODEL,
            # Processing Configuration
            "MAX_EMBEDDING_BATCH_SIZE": cls.MAX_EMBEDDING_BATCH_SIZE,
            "TOP_K_CHUNKS": cls.TOP_K_CHUNKS,
            "PER_KPI_TOP_K": cls.PER_KPI_TOP_K,
            "BM25_WEIGHT": cls.BM25_WEIGHT,
            "VECTOR_WEIGHT": cls.VECTOR_WEIGHT,
            "BM25_FACTOR": cls.BM25_FACTOR,
            "MAX_FILE_SIZE_MB": cls.MAX_FILE_SIZE_MB,
            "SUPPORTED_FILE_TYPES": ",".join(cls.SUPPORTED_FILE_TYPES),
            "MAX_IMAGES_PER_DOCUMENT": cls.MAX_IMAGES_PER_DOCUMENT,
            # Timeouts and Retries
            "MAX_RETRIES": cls.MAX_RETRIES,
            "DOCLING_TIMEOUT": cls.DOCLING_TIMEOUT,
            "BEDROCK_TIMEOUT": cls.BEDROCK_TIMEOUT,
            "LAMBDA_TIMEOUT": cls.LAMBDA_TIMEOUT,
            # External Services
            "DOCLING_ENDPOINT_URL": cls.DOCLING_ENDPOINT_URL,
            # Runtime Configuration
            "LOG_LEVEL": cls.LOG_LEVEL,
            "LAMBDA_MEMORY_SIZE": cls.LAMBDA_MEMORY_SIZE,
            "LAMBDA_RESERVED_CONCURRENCY": cls.LAMBDA_RESERVED_CONCURRENCY,
            # Security
            "KMS_KEY_ID": cls.KMS_KEY_ID,
            "ENABLE_ENCRYPTION": cls.ENABLE_ENCRYPTION,
            # Monitoring
            "ENABLE_CLOUDWATCH_METRICS": cls.ENABLE_CLOUDWATCH_METRICS,
            "ENABLE_XRAY_TRACING": cls.ENABLE_XRAY_TRACING,
        }

    @classmethod
    def validate(cls) -> Dict[str, Any]:
        """
        Comprehensive validation of environment variables.

        Returns:
            Dict[str, Any]: Validation results with errors and warnings
        """
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "missing_required": [],
            "invalid_values": [],
            "security_issues": [],
        }

        # Required variables for production
        required_vars = [
            ("DOCUMENTS_BUCKET", cls.DOCUMENTS_BUCKET),
            ("AWS_REGION", cls.AWS_REGION),
            ("BEDROCK_REGION", cls.BEDROCK_REGION),
            ("BEDROCK_EMBEDDING_MODEL_EN", cls.BEDROCK_EMBEDDING_MODEL_EN),
            ("BEDROCK_LLM_MODEL", cls.BEDROCK_LLM_MODEL),
        ]

        # Check required variables
        for var_name, var_value in required_vars:
            if not var_value or var_value.strip() == "":
                validation_result["missing_required"].append(var_name)
                validation_result["errors"].append(
                    f"Required variable {var_name} is missing or empty"
                )

        # Validate numeric ranges
        numeric_validations = [
            ("MAX_EMBEDDING_BATCH_SIZE", cls.MAX_EMBEDDING_BATCH_SIZE, 1, 100),
            ("TOP_K_CHUNKS", cls.TOP_K_CHUNKS, 1, 50),
            ("PER_KPI_TOP_K", cls.PER_KPI_TOP_K, 1, 20),
            ("MAX_FILE_SIZE_MB", cls.MAX_FILE_SIZE_MB, 1, 1000),
            ("MAX_RETRIES", cls.MAX_RETRIES, 1, 10),
            ("DOCLING_TIMEOUT", cls.DOCLING_TIMEOUT, 60, 3600),
            ("BEDROCK_TIMEOUT", cls.BEDROCK_TIMEOUT, 30, 1800),
            ("LAMBDA_TIMEOUT", cls.LAMBDA_TIMEOUT, 60, 900),
            ("LAMBDA_MEMORY_SIZE", cls.LAMBDA_MEMORY_SIZE, 128, 10240),
        ]

        for var_name, value, min_val, max_val in numeric_validations:
            if not (min_val <= value <= max_val):
                validation_result["invalid_values"].append(
                    f"{var_name}={value} must be between {min_val} and {max_val}"
                )

        # Validate percentage values
        percentage_validations = [
            ("BM25_WEIGHT", cls.BM25_WEIGHT),
            ("VECTOR_WEIGHT", cls.VECTOR_WEIGHT),
        ]

        for var_name, value in percentage_validations:
            if not (0.0 <= value <= 1.0):
                validation_result["invalid_values"].append(
                    f"{var_name}={value} must be between 0.0 and 1.0"
                )

        # Check weight sum
        weight_sum = cls.BM25_WEIGHT + cls.VECTOR_WEIGHT
        if abs(weight_sum - 1.0) > 0.01:  # Allow small floating point differences
            validation_result["warnings"].append(
                f"BM25_WEIGHT + VECTOR_WEIGHT = {weight_sum:.3f}, should equal 1.0"
            )

        # Validate environment-specific requirements
        if cls.ENVIRONMENT == "production":
            production_requirements = [
                ("AWS_ACCOUNT_ID", cls.AWS_ACCOUNT_ID),
                ("KMS_KEY_ID", cls.KMS_KEY_ID),
                ("DOCLING_ENDPOINT_URL", cls.DOCLING_ENDPOINT_URL),
            ]

            for var_name, var_value in production_requirements:
                if not var_value:
                    validation_result["warnings"].append(
                        f"Production environment should have {var_name} configured"
                    )

        # Security validations
        if cls.ENVIRONMENT == "production" and not cls.ENABLE_ENCRYPTION:
            validation_result["security_issues"].append(
                "Encryption should be enabled in production environment"
            )

        # Validate supported file types
        valid_file_types = {"pdf", "xlsx", "xls", "docx", "txt", "csv"}
        invalid_types = set(cls.SUPPORTED_FILE_TYPES) - valid_file_types
        if invalid_types:
            validation_result["warnings"].append(
                f"Unsupported file types detected: {invalid_types}"
            )

        # Validate model names format
        model_validations = [
            ("BEDROCK_EMBEDDING_MODEL_EN", cls.BEDROCK_EMBEDDING_MODEL_EN),
            ("BEDROCK_EMBEDDING_MODEL_FR", cls.BEDROCK_EMBEDDING_MODEL_FR),
            ("BEDROCK_LLM_MODEL", cls.BEDROCK_LLM_MODEL),
            ("BEDROCK_VISION_MODEL", cls.BEDROCK_VISION_MODEL),
        ]

        for var_name, model_id in model_validations:
            if model_id and not (
                model_id.startswith("amazon.")
                or model_id.startswith("anthropic.")
                or model_id.startswith("cohere.")
            ):
                validation_result["warnings"].append(
                    f"{var_name}={model_id} doesn't match expected model naming convention"
                )

        # Set overall validation status
        if (
            validation_result["errors"]
            or validation_result["missing_required"]
            or validation_result["invalid_values"]
        ):
            validation_result["is_valid"] = False

        return validation_result

    @classmethod
    def validate_runtime_dependencies(cls) -> Dict[str, Any]:
        """
        Validate runtime dependencies and service availability.

        Returns:
            Dict[str, Any]: Runtime validation results
        """
        import boto3
        from botocore.exceptions import ClientError, NoCredentialsError

        validation_result = {
            "is_valid": True,
            "aws_connectivity": False,
            "s3_access": False,
            "dynamodb_access": False,
            "sqs_access": False,
            "bedrock_access": False,
            "errors": [],
            "warnings": [],
        }

        try:
            # Test AWS credentials
            sts_client = boto3.client("sts", region_name=cls.AWS_REGION)
            identity = sts_client.get_caller_identity()
            validation_result["aws_connectivity"] = True
            validation_result["account_id"] = identity.get("Account")

        except NoCredentialsError:
            validation_result["errors"].append("AWS credentials not configured")
            validation_result["is_valid"] = False
            return validation_result
        except Exception as e:
            validation_result["errors"].append(f"AWS connectivity error: {str(e)}")
            validation_result["is_valid"] = False

        # Test S3 access
        try:
            s3_client = boto3.client("s3", region_name=cls.AWS_REGION)
            s3_client.head_bucket(Bucket=cls.DOCUMENTS_BUCKET)
            validation_result["s3_access"] = True
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "404":
                validation_result["warnings"].append(
                    f"S3 bucket {cls.DOCUMENTS_BUCKET} does not exist"
                )
            else:
                validation_result["errors"].append(f"S3 access error: {error_code}")
        except Exception as e:
            validation_result["errors"].append(f"S3 connectivity error: {str(e)}")

        # Test DynamoDB access
        try:
            dynamodb_client = boto3.client("dynamodb", region_name=cls.AWS_REGION)
            # Test one table
            dynamodb_client.describe_table(TableName=cls.KPI_ANALYZE_STATUS_TABLE)
            validation_result["dynamodb_access"] = True
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "ResourceNotFoundException":
                validation_result["warnings"].append(
                    f"DynamoDB table {cls.KPI_ANALYZE_STATUS_TABLE} does not exist"
                )
            else:
                validation_result["errors"].append(
                    f"DynamoDB access error: {error_code}"
                )
        except Exception as e:
            validation_result["errors"].append(f"DynamoDB connectivity error: {str(e)}")

        # Test SQS access
        try:
            sqs_client = boto3.client("sqs", region_name=cls.AWS_REGION)
            sqs_client.get_queue_url(QueueName=cls.EMBEDDING_QUEUE_NAME)
            validation_result["sqs_access"] = True
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "AWS.SimpleQueueService.NonExistentQueue":
                validation_result["warnings"].append(
                    f"SQS queue {cls.EMBEDDING_QUEUE_NAME} does not exist"
                )
            else:
                validation_result["errors"].append(f"SQS access error: {error_code}")
        except Exception as e:
            validation_result["errors"].append(f"SQS connectivity error: {str(e)}")

        # Test Bedrock access
        try:
            bedrock_client = boto3.client(
                "bedrock-runtime", region_name=cls.BEDROCK_REGION
            )
            # Test with a simple request (this might fail due to permissions, but tests connectivity)
            validation_result["bedrock_access"] = True
        except Exception as e:
            validation_result["warnings"].append(
                f"Bedrock connectivity warning: {str(e)}"
            )

        return validation_result

    @classmethod
    def to_json(cls) -> str:
        """Convert environment variables to JSON string."""
        return json.dumps(cls.get_all(), indent=2, default=str)

    @classmethod
    def print_config(cls) -> None:
        """Print the current configuration with validation."""
        print("=" * 80)
        print("STANDARDIZED KPI EXTRACTION CONFIGURATION")
        print("=" * 80)

        # Basic configuration
        config = cls.get_all()
        for key, value in config.items():
            if "KEY" in key or "SECRET" in key:
                print(f"{key}: {'*' * len(str(value)) if value else 'NOT_SET'}")
            else:
                print(f"{key}: {value}")

        print("\n" + "=" * 80)
        print("CONFIGURATION VALIDATION")
        print("=" * 80)

        # Validate configuration
        validation = cls.validate()

        if validation["is_valid"]:
            print("✅ Configuration is VALID")
        else:
            print("❌ Configuration has ERRORS")

        if validation["errors"]:
            print("\n🚨 ERRORS:")
            for error in validation["errors"]:
                print(f"  - {error}")

        if validation["warnings"]:
            print("\n⚠️  WARNINGS:")
            for warning in validation["warnings"]:
                print(f"  - {warning}")

        if validation["missing_required"]:
            print("\n❌ MISSING REQUIRED:")
            for missing in validation["missing_required"]:
                print(f"  - {missing}")

    @classmethod
    def generate_terraform_variables(cls) -> str:
        """
        Generate Terraform variables file with standardized names and validation.
        """
        terraform_vars = f"""
# STANDARDIZED Environment Variables for KPI Extraction Pipeline
# Generated from standardized_env_vars.py on {datetime.now(timezone.utc).isoformat()}

# Core Infrastructure Variables
variable "stack_name" {{
  description = "Stack name for resource naming"
  type        = string
  default     = "{cls.STACK_NAME}"
  
  validation {{
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]*$", var.stack_name))
    error_message = "Stack name must start with a letter and contain only alphanumeric characters and hyphens."
  }}
}}

variable "environment" {{
  description = "Environment (development, staging, production)"
  type        = string
  default     = "{cls.ENVIRONMENT}"
  
  validation {{
    condition     = contains(["development", "staging", "production"], var.environment)
    error_message = "Environment must be one of: development, staging, production."
  }}
}}

variable "aws_region" {{
  description = "AWS region for deployment"
  type        = string
  default     = "{cls.AWS_REGION}"
}}

# S3 Configuration
variable "documents_bucket" {{
  description = "S3 bucket for documents"
  type        = string
  default     = "{cls.DOCUMENTS_BUCKET}"
}}

# DynamoDB Tables
variable "kpi_analyze_status_table" {{
  description = "DynamoDB table for analyze status"
  type        = string
  default     = "{cls.KPI_ANALYZE_STATUS_TABLE}"
}}

variable "kpi_file_status_table" {{
  description = "DynamoDB table for file status"
  type        = string
  default     = "{cls.KPI_FILE_STATUS_TABLE}"
}}

variable "kpi_document_chunks_table" {{
  description = "DynamoDB table for document chunks"
  type        = string
  default     = "{cls.KPI_DOCUMENT_CHUNKS_TABLE}"
}}

variable "kpi_retrieval_context_table" {{
  description = "DynamoDB table for retrieval context"
  type        = string
  default     = "{cls.KPI_RETRIEVAL_CONTEXT_TABLE}"
}}

variable "kpi_responses_table" {{
  description = "DynamoDB table for KPI responses"
  type        = string
  default     = "{cls.KPI_RESPONSES_TABLE}"
}}

variable "kpi_final_output_table" {{
  description = "DynamoDB table for final output"
  type        = string
  default     = "{cls.KPI_FINAL_OUTPUT_TABLE}"
}}

variable "prompt_store_table" {{
  description = "DynamoDB table for prompt store"
  type        = string
  default     = "{cls.PROMPT_STORE_TABLE}"
}}

# SQS Queues
variable "embedding_queue_name" {{
  description = "SQS queue for embedding processing"
  type        = string
  default     = "{cls.EMBEDDING_QUEUE_NAME}"
}}

variable "retrieval_queue_name" {{
  description = "SQS queue for retrieval processing"
  type        = string
  default     = "{cls.RETRIEVAL_QUEUE_NAME}"
}}

variable "kpi_generation_queue_name" {{
  description = "SQS queue for KPI generation"
  type        = string
  default     = "{cls.KPI_GENERATION_QUEUE_NAME}"
}}

variable "output_generation_queue_name" {{
  description = "SQS queue for output generation"
  type        = string
  default     = "{cls.OUTPUT_GENERATION_QUEUE_NAME}"
}}

# Bedrock Configuration
variable "bedrock_region" {{
  description = "AWS region for Bedrock services"
  type        = string
  default     = "{cls.BEDROCK_REGION}"
}}

variable "bedrock_embedding_model_en" {{
  description = "Bedrock embedding model for English"
  type        = string
  default     = "{cls.BEDROCK_EMBEDDING_MODEL_EN}"
}}

variable "bedrock_embedding_model_fr" {{
  description = "Bedrock embedding model for French"
  type        = string
  default     = "{cls.BEDROCK_EMBEDDING_MODEL_FR}"
}}

variable "bedrock_llm_model" {{
  description = "Bedrock LLM model for KPI extraction"
  type        = string
  default     = "{cls.BEDROCK_LLM_MODEL}"
}}

variable "bedrock_vision_model" {{
  description = "Bedrock vision model for image processing"
  type        = string
  default     = "{cls.BEDROCK_VISION_MODEL}"
}}

# Processing Configuration
variable "max_embedding_batch_size" {{
  description = "Maximum batch size for embedding processing"
  type        = number
  default     = {cls.MAX_EMBEDDING_BATCH_SIZE}
  
  validation {{
    condition     = var.max_embedding_batch_size >= 1 && var.max_embedding_batch_size <= 100
    error_message = "Max embedding batch size must be between 1 and 100."
  }}
}}

variable "top_k_chunks" {{
  description = "Number of top chunks to retrieve"
  type        = number
  default     = {cls.TOP_K_CHUNKS}
  
  validation {{
    condition     = var.top_k_chunks >= 1 && var.top_k_chunks <= 50
    error_message = "Top K chunks must be between 1 and 50."
  }}
}}

variable "per_kpi_top_k" {{
  description = "Number of top chunks per KPI"
  type        = number
  default     = {cls.PER_KPI_TOP_K}
  
  validation {{
    condition     = var.per_kpi_top_k >= 1 && var.per_kpi_top_k <= 20
    error_message = "Per KPI top K must be between 1 and 20."
  }}
}}

# Hybrid Search Configuration
variable "bm25_weight" {{
  description = "Weight for BM25 search in hybrid retrieval"
  type        = number
  default     = {cls.BM25_WEIGHT}
  
  validation {{
    condition     = var.bm25_weight >= 0.0 && var.bm25_weight <= 1.0
    error_message = "BM25 weight must be between 0.0 and 1.0."
  }}
}}

variable "vector_weight" {{
  description = "Weight for vector search in hybrid retrieval"
  type        = number
  default     = {cls.VECTOR_WEIGHT}
  
  validation {{
    condition     = var.vector_weight >= 0.0 && var.vector_weight <= 1.0
    error_message = "Vector weight must be between 0.0 and 1.0."
  }}
}}

# Security Configuration
variable "enable_encryption" {{
  description = "Enable encryption for S3 and DynamoDB"
  type        = bool
  default     = {str(cls.ENABLE_ENCRYPTION).lower()}
}}

variable "kms_key_id" {{
  description = "KMS key ID for encryption"
  type        = string
  default     = "{cls.KMS_KEY_ID}"
}}

# Lambda Configuration
variable "lambda_memory_size" {{
  description = "Memory size for Lambda functions"
  type        = number
  default     = {cls.LAMBDA_MEMORY_SIZE}
  
  validation {{
    condition     = var.lambda_memory_size >= 128 && var.lambda_memory_size <= 10240
    error_message = "Lambda memory size must be between 128 and 10240 MB."
  }}
}}

variable "lambda_timeout" {{
  description = "Timeout for Lambda functions"
  type        = number
  default     = {cls.LAMBDA_TIMEOUT}
  
  validation {{
    condition     = var.lambda_timeout >= 60 && var.lambda_timeout <= 900
    error_message = "Lambda timeout must be between 60 and 900 seconds."
  }}
}}

# Monitoring Configuration
variable "enable_cloudwatch_metrics" {{
  description = "Enable CloudWatch metrics"
  type        = bool
  default     = {str(cls.ENABLE_CLOUDWATCH_METRICS).lower()}
}}

variable "enable_xray_tracing" {{
  description = "Enable X-Ray tracing"
  type        = bool
  default     = {str(cls.ENABLE_XRAY_TRACING).lower()}
}}

# Local variables for Lambda environment
locals {{
  common_environment = {{
    # Core Infrastructure
    DOCUMENTS_BUCKET                = var.documents_bucket
    AWS_REGION                     = var.aws_region
    ENVIRONMENT                    = var.environment
    STACK_NAME                     = var.stack_name
    
    # DynamoDB Tables
    KPI_ANALYZE_STATUS_TABLE       = var.kpi_analyze_status_table
    KPI_FILE_STATUS_TABLE          = var.kpi_file_status_table
    KPI_DOCUMENT_CHUNKS_TABLE      = var.kpi_document_chunks_table
    KPI_RETRIEVAL_CONTEXT_TABLE    = var.kpi_retrieval_context_table
    KPI_RESPONSES_TABLE            = var.kpi_responses_table
    KPI_FINAL_OUTPUT_TABLE         = var.kpi_final_output_table
    PROMPT_STORE_TABLE             = var.prompt_store_table
    
    # SQS Queues
    EMBEDDING_QUEUE_NAME           = var.embedding_queue_name
    RETRIEVAL_QUEUE_NAME           = var.retrieval_queue_name
    KPI_GENERATION_QUEUE_NAME      = var.kpi_generation_queue_name
    OUTPUT_GENERATION_QUEUE_NAME   = var.output_generation_queue_name
    
    # Bedrock Configuration
    BEDROCK_REGION                 = var.bedrock_region
    BEDROCK_EMBEDDING_MODEL_EN     = var.bedrock_embedding_model_en
    BEDROCK_EMBEDDING_MODEL_FR     = var.bedrock_embedding_model_fr
    BEDROCK_LLM_MODEL              = var.bedrock_llm_model
    BEDROCK_VISION_MODEL           = var.bedrock_vision_model
    
    # Processing Configuration
    MAX_EMBEDDING_BATCH_SIZE       = tostring(var.max_embedding_batch_size)
    TOP_K_CHUNKS                   = tostring(var.top_k_chunks)
    PER_KPI_TOP_K                  = tostring(var.per_kpi_top_k)
    BM25_WEIGHT                    = tostring(var.bm25_weight)
    VECTOR_WEIGHT                  = tostring(var.vector_weight)
    BM25_FACTOR                    = "{cls.BM25_FACTOR}"
    
    # File Processing
    MAX_FILE_SIZE_MB               = "{cls.MAX_FILE_SIZE_MB}"
    SUPPORTED_FILE_TYPES           = "{','.join(cls.SUPPORTED_FILE_TYPES)}"
    MAX_IMAGES_PER_DOCUMENT        = "{cls.MAX_IMAGES_PER_DOCUMENT}"
    
    # Timeouts and Retries
    MAX_RETRIES                    = "{cls.MAX_RETRIES}"
    DOCLING_TIMEOUT                = "{cls.DOCLING_TIMEOUT}"
    BEDROCK_TIMEOUT                = "{cls.BEDROCK_TIMEOUT}"
    
    # Security
    ENABLE_ENCRYPTION              = tostring(var.enable_encryption)
    KMS_KEY_ID                     = var.kms_key_id
    
    # Monitoring
    ENABLE_CLOUDWATCH_METRICS      = tostring(var.enable_cloudwatch_metrics)
    ENABLE_XRAY_TRACING           = tostring(var.enable_xray_tracing)
    
    # Logging
    LOG_LEVEL                      = "{cls.LOG_LEVEL}"
  }}
}}

# Outputs
output "environment_variables" {{
  description = "Environment variables for Lambda functions"
  value       = local.common_environment
  sensitive   = false
}}

output "configuration_summary" {{
  description = "Summary of the configuration"
  value = {{
    stack_name    = var.stack_name
    environment   = var.environment
    aws_region    = var.aws_region
    bedrock_region = var.bedrock_region
    encryption_enabled = var.enable_encryption
    monitoring_enabled = var.enable_cloudwatch_metrics
  }}
}}
"""
        return terraform_vars

    @classmethod
    def generate_docker_env_file(cls) -> str:
        """Generate Docker environment file for local testing with validation."""
        env_content = f"""# STANDARDIZED Environment Variables for KPI Extraction Pipeline
# Generated from standardized_env_vars.py on {datetime.now(timezone.utc).isoformat()}
# Environment: {cls.ENVIRONMENT}

# Core Infrastructure
DOCUMENTS_BUCKET={cls.DOCUMENTS_BUCKET}
AWS_REGION={cls.AWS_REGION}
ENVIRONMENT={cls.ENVIRONMENT}
STACK_NAME={cls.STACK_NAME}

# DynamoDB Tables
KPI_ANALYZE_STATUS_TABLE={cls.KPI_ANALYZE_STATUS_TABLE}
KPI_FILE_STATUS_TABLE={cls.KPI_FILE_STATUS_TABLE}
KPI_DOCUMENT_CHUNKS_TABLE={cls.KPI_DOCUMENT_CHUNKS_TABLE}
KPI_RETRIEVAL_CONTEXT_TABLE={cls.KPI_RETRIEVAL_CONTEXT_TABLE}
KPI_RESPONSES_TABLE={cls.KPI_RESPONSES_TABLE}
KPI_FINAL_OUTPUT_TABLE={cls.KPI_FINAL_OUTPUT_TABLE}
PROMPT_STORE_TABLE={cls.PROMPT_STORE_TABLE}

# SQS Queues
EMBEDDING_QUEUE_NAME={cls.EMBEDDING_QUEUE_NAME}
RETRIEVAL_QUEUE_NAME={cls.RETRIEVAL_QUEUE_NAME}
KPI_GENERATION_QUEUE_NAME={cls.KPI_GENERATION_QUEUE_NAME}
OUTPUT_GENERATION_QUEUE_NAME={cls.OUTPUT_GENERATION_QUEUE_NAME}

# Bedrock Configuration
BEDROCK_REGION={cls.BEDROCK_REGION}
BEDROCK_EMBEDDING_MODEL_EN={cls.BEDROCK_EMBEDDING_MODEL_EN}
BEDROCK_EMBEDDING_MODEL_FR={cls.BEDROCK_EMBEDDING_MODEL_FR}
BEDROCK_LLM_MODEL={cls.BEDROCK_LLM_MODEL}
BEDROCK_VISION_MODEL={cls.BEDROCK_VISION_MODEL}

# Processing Configuration
MAX_EMBEDDING_BATCH_SIZE={cls.MAX_EMBEDDING_BATCH_SIZE}
TOP_K_CHUNKS={cls.TOP_K_CHUNKS}
PER_KPI_TOP_K={cls.PER_KPI_TOP_K}
BM25_WEIGHT={cls.BM25_WEIGHT}
VECTOR_WEIGHT={cls.VECTOR_WEIGHT}
BM25_FACTOR={cls.BM25_FACTOR}

# File Processing
MAX_FILE_SIZE_MB={cls.MAX_FILE_SIZE_MB}
SUPPORTED_FILE_TYPES={','.join(cls.SUPPORTED_FILE_TYPES)}
MAX_IMAGES_PER_DOCUMENT={cls.MAX_IMAGES_PER_DOCUMENT}

# Timeouts and Retries
MAX_RETRIES={cls.MAX_RETRIES}
DOCLING_TIMEOUT={cls.DOCLING_TIMEOUT}
BEDROCK_TIMEOUT={cls.BEDROCK_TIMEOUT}
LAMBDA_TIMEOUT={cls.LAMBDA_TIMEOUT}

# Security
ENABLE_ENCRYPTION={cls.ENABLE_ENCRYPTION}
KMS_KEY_ID={cls.KMS_KEY_ID}

# Monitoring
ENABLE_CLOUDWATCH_METRICS={cls.ENABLE_CLOUDWATCH_METRICS}
ENABLE_XRAY_TRACING={cls.ENABLE_XRAY_TRACING}

# Runtime Configuration
LOG_LEVEL={cls.LOG_LEVEL}
LAMBDA_MEMORY_SIZE={cls.LAMBDA_MEMORY_SIZE}
LAMBDA_RESERVED_CONCURRENCY={cls.LAMBDA_RESERVED_CONCURRENCY}

# External Services (configure as needed)
DOCLING_ENDPOINT_URL={cls.DOCLING_ENDPOINT_URL}
AWS_ACCOUNT_ID={cls.AWS_ACCOUNT_ID}
"""
        return env_content


# STANDARDIZED MESSAGE SCHEMAS with enhanced validation
class StandardizedMessageSchemas:
    """
    Standardized message schemas for cross-stage communication.
    All stages must use these exact schemas with validation.
    """

    @staticmethod
    def embedding_message(file_id: str, analyze_id: str) -> Dict[str, Any]:
        """Standard message for embedding queue with validation."""
        if not file_id or not analyze_id:
            raise ValueError("file_id and analyze_id are required")

        return {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "stage": "embedding",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_stage": "docling_complete",
            "message_version": "1.0",
        }

    @staticmethod
    def retrieval_message(
        file_id: str, analyze_id: str, chunk_count: int = 0
    ) -> Dict[str, Any]:
        """Standard message for retrieval queue with validation."""
        if not file_id or not analyze_id:
            raise ValueError("file_id and analyze_id are required")

        return {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "stage": "retrieval",
            "chunk_count": max(0, chunk_count),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_stage": "embedding_complete",
            "message_version": "1.0",
        }

    @staticmethod
    def kpi_generation_message(
        file_id: str, analyze_id: str, context_stats: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Standard message for KPI generation queue with validation."""
        if not file_id or not analyze_id:
            raise ValueError("file_id and analyze_id are required")

        return {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "stage": "kpi_generation",
            "context_stats": context_stats or {},
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_stage": "retrieval_complete",
            "message_version": "1.0",
        }

    @staticmethod
    def output_generation_message(analyze_id: str) -> Dict[str, Any]:
        """Standard message for output generation queue with validation."""
        if not analyze_id:
            raise ValueError("analyze_id is required")

        return {
            "analyze_id": analyze_id,
            "stage": "output_generation",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_stage": "all_kpi_complete",
            "message_version": "1.0",
        }

    @staticmethod
    def validate_message(message: Dict[str, Any], expected_stage: str) -> bool:
        """Validate message format and content."""
        required_fields = ["timestamp", "stage", "message_version"]

        # Check required fields
        for field in required_fields:
            if field not in message:
                return False

        # Check stage matches
        if message.get("stage") != expected_stage:
            return False

        # Check message version
        if message.get("message_version") != "1.0":
            return False

        # Stage-specific validations
        if expected_stage in ["embedding", "retrieval", "kpi_generation"]:
            if not message.get("file_id") or not message.get("analyze_id"):
                return False
        elif expected_stage == "output_generation":
            if not message.get("analyze_id"):
                return False

        return True


if __name__ == "__main__":
    # Generate configuration files and perform validation
    env_vars = EnvironmentVariables()

    print("=== STANDARDIZED CONFIGURATION WITH VALIDATION ===")
    env_vars.print_config()

    print("\n=== RUNTIME DEPENDENCY VALIDATION ===")
    try:
        runtime_validation = env_vars.validate_runtime_dependencies()

        if runtime_validation["is_valid"]:
            print("✅ Runtime dependencies are accessible")
        else:
            print("⚠️  Some runtime dependencies have issues")

        if runtime_validation["errors"]:
            print("\n🚨 RUNTIME ERRORS:")
            for error in runtime_validation["errors"]:
                print(f"  - {error}")

        if runtime_validation["warnings"]:
            print("\n⚠️  RUNTIME WARNINGS:")
            for warning in runtime_validation["warnings"]:
                print(f"  - {warning}")

    except Exception as e:
        print(f"⚠️  Could not validate runtime dependencies: {e}")

    print("\n=== GENERATING CONFIGURATION FILES ===")

    # Generate Terraform variables
    terraform_content = env_vars.generate_terraform_variables()
    with open("standardized_terraform.tf", "w") as f:
        f.write(terraform_content)
    print("✅ Generated: standardized_terraform.tf")

    # Generate Docker env file
    docker_env = env_vars.generate_docker_env_file()
    with open("standardized.env", "w") as f:
        f.write(docker_env)
    print("✅ Generated: standardized.env")

    print("\n=== MESSAGE SCHEMA EXAMPLES ===")
    schemas = StandardizedMessageSchemas()

    try:
        print(
            "Embedding message:",
            json.dumps(schemas.embedding_message("file-123", "analyze-456"), indent=2),
        )
        print(
            "Output message:",
            json.dumps(schemas.output_generation_message("analyze-456"), indent=2),
        )
        print("✅ Message schemas validated")
    except Exception as e:
        print(f"❌ Message schema error: {e}")

    print("\n=== CONFIGURATION SUMMARY ===")
    print(f"Environment: {env_vars.ENVIRONMENT}")
    print(f"Stack Name: {env_vars.STACK_NAME}")
    print(f"AWS Region: {env_vars.AWS_REGION}")
    print(f"Bedrock Region: {env_vars.BEDROCK_REGION}")
    print(f"Encryption Enabled: {env_vars.ENABLE_ENCRYPTION}")
    print(f"Monitoring Enabled: {env_vars.ENABLE_CLOUDWATCH_METRICS}")
    print("\n✅ Configuration validation completed")
