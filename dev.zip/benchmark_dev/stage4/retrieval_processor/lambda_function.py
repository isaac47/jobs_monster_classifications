import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import boto3
from utils.similarity_calculator import SimilarityCalculator

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.analyze_status_checker import AnalyzeStatusChecker
from common.utils.dynamodb_utils import get_item, put_item, query_items, update_item
from common.utils.logger import LogContext, get_logger
from common.utils.prompt_store_manager import prompt_store
from common.utils.sqs_utils import get_queue_url, send_message

logger = get_logger(__name__)


def parse_sqs_message(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Parse SQS messages from the event.

    Args:
        event: Lambda event

    Returns:
        List[Dict[str, Any]]: List of parsed messages
    """
    messages = []

    for record in event.get("Records", []):
        if record.get("eventSource") != "aws:sqs":
            continue

        body = record.get("body")
        if not body:
            continue

        try:
            message = json.loads(body)
            messages.append(
                {"message": message, "receipt_handle": record.get("receiptHandle")}
            )
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing message body: {e}")

    return messages


def update_file_status(
    file_id: str,
    analyze_id: str,
    status: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """
    Update file status in KPI file status table.

    Args:
        file_id: File identifier
        analyze_id: Analyze identifier
        status: New status
        metadata: Optional additional metadata

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        update_expression = """
        SET #status = :status,
            updated_at = :updated_at
        """

        expression_values = {
            ":status": status,
            ":updated_at": datetime.now(timezone.utc).isoformat(),
        }

        expression_names = {"#status": "status"}

        # Add additional metadata if provided
        if metadata:
            for key, value in metadata.items():
                safe_key = key.replace("-", "_").replace(".", "_")
                update_expression += f", {safe_key} = :{safe_key}"
                expression_values[f":{safe_key}"] = value

        return update_item(
            EnvVars.KPI_FILE_STATUS_TABLE,
            {"file_id": file_id, "analyze_id": analyze_id},
            update_expression,
            expression_values,
            expression_names,
        )

    except Exception as e:
        logger.error(f"Error updating file status: {e}")
        return False


def get_chunks_for_file(file_id: str) -> List[Dict[str, Any]]:
    """
    Get all chunks with embeddings for a specific file from DynamoDB.

    Args:
        file_id: File identifier

    Returns:
        List[Dict[str, Any]]: List of chunks with embeddings
    """
    try:
        chunks = query_items(
            EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
            "file_id = :file_id",
            {":file_id": file_id},
        )

        # Filter chunks that have embeddings
        embedded_chunks = [chunk for chunk in chunks if chunk.get("embedding")]

        logger.info(
            f"Retrieved {len(embedded_chunks)} embedded chunks for file {file_id}"
        )
        return embedded_chunks

    except Exception as e:
        logger.error(f"Error retrieving chunks for file {file_id}: {e}")
        return []


def get_retrieval_prompt_template(
    bank_id: str, document_category: str, language: str = "en"
) -> Optional[str]:
    """
    Get context retrieval prompt template from DynamoDB prompt store.

    Args:
        bank_id: Bank ID
        document_category: Document category
        language: Language preference

    Returns:
        Optional[str]: Context retrieval template or None if not found
    """
    try:
        # Try to get context retrieval specific template
        template = prompt_store.get_prompt_template(
            bank_id=bank_id,
            document_category=document_category,
            template_type="context_retrieval",
            language=language,
        )

        if template:
            logger.info(
                f"Found context retrieval template for {bank_id}/{document_category}"
            )
            return template

        # Fallback to document analysis template
        template = prompt_store.get_prompt_template(
            bank_id=bank_id,
            document_category=document_category,
            template_type="document_analysis",
            language=language,
        )

        if template:
            logger.info(
                f"Using document analysis template for {bank_id}/{document_category}"
            )
            return template

        # Final fallback to default context retrieval
        template = prompt_store.get_prompt_template(
            bank_id="default",
            document_category="context_retrieval_default",
            template_type="context_retrieval",
            language=language,
        )

        if template:
            logger.info(f"Using default context retrieval template")
            return template

        logger.warning(
            f"No context retrieval template found for {bank_id}/{document_category}"
        )
        return None

    except Exception as e:
        logger.error(f"Error retrieving context retrieval template: {e}")
        return None


def generate_enhanced_kpi_queries(
    kpi_list: List[str],
    kpi_taxonomy: Dict[str, Any],
    context_template: str,
    bank_id: str,
    language: str = "en",
) -> List[Dict[str, Any]]:
    """
    Generate enhanced KPI-specific queries using taxonomy and context template.

    Args:
        kpi_list: List of KPIs to extract
        kpi_taxonomy: KPI taxonomy with synonyms and categories
        context_template: Context template for query enhancement
        bank_id: Bank identifier for context
        language: Language for query generation

    Returns:
        List[Dict[str, Any]]: List of enhanced KPI-specific queries
    """
    queries = []

    try:
        # Extract query patterns from context template if available
        query_enhancement_patterns = {
            "financial_context": [
                "financial performance",
                "banking metrics",
                "key indicators",
            ],
            "temporal_context": ["quarterly", "annual", "period", "year-over-year"],
            "regulatory_context": [
                "regulatory capital",
                "compliance",
                "Basel",
                "solvency",
            ],
            "business_context": [
                "business segments",
                "divisions",
                "operations",
                "activities",
            ],
        }

        for kpi in kpi_list:
            try:
                # Get KPI information from taxonomy
                kpi_info = kpi_taxonomy.get(kpi, {})

                # Build base query components
                base_terms = [kpi]

                # Add synonyms from taxonomy
                synonyms = kpi_info.get("synonyms", [])
                base_terms.extend(synonyms)

                # Build contextual query variations
                query_variations = []

                # 1. Direct KPI query
                direct_query = f"Extract {kpi} financial metric from banking documents"
                if synonyms:
                    direct_query += f" (also known as: {', '.join(synonyms[:3])})"
                query_variations.append(
                    {"query_type": "direct", "query": direct_query, "weight": 1.0}
                )

                # 2. Category-enhanced query
                category = kpi_info.get("category", "")
                subcategory = kpi_info.get("subcategory", "")
                if category:
                    category_query = f"Find {kpi} in {category} section"
                    if subcategory:
                        category_query += f" specifically in {subcategory} data"
                    query_variations.append(
                        {
                            "query_type": "category",
                            "query": category_query,
                            "weight": 0.8,
                        }
                    )

                # 3. Context-enhanced query using template patterns
                if context_template:
                    # Extract financial context terms from template
                    financial_terms = []
                    for pattern_type, patterns in query_enhancement_patterns.items():
                        for pattern in patterns:
                            if pattern.lower() in context_template.lower():
                                financial_terms.append(pattern)

                    if financial_terms:
                        context_query = f"Locate {kpi} within {', '.join(financial_terms[:2])} context"
                        query_variations.append(
                            {
                                "query_type": "context",
                                "query": context_query,
                                "weight": 0.7,
                            }
                        )

                # 4. Language-specific query
                if language == "fr":
                    # French-specific enhancements
                    fr_query = (
                        f"Identifier {kpi} dans les documents financiers français"
                    )
                    if synonyms:
                        fr_terms = [
                            s
                            for s in synonyms
                            if any(
                                fr_word in s.lower()
                                for fr_word in [
                                    "ratio",
                                    "résultat",
                                    "produit",
                                    "coefficient",
                                ]
                            )
                        ]
                        if fr_terms:
                            fr_query += f" (aussi: {', '.join(fr_terms[:2])})"
                    query_variations.append(
                        {
                            "query_type": "language_specific",
                            "query": fr_query,
                            "weight": 0.9,
                        }
                    )

                # 5. Detail level query
                detail_level = kpi_info.get("detail_level", "")
                if detail_level:
                    detail_query = (
                        f"Extract {kpi} at {detail_level} level with breakdown details"
                    )
                    query_variations.append(
                        {
                            "query_type": "detail_level",
                            "query": detail_query,
                            "weight": 0.6,
                        }
                    )

                # 6. Priority-based query enhancement
                priority = kpi_info.get("priority", "medium")
                if priority == "high":
                    priority_query = f"Find key performance indicator {kpi} - critical metric for analysis"
                    query_variations.append(
                        {
                            "query_type": "priority",
                            "query": priority_query,
                            "weight": 1.2,
                        }
                    )

                # Create final query object
                final_query = {
                    "kpi": kpi,
                    "primary_query": query_variations[0][
                        "query"
                    ],  # Use direct query as primary
                    "query_variations": query_variations,
                    "priority": priority,
                    "category": category,
                    "synonyms": synonyms,
                    "expected_format": kpi_info.get("expected_format", ""),
                    "search_weight": (
                        1.0
                        if priority == "high"
                        else 0.8 if priority == "medium" else 0.6
                    ),
                }

                queries.append(final_query)

            except Exception as e:
                logger.error(f"Error generating query for KPI {kpi}: {e}")
                # Fallback simple query
                queries.append(
                    {
                        "kpi": kpi,
                        "primary_query": f"Extract {kpi} from financial documents",
                        "query_variations": [
                            {
                                "query_type": "fallback",
                                "query": f"Extract {kpi}",
                                "weight": 0.5,
                            }
                        ],
                        "priority": "medium",
                        "category": "",
                        "synonyms": [],
                        "search_weight": 0.5,
                    }
                )

        logger.info(f"Generated {len(queries)} enhanced KPI queries")
        return queries

    except Exception as e:
        logger.error(f"Error generating enhanced KPI queries: {e}")
        return []


def get_embedding_for_text(text: str, model_id: str) -> Optional[List[float]]:
    """
    Get embedding for a text using Bedrock.

    Args:
        text: Text to embed
        model_id: Bedrock model ID

    Returns:
        Optional[List[float]]: Embedding vector or None if failed
    """
    try:
        bedrock_runtime = boto3.client(
            service_name="bedrock-runtime", region_name=EnvVars.BEDROCK_REGION
        )

        # Prepare request body based on model
        if model_id.startswith("amazon.titan-embed"):
            request_body = {"inputText": text}
        elif model_id.startswith("cohere.embed"):
            request_body = {"texts": [text], "input_type": "search_query"}
        else:
            request_body = {"texts": [text]}

        response = bedrock_runtime.invoke_model(
            modelId=model_id,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(request_body),
        )

        response_body = json.loads(response.get("body").read())

        # Extract embedding based on model
        if model_id.startswith("amazon.titan-embed"):
            embedding = response_body.get("embedding", [])
        elif model_id.startswith("cohere.embed"):
            embeddings = response_body.get("embeddings", [])
            embedding = embeddings[0] if embeddings else []
        else:
            embeddings = response_body.get("embeddings", [])
            embedding = embeddings[0] if embeddings else []

        return embedding

    except Exception as e:
        logger.error(f"Error creating embedding for text: {e}")
        return None


def retrieve_relevant_context_per_kpi_enhanced(
    kpi_queries: List[Dict[str, Any]],
    chunks: List[Dict[str, Any]],
    model_id: str,
    top_k: int,
    context_template: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Enhanced retrieval with multiple query variations and context-aware ranking.

    Args:
        kpi_queries: List of enhanced KPI-specific queries
        chunks: List of chunks with embeddings
        model_id: Embedding model ID
        top_k: Number of chunks to retrieve per KPI
        context_template: Optional context template for enhanced ranking

    Returns:
        Dict[str, Any]: Enhanced context organized by KPI
    """
    try:
        # Initialize similarity calculator with enhanced weights
        calculator = SimilarityCalculator(
            bm25_weight=EnvVars.BM25_WEIGHT,
            vector_weight=EnvVars.VECTOR_WEIGHT,
            bm25_factor=EnvVars.BM25_FACTOR,
        )

        kpi_contexts = {}
        all_relevant_chunks = set()
        global_chunk_scores = {}  # Track chunk relevance across all KPIs

        for kpi_query in kpi_queries:
            kpi = kpi_query["kpi"]
            primary_query = kpi_query["primary_query"]
            query_variations = kpi_query.get("query_variations", [])
            search_weight = kpi_query.get("search_weight", 1.0)

            logger.debug(
                f"Processing enhanced queries for KPI '{kpi}': {len(query_variations)} variations"
            )

            # Process each query variation
            variation_results = []

            for variation in query_variations:
                query_text = variation["query"]
                variation_weight = variation.get("weight", 1.0)

                # Get embedding for this query variation
                query_embedding = get_embedding_for_text(query_text, model_id)
                if not query_embedding:
                    logger.warning(
                        f"Failed to get embedding for query variation: {query_text}"
                    )
                    continue

                # Get top chunks for this variation
                variation_chunks = calculator.get_top_k_chunks(
                    query_text,
                    query_embedding,
                    chunks,
                    top_k * 2,  # Get more for diversity
                )

                # Apply variation weight to scores
                for chunk in variation_chunks:
                    chunk["variation_weight"] = variation_weight
                    chunk["variation_type"] = variation.get("query_type", "unknown")
                    # Adjust relevance score
                    original_score = chunk.get("relevance_score", 0.0)
                    chunk["weighted_relevance_score"] = (
                        original_score * variation_weight
                    )

                variation_results.extend(variation_chunks)

            # Aggregate results across variations
            chunk_aggregated_scores = {}
            for chunk in variation_results:
                chunk_id = chunk.get("chunk_id")
                if chunk_id not in chunk_aggregated_scores:
                    chunk_aggregated_scores[chunk_id] = {
                        "chunk": chunk,
                        "total_score": 0.0,
                        "variation_count": 0,
                        "variation_types": set(),
                    }

                agg = chunk_aggregated_scores[chunk_id]
                agg["total_score"] += chunk.get("weighted_relevance_score", 0.0)
                agg["variation_count"] += 1
                agg["variation_types"].add(chunk.get("variation_type", "unknown"))

            # Calculate final scores and select top chunks
            final_chunks = []
            for chunk_id, agg in chunk_aggregated_scores.items():
                # Average score across variations with diversity bonus
                avg_score = agg["total_score"] / agg["variation_count"]

                # Diversity bonus for chunks that match multiple query types
                diversity_bonus = min(0.1 * len(agg["variation_types"]), 0.3)

                # Apply search weight for KPI priority
                final_score = (avg_score + diversity_bonus) * search_weight

                chunk = agg["chunk"].copy()
                chunk["final_relevance_score"] = final_score
                chunk["diversity_score"] = diversity_bonus
                chunk["matching_variations"] = list(agg["variation_types"])

                final_chunks.append(chunk)

            # Sort by final score and take top K
            final_chunks.sort(
                key=lambda x: x.get("final_relevance_score", 0), reverse=True
            )
            top_chunks = final_chunks[:top_k]

            # Store context for this KPI
            kpi_contexts[kpi] = {
                "query": primary_query,
                "query_variations_count": len(query_variations),
                "priority": kpi_query.get("priority", "medium"),
                "category": kpi_query.get("category", ""),
                "chunks": [],
            }

            # Process final chunks
            for chunk in top_chunks:
                chunk_info = {
                    "chunk_id": chunk.get("chunk_id"),
                    "file_id": chunk.get("file_id"),
                    "text": chunk.get("text", ""),
                    "page_info": chunk.get("page_info"),
                    "relevance_score": chunk.get("final_relevance_score", 0.0),
                    "diversity_score": chunk.get("diversity_score", 0.0),
                    "matching_variations": chunk.get("matching_variations", []),
                    "headings": chunk.get("headings", []),
                    "section_context": chunk.get("section_title", ""),
                }
                kpi_contexts[kpi]["chunks"].append(chunk_info)
                all_relevant_chunks.add(chunk.get("chunk_id"))

                # Track global relevance
                global_chunk_id = chunk.get("chunk_id")
                if global_chunk_id not in global_chunk_scores:
                    global_chunk_scores[global_chunk_id] = {
                        "chunk": chunk,
                        "kpi_matches": [],
                        "total_score": 0.0,
                    }

                global_chunk_scores[global_chunk_id]["kpi_matches"].append(kpi)
                global_chunk_scores[global_chunk_id]["total_score"] += chunk.get(
                    "final_relevance_score", 0.0
                )

        # Create overall context with cross-KPI relevant chunks
        overall_chunks = []
        for chunk_id, chunk_data in global_chunk_scores.items():
            if len(chunk_data["kpi_matches"]) > 1:  # Chunks relevant to multiple KPIs
                chunk_info = {
                    "chunk_id": chunk_id,
                    "file_id": chunk_data["chunk"].get("file_id"),
                    "text": chunk_data["chunk"].get("text", ""),
                    "page_info": chunk_data["chunk"].get("page_info"),
                    "relevance_score": chunk_data["total_score"],
                    "kpi_matches": chunk_data["kpi_matches"],
                    "cross_kpi_relevance": True,
                    "headings": chunk_data["chunk"].get("headings", []),
                }
                overall_chunks.append(chunk_info)

        # Sort overall chunks by cross-KPI relevance
        overall_chunks.sort(
            key=lambda x: (len(x["kpi_matches"]), x["relevance_score"]), reverse=True
        )

        context_result = {
            "kpi_specific_context": kpi_contexts,
            "overall_context": {
                "query": "Extract comprehensive financial KPIs and performance metrics",
                "chunks": overall_chunks[:top_k],
                "context_template_used": context_template is not None,
            },
            "statistics": {
                "total_kpis": len(kpi_queries),
                "total_unique_chunks": len(all_relevant_chunks),
                "cross_kpi_chunks": len(overall_chunks),
                "model_used": model_id,
                "enhanced_retrieval": True,
            },
        }

        logger.info(
            f"Enhanced retrieval: {len(kpi_contexts)} KPIs, {len(all_relevant_chunks)} unique chunks, {len(overall_chunks)} cross-KPI chunks"
        )
        return context_result

    except Exception as e:
        logger.error(f"Error in enhanced KPI-specific context retrieval: {e}")
        return {}


def store_retrieval_context(
    file_id: str, analyze_id: str, context: Dict[str, Any]
) -> bool:
    """
    Store retrieval context in DynamoDB.

    Args:
        file_id: File identifier
        analyze_id: Analyze identifier
        context: Context object

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        context_record = {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "context": context,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "context_type": "enhanced_kpi_retrieval",
            "retrieval_version": "2.0",  # Enhanced version
        }

        success = put_item(EnvVars.KPI_RETRIEVAL_CONTEXT_TABLE, context_record)

        if success:
            logger.info(f"Stored enhanced retrieval context for file {file_id}")
        else:
            logger.error(f"Failed to store retrieval context for file {file_id}")

        return success

    except Exception as e:
        logger.error(f"Error storing retrieval context: {e}")
        return False


def notify_kpi_generation_queue(
    message: Dict[str, Any], context_stats: Dict[str, Any]
) -> bool:
    """
    Notify the KPI generation queue that retrieval is complete.

    Args:
        message: Original message
        context_stats: Context statistics

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        queue_url = get_queue_url(EnvVars.KPI_GENERATION_QUEUE_NAME)
        if not queue_url:
            logger.error(
                f"Could not get URL for queue: {EnvVars.KPI_GENERATION_QUEUE_NAME}"
            )
            return False

        kpi_message = {
            "file_id": message.get("file_id"),
            "analyze_id": message.get("analyze_id"),
            "stage": "kpi_generation",
            "context_stats": context_stats,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_stage": "retrieval_complete",
            "enhanced_retrieval": True,
        }

        message_id = send_message(queue_url, kpi_message)
        if message_id:
            logger.info(f"Message sent to KPI generation queue: {message_id}")
            return True

        return False
    except Exception as e:
        logger.error(f"Error notifying KPI generation queue: {e}")
        return False


def process_message(message_data: Dict[str, Any]) -> bool:
    """
    Process a message from the queue with enhanced prompt template integration.

    Args:
        message_data: Message data

    Returns:
        bool: True if successful, False otherwise
    """
    message = message_data["message"]

    file_id = message.get("file_id")
    analyze_id = message.get("analyze_id")

    if not file_id or not analyze_id:
        logger.error(f"Missing required fields in message: {message}")
        return False

    with LogContext(logger, f"Processing enhanced retrieval for file {file_id}"):
        try:
            # Critical Check: Query analyze_id status → If "failed", skip processing
            can_continue, analyze_record = AnalyzeStatusChecker.check_analyze_status(
                analyze_id
            )
            if not can_continue:
                logger.info(
                    f"Skipping retrieval processing for failed analyze: {analyze_id}"
                )
                return True

            # Update file status to retrieval_processing
            if not update_file_status(file_id, analyze_id, "retrieval_processing"):
                logger.error(f"Failed to update file status to retrieval_processing")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to update file status", "retrieval"
                )
                return False

            # Retrieve analyze parameters (kpi_list, taxonomy)
            analyze_params = AnalyzeStatusChecker.get_analyze_parameters(analyze_id)
            if not analyze_params:
                logger.error(f"Failed to get analyze parameters for {analyze_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to get analyze parameters", "retrieval"
                )
                return False

            kpi_list = analyze_params.get("kpi_list", [])
            kpi_taxonomy = analyze_params.get("kpi_taxonomy", {})
            bank_id = analyze_params.get("bank_id", "")
            bank_is_french = analyze_params.get("bank_is_french", False)
            language = "fr" if bank_is_french else "en"

            if not kpi_list:
                logger.error(f"No KPIs specified for analyze {analyze_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "No KPIs specified", "retrieval"
                )
                return False

            # Get file info to determine document category
            file_record = get_item(
                EnvVars.KPI_FILE_STATUS_TABLE,
                {"file_id": file_id, "analyze_id": analyze_id},
            )
            document_category = (
                file_record.get("file_category", "default")
                if file_record
                else "default"
            )

            # Get context retrieval template from prompt store
            context_template = get_retrieval_prompt_template(
                bank_id, document_category, language
            )

            if not context_template:
                logger.warning(
                    f"No context retrieval template found, using enhanced queries without template"
                )

            # Get chunks with embeddings
            chunks = get_chunks_for_file(file_id)
            if not chunks:
                logger.error(f"No embedded chunks found for file {file_id}")
                update_file_status(
                    file_id,
                    analyze_id,
                    "failed",
                    {"error_message": "No embedded chunks found"},
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, f"No embedded chunks for file {file_id}", "retrieval"
                )
                return False

            # Generate enhanced KPI-specific queries using context template
            kpi_queries = generate_enhanced_kpi_queries(
                kpi_list, kpi_taxonomy, context_template, bank_id, language
            )

            if not kpi_queries:
                logger.error(f"Failed to generate KPI queries for file {file_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, f"Failed to generate KPI queries", "retrieval"
                )
                return False

            # Get appropriate embedding model
            model_id = EnvVars.get_embedding_model(bank_is_french)

            # Retrieve relevant context using enhanced hybrid retrieval strategy
            context = retrieve_relevant_context_per_kpi_enhanced(
                kpi_queries, chunks, model_id, EnvVars.PER_KPI_TOP_K, context_template
            )

            if not context:
                logger.error(f"Failed to retrieve context for file {file_id}")
                update_file_status(
                    file_id,
                    analyze_id,
                    "failed",
                    {"error_message": "Failed to retrieve context"},
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    f"Failed to retrieve context for file {file_id}",
                    "retrieval",
                )
                return False

            # Store results in kpi_retrieval_context
            if not store_retrieval_context(file_id, analyze_id, context):
                logger.error(f"Failed to store retrieval context for file {file_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    f"Failed to store context for file {file_id}",
                    "retrieval",
                )
                return False

            # Update file status to retrieval_complete
            retrieval_metadata = {
                "context_kpis": len(context.get("kpi_specific_context", {})),
                "unique_chunks": context.get("statistics", {}).get(
                    "total_unique_chunks", 0
                ),
                "cross_kpi_chunks": context.get("statistics", {}).get(
                    "cross_kpi_chunks", 0
                ),
                "model_used": model_id,
                "template_used": context_template is not None,
                "enhanced_retrieval": True,
            }

            if not update_file_status(
                file_id, analyze_id, "retrieval_complete", retrieval_metadata
            ):
                logger.error(f"Failed to update file status to retrieval_complete")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to update file status to complete", "retrieval"
                )
                return False

            # Send message to KPI generation queue
            if not notify_kpi_generation_queue(message, context.get("statistics", {})):
                logger.error(
                    f"Failed to notify KPI generation queue for file {file_id}"
                )
                return False

            logger.info(f"Successfully processed enhanced retrieval for file {file_id}")
            return True

        except Exception as e:
            logger.error(f"Error processing retrieval: {e}")
            update_file_status(file_id, analyze_id, "failed", {"error_message": str(e)})
            AnalyzeStatusChecker.mark_analyze_as_failed(
                analyze_id, f"Retrieval processing error: {str(e)}", "retrieval"
            )
            return False


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for enhanced retrieval processing with prompt store integration.

    Args:
        event: Lambda event
        context: Lambda context

    Returns:
        Dict[str, Any]: Response
    """
    logger.info(f"🚀 Starting Stage 4: Enhanced Retrieval Processing")
    logger.info(f"📥 Received event: {json.dumps(event)}")

    # Parse SQS messages
    messages = parse_sqs_message(event)
    if not messages:
        logger.warning("⚠️  No valid messages found")
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "No valid messages found"}),
        }

    logger.info(f"📋 Processing {len(messages)} messages")

    # Process each message
    results = []
    for i, message_data in enumerate(messages):
        logger.info(f"🔄 Processing message {i+1}/{len(messages)}")

        success = process_message(message_data)
        file_id = message_data["message"].get("file_id", "unknown")
        analyze_id = message_data["message"].get("analyze_id", "unknown")

        result = {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "success": success,
        }

        if success:
            logger.info(f"✅ Message {i+1} processed successfully: file {file_id}")
        else:
            logger.error(f"❌ Message {i+1} failed: file {file_id}")

        results.append(result)

    # Summary
    success_count = sum(1 for r in results if r["success"])
    failure_count = len(results) - success_count

    logger.info(f"📊 SUMMARY: {success_count} successful, {failure_count} failed")

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "message": "Stage 4 enhanced retrieval processing completed",
                "results": results,
                "summary": {
                    "total_processed": len(results),
                    "successful": success_count,
                    "failed": failure_count,
                },
            }
        ),
    }
