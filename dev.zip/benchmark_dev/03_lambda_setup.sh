#!/bin/bash
# Stage 2 Setup - Part 3: Lambda Functions and Integrations
# Creates Lambda functions and connects them to DynamoDB streams, SQS queues, and S3

STACK_NAME="benchmark-bs"
REGION="eu-west-3"
ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)
BUCKET_NAME="tmp-storage-benchmark"

print_status() {
  echo -e "\n== $1 =="
}

print_success() {
  echo -e "\n✅ $1"
}

print_error() {
  echo -e "\n❌ $1"
}

print_warning() {
  echo -e "\n⚠️  $1"
}

# Load queue URLs from previous script
QUEUE_URLS_FILE="/tmp/${STACK_NAME}-queue-urls.env"
if [ -f "$QUEUE_URLS_FILE" ]; then
  source "$QUEUE_URLS_FILE"
  print_success "Loaded queue URLs from $QUEUE_URLS_FILE"
else
  print_error "Queue URLs file not found. Run the SQS setup script first."
  exit 1
fi

# Verify required queue URLs are loaded
required_vars=("EMBEDDING_QUEUE_URL" "RETRIEVAL_QUEUE_URL" "KPI_QUEUE_URL" "OUTPUT_QUEUE_URL")
for var in "${required_vars[@]}"; do
  if [ -z "${!var}" ]; then
    print_error "Required variable $var is not set. Check the SQS setup."
    exit 1
  fi
done

print_status "Getting DynamoDB Stream ARNs..."

# Get stream ARNs
FILE_STATUS_STREAM_ARN=$(aws dynamodb describe-table \
  --table-name "${STACK_NAME}-kpi-file-status" \
  --query 'Table.LatestStreamArn' \
  --output text \
  --region $REGION 2>/dev/null)

KPI_RESPONSES_STREAM_ARN=$(aws dynamodb describe-table \
  --table-name "${STACK_NAME}-kpi-responses" \
  --query 'Table.LatestStreamArn' \
  --output text \
  --region $REGION)

if [ "$FILE_STATUS_STREAM_ARN" = "" ] || [ "$FILE_STATUS_STREAM_ARN" = "None" ]; then
  print_error "File status table stream not found. Ensure Stage 1 is completed with streams enabled."
  exit 1
fi

if [ "$KPI_RESPONSES_STREAM_ARN" = "" ] || [ "$KPI_RESPONSES_STREAM_ARN" = "None" ]; then
  print_error "KPI responses table stream not found. Run DynamoDB setup script first."
  exit 1
fi

print_success "Found DynamoDB streams:"
echo "  File Status Stream: $FILE_STATUS_STREAM_ARN"
echo "  KPI Responses Stream: $KPI_RESPONSES_STREAM_ARN"

print_status "Creating comprehensive IAM role for Lambda functions..."

# Create IAM role for Lambda functions
LAMBDA_ROLE_NAME="${STACK_NAME}-pipeline-lambda-role"

# Check if role already exists
if aws iam get-role --role-name "$LAMBDA_ROLE_NAME" --region $REGION >/dev/null 2>&1; then
  print_warning "IAM role $LAMBDA_ROLE_NAME already exists. Using existing role."
  LAMBDA_ROLE_ARN=$(aws iam get-role --role-name "$LAMBDA_ROLE_NAME" --query "Role.Arn" --output text)
else
  LAMBDA_ROLE_ARN=$(aws iam create-role \
    --role-name "$LAMBDA_ROLE_NAME" \
    --assume-role-policy-document '{
      "Version": "2012-10-17",
      "Statement": [{
        "Effect": "Allow",
        "Principal": {"Service": "lambda.amazonaws.com"},
        "Action": "sts:AssumeRole"
      }]
    }' \
    --query "Role.Arn" \
    --output text)
  
  print_success "Created IAM role: $LAMBDA_ROLE_ARN"
fi

# Attach basic Lambda execution policy
aws iam attach-role-policy \
  --role-name "$LAMBDA_ROLE_NAME" \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# Create comprehensive policy for all Lambda functions
LAMBDA_POLICY_DOC=$(cat << EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "dynamodb:GetItem",
                "dynamodb:PutItem",
                "dynamodb:UpdateItem",
                "dynamodb:DeleteItem",
                "dynamodb:Query",
                "dynamodb:Scan",
                "dynamodb:BatchGetItem",
                "dynamodb:BatchWriteItem",
                "dynamodb:DescribeTable",
                "dynamodb:DescribeStream",
                "dynamodb:GetRecords",
                "dynamodb:GetShardIterator",
                "dynamodb:ListStreams"
            ],
            "Resource": [
                "arn:aws:dynamodb:${REGION}:${ACCOUNT_ID}:table/${STACK_NAME}-*",
                "arn:aws:dynamodb:${REGION}:${ACCOUNT_ID}:table/${STACK_NAME}-*/index/*",
                "arn:aws:dynamodb:${REGION}:${ACCOUNT_ID}:table/${STACK_NAME}-*/stream/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "sqs:SendMessage",
                "sqs:ReceiveMessage",
                "sqs:DeleteMessage",
                "sqs:GetQueueAttributes",
                "sqs:GetQueueUrl"
            ],
            "Resource": [
                "arn:aws:sqs:${REGION}:${ACCOUNT_ID}:${STACK_NAME}-*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:GetObjectMetadata",
                "s3:PutObject",
                "s3:DeleteObject",
                "s3:HeadObject"
            ],
            "Resource": [
                "arn:aws:s3:::${STACK_NAME}-documents/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::${STACK_NAME}-documents"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModelWithResponseStream"
            ],
            "Resource": [
                "arn:aws:bedrock:${REGION}::foundation-model/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "sagemaker:InvokeEndpoint"
            ],
            "Resource": [
                "arn:aws:sagemaker:${REGION}:${ACCOUNT_ID}:endpoint/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Resource": "arn:aws:logs:${REGION}:${ACCOUNT_ID}:*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudwatch:PutMetricData"
            ],
            "Resource": "*"
        }
    ]
}
EOF
)

# Check if policy already exists
POLICY_NAME="${STACK_NAME}-pipeline-lambda-policy"
if aws iam get-policy --policy-arn "arn:aws:iam::${ACCOUNT_ID}:policy/${POLICY_NAME}" >/dev/null 2>&1; then
  print_warning "Policy $POLICY_NAME already exists. Using existing policy."
  LAMBDA_POLICY_ARN="arn:aws:iam::${ACCOUNT_ID}:policy/${POLICY_NAME}"
else
  LAMBDA_POLICY_ARN=$(aws iam create-policy \
    --policy-name "$POLICY_NAME" \
    --policy-document "$LAMBDA_POLICY_DOC" \
    --query "Policy.Arn" \
    --output text)
  
  print_success "Created Lambda policy: $LAMBDA_POLICY_ARN"
fi

# Attach policy to role
aws iam attach-role-policy \
  --role-name "$LAMBDA_ROLE_NAME" \
  --policy-arn "$LAMBDA_POLICY_ARN"

print_success "Attached policy to role"

# Wait for IAM propagation
print_status "Waiting for IAM role propagation..."
sleep 30

print_status "Creating Lambda functions..."

# 1. Status Handler Lambda
print_status "Creating Status Handler Lambda..."

STATUS_HANDLER_FUNCTION_NAME="${STACK_NAME}-status-handler"

# Check if function already exists
if aws lambda get-function --function-name "$STATUS_HANDLER_FUNCTION_NAME" --region $REGION >/dev/null 2>&1; then
  print_warning "Function $STATUS_HANDLER_FUNCTION_NAME already exists. Updating..."
  
  # Update function code
  aws lambda update-function-code \
    --function-name "$STATUS_HANDLER_FUNCTION_NAME" \
    --s3-bucket "$BUCKET_NAME" \
    --s3-key "status_handler.zip" \
    --region $REGION
  
  # Update environment variables
  aws lambda update-function-configuration \
    --function-name "$STATUS_HANDLER_FUNCTION_NAME" \
    --environment Variables="{\"EMBEDDING_QUEUE_URL\":\"${EMBEDDING_QUEUE_URL}\",\"RETRIEVAL_QUEUE_URL\":\"${RETRIEVAL_QUEUE_URL}\",\"KPI_QUEUE_URL\":\"${KPI_QUEUE_URL}\",\"OUTPUT_QUEUE_URL\":\"${OUTPUT_QUEUE_URL}\",\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\"}" \
    --region $REGION
  
  STATUS_HANDLER_FUNCTION_ARN=$(aws lambda get-function --function-name "$STATUS_HANDLER_FUNCTION_NAME" --query "Configuration.FunctionArn" --output text --region $REGION)
  
else
  STATUS_HANDLER_FUNCTION_ARN=$(aws lambda create-function \
    --function-name "$STATUS_HANDLER_FUNCTION_NAME" \
    --runtime python3.12 \
    --role "$LAMBDA_ROLE_ARN" \
    --handler lambda_function.handler \
    --code S3Bucket="$BUCKET_NAME",S3Key="status_handler.zip" \
    --environment Variables="{\"EMBEDDING_QUEUE_URL\":\"${EMBEDDING_QUEUE_URL}\",\"RETRIEVAL_QUEUE_URL\":\"${RETRIEVAL_QUEUE_URL}\",\"KPI_QUEUE_URL\":\"${KPI_QUEUE_URL}\",\"OUTPUT_QUEUE_URL\":\"${OUTPUT_QUEUE_URL}\",\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\"}" \
    --timeout 300 \
    --memory-size 1024 \
    --query "FunctionArn" \
    --output text \
    --region $REGION)
fi

print_success "Status Handler Lambda: $STATUS_HANDLER_FUNCTION_ARN"

# 2. Embedding Processor Lambda
print_status "Creating Embedding Processor Lambda..."

EMBEDDING_FUNCTION_NAME="${STACK_NAME}-embedding-processor"

if aws lambda get-function --function-name "$EMBEDDING_FUNCTION_NAME" --region $REGION >/dev/null 2>&1; then
  print_warning "Function $EMBEDDING_FUNCTION_NAME already exists. Updating..."
  
  aws lambda update-function-code \
    --function-name "$EMBEDDING_FUNCTION_NAME" \
    --s3-bucket "$BUCKET_NAME" \
    --s3-key "embedding_processor.zip" \
    --region $REGION
  
  aws lambda update-function-configuration \
    --function-name "$EMBEDDING_FUNCTION_NAME" \
    --environment Variables="{\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\",\"RETRIEVAL_QUEUE_URL\":\"${RETRIEVAL_QUEUE_URL}\"}" \
    --region $REGION
  
  EMBEDDING_FUNCTION_ARN=$(aws lambda get-function --function-name "$EMBEDDING_FUNCTION_NAME" --query "Configuration.FunctionArn" --output text --region $REGION)
  
else
  EMBEDDING_FUNCTION_ARN=$(aws lambda create-function \
    --function-name "$EMBEDDING_FUNCTION_NAME" \
    --runtime python3.12 \
    --role "$LAMBDA_ROLE_ARN" \
    --handler lambda_function.handler \
    --code S3Bucket="$BUCKET_NAME",S3Key="embedding_processor.zip" \
    --environment Variables="{\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\",\"RETRIEVAL_QUEUE_URL\":\"${RETRIEVAL_QUEUE_URL}\"}" \
    --timeout 900 \
    --memory-size 1024 \
    --query "FunctionArn" \
    --output text \
    --region $REGION)
fi

print_success "Embedding Processor Lambda: $EMBEDDING_FUNCTION_ARN"

# 3. Retrieval Processor Lambda
print_status "Creating Retrieval Processor Lambda..."

RETRIEVAL_FUNCTION_NAME="${STACK_NAME}-retrieval-processor"

if aws lambda get-function --function-name "$RETRIEVAL_FUNCTION_NAME" --region $REGION >/dev/null 2>&1; then
  print_warning "Function $RETRIEVAL_FUNCTION_NAME already exists. Updating..."
  
  aws lambda update-function-code \
    --function-name "$RETRIEVAL_FUNCTION_NAME" \
    --s3-bucket "$BUCKET_NAME" \
    --s3-key "retrieval_processor.zip" \
    --region $REGION
  
  aws lambda update-function-configuration \
    --function-name "$RETRIEVAL_FUNCTION_NAME" \
    --environment Variables="{\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\",\"KPI_QUEUE_URL\":\"${KPI_QUEUE_URL}\"}" \
    --region $REGION
  
  RETRIEVAL_FUNCTION_ARN=$(aws lambda get-function --function-name "$RETRIEVAL_FUNCTION_NAME" --query "Configuration.FunctionArn" --output text --region $REGION)
  
else
  RETRIEVAL_FUNCTION_ARN=$(aws lambda create-function \
    --function-name "$RETRIEVAL_FUNCTION_NAME" \
    --runtime python3.12 \
    --role "$LAMBDA_ROLE_ARN" \
    --handler lambda_function.handler \
    --code S3Bucket="$BUCKET_NAME",S3Key="retrieval_processor.zip" \
    --environment Variables="{\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\",\"KPI_QUEUE_URL\":\"${KPI_QUEUE_URL}\"}" \
    --timeout 900 \
    --memory-size 1024 \
    --query "FunctionArn" \
    --output text \
    --region $REGION)
fi

print_success "Retrieval Processor Lambda: $RETRIEVAL_FUNCTION_ARN"

# 4. KPI Generator Lambda
print_status "Creating KPI Generator Lambda..."

KPI_FUNCTION_NAME="${STACK_NAME}-kpi-generator"

if aws lambda get-function --function-name "$KPI_FUNCTION_NAME" --region $REGION >/dev/null 2>&1; then
  print_warning "Function $KPI_FUNCTION_NAME already exists. Updating..."
  
  aws lambda update-function-code \
    --function-name "$KPI_FUNCTION_NAME" \
    --s3-bucket "$BUCKET_NAME" \
    --s3-key "kpi_generator.zip" \
    --region $REGION
  
  aws lambda update-function-configuration \
    --function-name "$KPI_FUNCTION_NAME" \
    --environment Variables="{\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\"}" \
    --region $REGION
  
  KPI_FUNCTION_ARN=$(aws lambda get-function --function-name "$KPI_FUNCTION_NAME" --query "Configuration.FunctionArn" --output text --region $REGION)
  
else
  KPI_FUNCTION_ARN=$(aws lambda create-function \
    --function-name "$KPI_FUNCTION_NAME" \
    --runtime python3.12 \
    --role "$LAMBDA_ROLE_ARN" \
    --handler lambda_function.handler \
    --code S3Bucket="$BUCKET_NAME",S3Key="kpi_generator.zip" \
    --environment Variables="{\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\"}" \
    --timeout 900 \
    --memory-size 2048 \
    --query "FunctionArn" \
    --output text \
    --region $REGION)
fi

print_success "KPI Generator Lambda: $KPI_FUNCTION_ARN"

# 5. Output Generator Lambda
print_status "Creating Output Generator Lambda..."

OUTPUT_FUNCTION_NAME="${STACK_NAME}-output-generator"

if aws lambda get-function --function-name "$OUTPUT_FUNCTION_NAME" --region $REGION >/dev/null 2>&1; then
  print_warning "Function $OUTPUT_FUNCTION_NAME already exists. Updating..."
  
  aws lambda update-function-code \
    --function-name "$OUTPUT_FUNCTION_NAME" \
    --s3-bucket "$BUCKET_NAME" \
    --s3-key "output_generator.zip" \
    --region $REGION
  
  aws lambda update-function-configuration \
    --function-name "$OUTPUT_FUNCTION_NAME" \
    --environment Variables="{\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\"}" \
    --region $REGION
  
  OUTPUT_FUNCTION_ARN=$(aws lambda get-function --function-name "$OUTPUT_FUNCTION_NAME" --query "Configuration.FunctionArn" --output text --region $REGION)
  
else
  OUTPUT_FUNCTION_ARN=$(aws lambda create-function \
    --function-name "$OUTPUT_FUNCTION_NAME" \
    --runtime python3.12 \
    --role "$LAMBDA_ROLE_ARN" \
    --handler lambda_function.handler \
    --code S3Bucket="$BUCKET_NAME",S3Key="output_generator.zip" \
    --environment Variables="{\"STACK_NAME\":\"${STACK_NAME}\",\"REGION\":\"${REGION}\"}" \
    --timeout 600 \
    --memory-size 1024 \
    --query "FunctionArn" \
    --output text \
    --region $REGION)
fi

print_success "Output Generator Lambda: $OUTPUT_FUNCTION_ARN"

print_status "Setting up DynamoDB Stream triggers..."

# Function to add event source mapping with retry
add_event_source_mapping() {
  local function_name=$1
  local stream_arn=$2
  local filter_criteria=$3
  local max_attempts=3
  local attempt=1
  
  while [ $attempt -le $max_attempts ]; do
    echo "Attempt $attempt to add stream trigger for $function_name"
    
    # Check if mapping already exists
    existing_mappings=$(aws lambda list-event-source-mappings \
      --function-name "$function_name" \
      --event-source-arn "$stream_arn" \
      --query "EventSourceMappings[0].UUID" \
      --output text \
      --region $REGION 2>/dev/null)
    
    if [ "$existing_mappings" != "" ] && [ "$existing_mappings" != "None" ]; then
      print_warning "Event source mapping already exists for $function_name"
      return 0
    fi
    
    # Create the mapping
    if [ -n "$filter_criteria" ]; then
      aws lambda create-event-source-mapping \
        --event-source-arn "$stream_arn" \
        --function-name "$function_name" \
        --starting-position TRIM_HORIZON \
        --batch-size 10 \
        --maximum-batching-window-in-seconds 5 \
        --parallelization-factor 1 \
        --maximum-record-age-in-seconds 300 \
        --bisect-batch-on-function-error \
        --maximum-retry-attempts 3 \
        --filter-criteria "$filter_criteria" \
        --region $REGION >/dev/null 2>&1
    else
      aws lambda create-event-source-mapping \
        --event-source-arn "$stream_arn" \
        --function-name "$function_name" \
        --starting-position TRIM_HORIZON \
        --batch-size 10 \
        --maximum-batching-window-in-seconds 5 \
        --parallelization-factor 1 \
        --maximum-record-age-in-seconds 300 \
        --bisect-batch-on-function-error \
        --maximum-retry-attempts 3 \
        --region $REGION >/dev/null 2>&1
    fi
    
    if [ $? -eq 0 ]; then
      print_success "Added stream trigger for $function_name"
      return 0
    else
      print_error "Failed to add stream trigger for $function_name (attempt $attempt)"
      attempt=$((attempt + 1))
      sleep 5
    fi
  done
  
  print_error "Failed to add stream trigger for $function_name after $max_attempts attempts"
  return 1
}

# Add DynamoDB stream triggers for Status Handler
# File status changes trigger
add_event_source_mapping "$STATUS_HANDLER_FUNCTION_NAME" "$FILE_STATUS_STREAM_ARN" ""

# KPI responses completion trigger  
add_event_source_mapping "$STATUS_HANDLER_FUNCTION_NAME" "$KPI_RESPONSES_STREAM_ARN" ""

print_status "Setting up SQS triggers for Lambda functions..."

# Function to add SQS trigger with retry
add_sqs_trigger() {
  local function_name=$1
  local queue_url=$2
  local batch_size=${3:-10}
  local max_attempts=3
  local attempt=1
  
  # Get queue ARN from URL
  local queue_arn=$(aws sqs get-queue-attributes \
    --queue-url "$queue_url" \
    --attribute-names QueueArn \
    --query "Attributes.QueueArn" \
    --output text \
    --region $REGION)
  
  while [ $attempt -le $max_attempts ]; do
    echo "Attempt $attempt to add SQS trigger for $function_name"
    
    # Check if mapping already exists
    existing_mappings=$(aws lambda list-event-source-mappings \
      --function-name "$function_name" \
      --event-source-arn "$queue_arn" \
      --query "EventSourceMappings[0].UUID" \
      --output text \
      --region $REGION 2>/dev/null)
    
    if [ "$existing_mappings" != "" ] && [ "$existing_mappings" != "None" ]; then
      print_warning "SQS trigger already exists for $function_name"
      return 0
    fi
    
    # Create the mapping
    aws lambda create-event-source-mapping \
      --event-source-arn "$queue_arn" \
      --function-name "$function_name" \
      --batch-size $batch_size \
      --maximum-batching-window-in-seconds 5 \
      --region $REGION >/dev/null 2>&1
    
    if [ $? -eq 0 ]; then
      print_success "Added SQS trigger for $function_name"
      return 0
    else
      print_error "Failed to add SQS trigger for $function_name (attempt $attempt)"
      attempt=$((attempt + 1))
      sleep 5
    fi
  done
  
  print_error "Failed to add SQS trigger for $function_name after $max_attempts attempts"
  return 1
}

# Add SQS triggers for each processor
add_sqs_trigger "$EMBEDDING_FUNCTION_NAME" "$EMBEDDING_QUEUE_URL" 5
add_sqs_trigger "$RETRIEVAL_FUNCTION_NAME" "$RETRIEVAL_QUEUE_URL" 5  
add_sqs_trigger "$KPI_FUNCTION_NAME" "$KPI_QUEUE_URL" 3
add_sqs_trigger "$OUTPUT_FUNCTION_NAME" "$OUTPUT_QUEUE_URL" 1

print_status "Verifying Lambda function configurations..."

# Verify all functions exist and are properly configured
functions=(
  "$STATUS_HANDLER_FUNCTION_NAME"
  "$EMBEDDING_FUNCTION_NAME"
  "$RETRIEVAL_FUNCTION_NAME"
  "$KPI_FUNCTION_NAME"
  "$OUTPUT_FUNCTION_NAME"
)

all_functions_ok=true
for func in "${functions[@]}"; do
  if aws lambda get-function --function-name "$func" --region $REGION >/dev/null 2>&1; then
    state=$(aws lambda get-function --function-name "$func" --query "Configuration.State" --output text --region $REGION)
    if [ "$state" = "Active" ]; then
      print_success "✓ $func is active and ready"
    else
      print_warning "⚠ $func state: $state"
    fi
  else
    print_error "✗ $func not found"
    all_functions_ok=false
  fi
done

# Save deployment info
DEPLOYMENT_INFO_FILE="/tmp/${STACK_NAME}-lambda-deployment.env"
cat > "$DEPLOYMENT_INFO_FILE" << EOF
STATUS_HANDLER_FUNCTION_ARN="$STATUS_HANDLER_FUNCTION_ARN"
EMBEDDING_FUNCTION_ARN="$EMBEDDING_FUNCTION_ARN"
RETRIEVAL_FUNCTION_ARN="$RETRIEVAL_FUNCTION_ARN"
KPI_FUNCTION_ARN="$KPI_FUNCTION_ARN"
OUTPUT_FUNCTION_ARN="$OUTPUT_FUNCTION_ARN"
LAMBDA_ROLE_ARN="$LAMBDA_ROLE_ARN"
FILE_STATUS_STREAM_ARN="$FILE_STATUS_STREAM_ARN"
KPI_RESPONSES_STREAM_ARN="$KPI_RESPONSES_STREAM_ARN"
EOF

print_status "Lambda Functions and Integrations Summary"
echo ""
echo "Created Lambda Functions:"
echo "  1. Status Handler: $STATUS_HANDLER_FUNCTION_NAME"
echo "     - Listens to: File Status + KPI Responses streams"
echo "     - Sends to: All processing queues"
echo ""
echo "  2. Embedding Processor: $EMBEDDING_FUNCTION_NAME"
echo "     - Triggered by: Embedding Queue"
echo "     - Sends to: Retrieval Queue"
echo ""
echo "  3. Retrieval Processor: $RETRIEVAL_FUNCTION_NAME"
echo "     - Triggered by: Retrieval Queue"
echo "     - Sends to: KPI Queue"
echo ""
echo "  4. KPI Generator: $KPI_FUNCTION_NAME"
echo "     - Triggered by: KPI Queue"
echo "     - Stores: KPI Responses (triggers completion check)"
echo ""
echo "  5. Output Generator: $OUTPUT_FUNCTION_NAME"
echo "     - Triggered by: Output Queue"
echo "     - Stores: Final results in S3"
echo ""
echo "IAM Role: $LAMBDA_ROLE_ARN"
echo "Deployment info saved to: $DEPLOYMENT_INFO_FILE"

if [ "$all_functions_ok" = true ]; then
  print_success "All Lambda functions and integrations set up successfully!"
  echo ""
  echo "🎉 Stage 2 setup is complete! The KPI extraction pipeline is ready."
  echo ""
  echo "Next steps:"
  echo "1. Upload your Lambda function code (.zip files) to S3 bucket: $BUCKET_NAME"
  echo "2. Test the pipeline by uploading documents to: ${STACK_NAME}-documents/input/"
  echo "3. Monitor progress in CloudWatch logs and DynamoDB tables"
  exit 0
else
  print_error "Some functions failed to set up properly. Check the output above."
  exit 1
fi
