import boto3
import os
import uuid
import json
from datetime import datetime

def upload_excel_to_s3(
    file_path="./data/serie_trim_1.xlsx", 
    stack_name="benchmark-sb",
    bank_is_french=True,
    kpi_list=["Net Income", "Revenue", "ROE", "Cost Income Ratio", "Tier 1 Ratio"],
    taxonomy={
        "Net Income": ["Net Profit", "Profit After Tax", "Net Earnings", "Bottom Line"],
        "Revenue": ["Turnover", "Sales", "Income", "Top Line"],
        "ROE": ["Return on Equity", "Return on Shareholders' Equity", "Equity Returns"],
        "Cost Income Ratio": ["Cost to Income", "Efficiency Ratio", "C/I Ratio", "Cost-to-Income"],
        "Tier 1 Ratio": ["Core Tier 1", "CET1 Ratio", "Common Equity Tier 1"]
    },
    kpi_detail_levels={
        "ROE": ["Group", "Retail Banking", "Corporate Banking", "Insurance"],
        "Revenue": ["Group", "Domestic Markets", "International Markets", "CIB"],
        "Net Income": ["Group", "Attributable to shareholders", "Minority interests"],
        "Cost Income Ratio": ["Group", "Retail Banking", "Wealth Management"]
    },
    bank_id="BNP001",
    file_category="serie_trimestrielle"
):
    """
    Uploads an Excel file to the specified S3 bucket with all required metadata.
    
    Args:
        file_path: Path to the local Excel file
        stack_name: Name of the stack (used to construct bucket name)
        bank_is_french: Boolean indicating if the bank is French
        kpi_list: List of KPIs to extract
        taxonomy: Dictionary of KPI synonyms
        kpi_detail_levels: Hierarchy of KPI levels
        bank_id: Unique identifier for the bank
        file_category: Category of the financial document
        
    Returns:
        Dictionary containing upload details if successful
    """
    # Validate file exists
    if not os.path.exists(file_path):
        print(f"Error: File {file_path} does not exist")
        return None
    
    # Initialize S3 client
    s3_client = boto3.client('s3')
    bucket_name = f"{stack_name}-documents"
    
    # Generate analyze_id and file_id
    analyze_id = "15e5bc33-e687-4649-8fb4-e00e603b81a8" # str(uuid.uuid4())
    file_id = "33aa7932-43a3-4e2b-b0ed-5dabb7ef3874" # str(uuid.uuid4())
    
    # Extract file name from path
    file_name = os.path.basename(file_path)
    
    # Define the S3 key (path in the bucket)
    s3_key = f"input/{analyze_id}/{file_id}/{file_name}"
    
    try:
        # Convert complex metadata to JSON strings since S3 metadata only accepts strings
        metadata = {
            'analyze_id': analyze_id,
            'file_id': file_id,
            'file_name': file_name,
            'file_category': file_category,
            'bank_is_french': str(bank_is_french).lower(),
            'bank_id': bank_id,
            'kpi_list': json.dumps(kpi_list),
            'taxonomy': json.dumps(taxonomy),
            'kpi_detail_levels': json.dumps(kpi_detail_levels),
            'upload_timestamp': datetime.utcnow().isoformat()
        }
        
        # Upload file to S3
        with open(file_path, 'rb') as file_data:
            s3_client.upload_fileobj(
                file_data,
                bucket_name,
                s3_key,
                ExtraArgs={
                    'Metadata': metadata
                }
            )
        
        # Return upload information
        result = {
            'success': True,
            'bucket_name': bucket_name,
            'file_name': file_name,
            'analyze_id': analyze_id,
            'file_id': file_id,
            's3_key': s3_key,
            's3_uri': f"s3://{bucket_name}/{s3_key}",
            'metadata': metadata
        }
        
        print(f"Successfully uploaded {file_name} to {bucket_name}")
        print(f"S3 URI: s3://{bucket_name}/{s3_key}")
        print(f"Analyze ID: {analyze_id}")
        print(f"File ID: {file_id}")
        
        return result
        
    except Exception as e:
        print(f"Error uploading file to S3: {str(e)}")
        return {
            'success': False,
            'error': str(e)
        }
    


# Example usage
if __name__ == "__main__":
    upload_excel_to_s3()