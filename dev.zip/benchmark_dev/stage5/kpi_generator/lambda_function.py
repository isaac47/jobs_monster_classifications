import json
import time
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import boto3
from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.analyze_status_checker import AnalyzeStatusChecker
from common.utils.dynamodb_utils import get_item, put_item, update_item
from common.utils.logger import LogContext, get_logger
from common.utils.sqs_utils import get_queue_url, send_message

logger = get_logger(__name__)


def parse_sqs_message(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Parse SQS messages from the event.

    Args:
        event: Lambda event

    Returns:
        List[Dict[str, Any]]: List of parsed messages
    """
    messages = []

    for record in event.get("Records", []):
        if record.get("eventSource") != "aws:sqs":
            continue

        body = record.get("body")
        if not body:
            continue

        try:
            message = json.loads(body)
            messages.append(
                {"message": message, "receipt_handle": record.get("receiptHandle")}
            )
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing message body: {e}")

    return messages


def update_file_status(
    file_id: str,
    analyze_id: str,
    status: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """
    Update file status in KPI file status table.

    Args:
        file_id: File identifier
        analyze_id: Analyze identifier
        status: New status
        metadata: Optional additional metadata

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        update_expression = """
        SET #status = :status,
            updated_at = :updated_at
        """

        expression_values = {
            ":status": status,
            ":updated_at": datetime.now(timezone.utc).isoformat(),
        }

        expression_names = {"#status": "status"}

        # Add additional metadata if provided
        if metadata:
            for key, value in metadata.items():
                safe_key = key.replace("-", "_").replace(".", "_")
                update_expression += f", {safe_key} = :{safe_key}"
                expression_values[f":{safe_key}"] = value

        return update_item(
            EnvVars.KPI_FILE_STATUS_TABLE,
            {"file_id": file_id, "analyze_id": analyze_id},
            update_expression,
            expression_values,
            expression_names,
        )

    except Exception as e:
        logger.error(f"Error updating file status: {e}")
        return False


def get_retrieval_context(file_id: str, analyze_id: str) -> Optional[Dict[str, Any]]:
    """
    Retrieve context chunks from kpi_retrieval_context table.

    Args:
        file_id: File identifier
        analyze_id: Analyze identifier

    Returns:
        Optional[Dict[str, Any]]: Context data or None if not found
    """
    try:
        context_record = get_item(
            EnvVars.KPI_RETRIEVAL_CONTEXT_TABLE,
            {"file_id": file_id, "analyze_id": analyze_id},
        )

        if context_record and "context" in context_record:
            logger.info(f"Retrieved context for file {file_id}")
            return context_record["context"]
        else:
            logger.warning(f"No context found for file {file_id}")
            return None

    except Exception as e:
        logger.error(f"Error retrieving context: {e}")
        return None


def get_prompt_template_for_kpi_extraction(
    bank_id: str, document_category: str, file_category: str = None
) -> Optional[str]:
    """
    Get prompt template specifically for KPI extraction.

    Args:
        bank_id: Bank identifier
        document_category: Document category
        file_category: Specific file category (optional)

    Returns:
        Optional[str]: Prompt template or None if not found
    """
    try:
        # Try file category specific first
        if file_category:
            prompt_item = get_item(
                EnvVars.PROMPT_STORE_TABLE,
                {
                    "bank_id": bank_id,
                    "document_category": f"{document_category}_{file_category}",
                },
            )
            if prompt_item and "kpi_extraction_template" in prompt_item:
                return prompt_item["kpi_extraction_template"]

        # Try document category specific
        prompt_item = get_item(
            EnvVars.PROMPT_STORE_TABLE,
            {"bank_id": bank_id, "document_category": document_category},
        )
        if prompt_item and "kpi_extraction_template" in prompt_item:
            return prompt_item["kpi_extraction_template"]

        # Try bank default
        bank_default = get_item(
            EnvVars.PROMPT_STORE_TABLE,
            {"bank_id": bank_id, "document_category": "kpi_extraction_default"},
        )
        if bank_default and "kpi_extraction_template" in bank_default:
            return bank_default["kpi_extraction_template"]

        # Try global default
        global_default = get_item(
            EnvVars.PROMPT_STORE_TABLE,
            {"bank_id": "default", "document_category": "kpi_extraction_default"},
        )
        if global_default and "kpi_extraction_template" in global_default:
            return global_default["kpi_extraction_template"]

        return None

    except Exception as e:
        logger.error(f"Error retrieving KPI extraction prompt: {e}")
        return None


def construct_kpi_extraction_prompt(
    context: Dict[str, Any],
    analyze_params: Dict[str, Any],
    prompt_template: str,
    file_category: str = None,
) -> str:
    """
    Construct comprehensive prompt for KPI extraction.

    Args:
        context: Retrieved context with KPI-specific chunks
        analyze_params: Analyze parameters including KPI list and taxonomy
        prompt_template: Base prompt template
        file_category: File category for context

    Returns:
        str: Complete prompt for LLM
    """
    try:
        kpi_list = analyze_params.get("kpi_list", [])
        kpi_taxonomy = analyze_params.get("kpi_taxonomy", {})
        bank_is_french = analyze_params.get("bank_is_french", False)
        detail_level = analyze_params.get("detail_level", "")

        # Start with base template
        prompt_parts = [prompt_template]

        # Add file category context if available
        if file_category:
            prompt_parts.append(f"\n## Document Type: {file_category}")

        # Add KPI definitions and expected formats
        prompt_parts.append("\n## KPIs to Extract:")
        for kpi in kpi_list:
            kpi_info = kpi_taxonomy.get(kpi, {})
            kpi_def = f"- **{kpi}**"

            if kpi_info.get("synonyms"):
                kpi_def += f" (also: {', '.join(kpi_info['synonyms'])})"

            if kpi_info.get("category"):
                kpi_def += f" - Category: {kpi_info['category']}"

            if kpi_info.get("priority"):
                kpi_def += f" - Priority: {kpi_info['priority']}"

            if kpi_info.get("expected_format"):
                kpi_def += f" - Format: {kpi_info['expected_format']}"

            prompt_parts.append(kpi_def)

        # Add detail level context
        if detail_level:
            prompt_parts.append(f"\n## Detail Level: {detail_level}")

        # Add language-specific examples
        if bank_is_french:
            prompt_parts.append(
                """
## Exemples (French Bank):
- "Chiffre d'affaires" → revenue
- "Résultat net" → net_income
- "Bénéfice par action" → eps"""
            )
        else:
            prompt_parts.append(
                """
## Examples (English):
- "Total revenue" → revenue
- "Net income" → net_income
- "Earnings per share" → eps"""
            )

        # Add context chunks
        prompt_parts.append("\n## Document Context:")

        # Add KPI-specific context
        if "kpi_specific_context" in context:
            for kpi, kpi_context in context["kpi_specific_context"].items():
                if kpi_context.get("chunks"):
                    prompt_parts.append(f"\n### Context for {kpi}:")
                    for i, chunk in enumerate(
                        kpi_context["chunks"][:3]
                    ):  # Limit to top 3 chunks per KPI
                        chunk_text = chunk.get("text", "")[:500]  # Limit chunk size
                        prompt_parts.append(f"Chunk {i+1}: {chunk_text}")

        # Add overall context
        if "overall_context" in context and context["overall_context"].get("chunks"):
            prompt_parts.append("\n### Additional Context:")
            for i, chunk in enumerate(
                context["overall_context"]["chunks"][:2]
            ):  # Limit to top 2 overall chunks
                chunk_text = chunk.get("text", "")[:500]
                prompt_parts.append(f"Context {i+1}: {chunk_text}")

        # Add output schema specification
        output_schema = {
            "kpi_extractions": [
                {
                    "kpi_name": "string (must match one from KPI list)",
                    "value": "string or number",
                    "unit": "string (e.g., ', '%', 'millions')",
                    "period": "string (e.g., 'Q3 2023', '2023')",
                    "confidence_score": "float (0.0-1.0)",
                    "source_text": "string (exact text from document)",
                    "detail_level": "string (matches requested detail level)",
                    "metadata": {
                        "page_reference": "string",
                        "section": "string",
                        "calculation_method": "string (if applicable)",
                    },
                }
            ],
            "processing_metadata": {
                "total_kpis_requested": "number",
                "kpis_found": "number",
                "confidence_average": "float",
                "processing_notes": "string",
            },
        }

        prompt_parts.append(
            f"""
## Output Format:
Please extract the requested KPIs and return them in the following JSON format:
{json.dumps(output_schema, indent=2)}

## Instructions:
1. Extract only the KPIs listed above
2. Provide exact values with appropriate units
3. Include confidence scores based on clarity of information
4. Reference the source text where each KPI was found
5. If a KPI is not found, do not include it in the output
6. Ensure all KPI names exactly match those in the requested list
7. Be precise with numerical values and units
"""
        )

        final_prompt = "\n".join(prompt_parts)

        # Log prompt size for monitoring
        logger.info(
            f"Constructed prompt with {len(final_prompt)} characters for {len(kpi_list)} KPIs"
        )

        return final_prompt

    except Exception as e:
        logger.error(f"Error constructing KPI extraction prompt: {e}")
        raise


def call_bedrock_llm(
    prompt: str, model_id: str, max_retries: int = 3
) -> Optional[Dict[str, Any]]:
    """
    Call Bedrock LLM API with structured prompt and retry logic.

    Args:
        prompt: Complete prompt for KPI extraction
        model_id: Bedrock model ID
        max_retries: Maximum number of retry attempts

    Returns:
        Optional[Dict[str, Any]]: LLM response or None if failed
    """
    try:
        bedrock_runtime = boto3.client(
            service_name="bedrock-runtime", region_name=EnvVars.BEDROCK_REGION
        )

        for attempt in range(max_retries):
            try:
                # Prepare request based on model
                if model_id.startswith("anthropic.claude"):
                    if "claude-3" in model_id or "claude-4" in model_id:
                        # New Claude 3/4 format
                        request_body = {
                            "anthropic_version": "bedrock-2023-05-31",
                            "messages": [{"role": "user", "content": prompt}],
                            "max_tokens": 4000,
                            "temperature": 0.1,
                            "top_p": 0.9,
                        }
                    else:
                        # Legacy Claude format
                        request_body = {
                            "prompt": f"\n\nHuman: {prompt}\n\nAssistant:",
                            "max_tokens": 4000,
                            "temperature": 0.1,
                            "top_p": 0.9,
                            "stop_sequences": ["\n\nHuman:"],
                        }
                else:
                    # Generic format for other models
                    request_body = {
                        "prompt": prompt,
                        "max_tokens": 4000,
                        "temperature": 0.1,
                    }

                response = bedrock_runtime.invoke_model(
                    modelId=model_id,
                    contentType="application/json",
                    accept="application/json",
                    body=json.dumps(request_body),
                )

                response_body = json.loads(response.get("body").read())

                # Extract response text based on model
                if model_id.startswith("anthropic.claude"):
                    if "claude-3" in model_id or "claude-4" in model_id:
                        # New Claude 3/4 format
                        content = response_body.get("content", [])
                        response_text = content[0].get("text", "") if content else ""
                    else:
                        # Legacy Claude format
                        response_text = response_body.get("completion", "")
                else:
                    # Handle other model response formats
                    response_text = response_body.get(
                        "text", response_body.get("completion", "")
                    )

                logger.info(f"LLM response received on attempt {attempt + 1}")
                return {
                    "response_text": response_text.strip(),
                    "model_id": model_id,
                    "attempt": attempt + 1,
                    "usage": response_body.get("usage", {}),
                    "raw_response": response_body,
                }

            except Exception as e:
                logger.warning(f"LLM API attempt {attempt + 1} failed: {e}")
                if attempt < max_retries - 1:
                    # Exponential backoff
                    wait_time = (2**attempt) + 1
                    logger.info(f"Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"All {max_retries} attempts failed for LLM API call")
                    raise

        return None

    except Exception as e:
        logger.error(f"Error calling Bedrock LLM: {e}")
        return None


def parse_and_validate_llm_response(
    llm_response: Dict[str, Any], expected_kpis: List[str], detail_level: str = ""
) -> Tuple[bool, Optional[Dict[str, Any]], List[str]]:
    """
    Parse and validate LLM response.

    Args:
        llm_response: Response from LLM
        expected_kpis: List of expected KPI names
        detail_level: Expected detail level

    Returns:
        Tuple[bool, Optional[Dict[str, Any]], List[str]]: (is_valid, parsed_data, errors)
    """
    try:
        response_text = llm_response.get("response_text", "")
        errors = []

        # Try to extract JSON from response
        json_start = response_text.find("{")
        json_end = response_text.rfind("}") + 1

        if json_start == -1 or json_end == 0:
            errors.append("No JSON found in LLM response")
            return False, None, errors

        json_text = response_text[json_start:json_end]

        try:
            parsed_response = json.loads(json_text)
        except json.JSONDecodeError as e:
            errors.append(f"Invalid JSON in LLM response: {e}")
            # Try to fix common JSON issues
            try:
                # Remove trailing commas and fix common issues
                fixed_json = json_text.replace(",}", "}").replace(",]", "]")
                parsed_response = json.loads(fixed_json)
                logger.info("Fixed JSON parsing issues")
            except:
                return False, None, errors

        # Validate schema compliance
        if "kpi_extractions" not in parsed_response:
            errors.append("Missing 'kpi_extractions' field")
            return False, None, errors

        kpi_extractions = parsed_response["kpi_extractions"]
        if not isinstance(kpi_extractions, list):
            errors.append("'kpi_extractions' must be a list")
            return False, None, errors

        # Validate each KPI extraction
        valid_extractions = []
        for i, extraction in enumerate(kpi_extractions):
            extraction_errors = []

            # Required fields
            required_fields = ["kpi_name", "value", "confidence_score"]
            for field in required_fields:
                if field not in extraction:
                    extraction_errors.append(f"Missing required field: {field}")

            # Validate KPI name
            kpi_name = extraction.get("kpi_name", "")
            if kpi_name not in expected_kpis:
                extraction_errors.append(
                    f"Invalid KPI name: {kpi_name} (expected one of: {expected_kpis})"
                )

            # Validate confidence score
            confidence = extraction.get("confidence_score")
            if confidence is not None:
                try:
                    confidence_float = float(confidence)
                    if not (0.0 <= confidence_float <= 1.0):
                        extraction_errors.append(
                            f"Confidence score must be between 0.0 and 1.0, got: {confidence}"
                        )
                    extraction["confidence_score"] = confidence_float
                except (ValueError, TypeError):
                    extraction_errors.append(
                        f"Invalid confidence score format: {confidence}"
                    )

            # Validate detail level if specified
            if detail_level and extraction.get("detail_level"):
                if extraction["detail_level"] != detail_level:
                    extraction_errors.append(
                        f"Detail level mismatch: expected {detail_level}, got {extraction['detail_level']}"
                    )

            # Validate value is not empty
            value = extraction.get("value")
            if value is None or str(value).strip() == "":
                extraction_errors.append("Value cannot be empty")

            if extraction_errors:
                errors.extend([f"Extraction {i+1}: {err}" for err in extraction_errors])
            else:
                valid_extractions.append(extraction)

        # Update the response with only valid extractions
        parsed_response["kpi_extractions"] = valid_extractions

        # Add processing metadata if missing
        if "processing_metadata" not in parsed_response:
            parsed_response["processing_metadata"] = {
                "total_kpis_requested": len(expected_kpis),
                "kpis_found": len(valid_extractions),
                "confidence_average": (
                    sum(ext.get("confidence_score", 0) for ext in valid_extractions)
                    / len(valid_extractions)
                    if valid_extractions
                    else 0
                ),
                "processing_notes": f"Validated {len(valid_extractions)} of {len(kpi_extractions)} extractions",
            }

        is_valid = len(errors) == 0 and len(valid_extractions) > 0

        logger.info(
            f"Validation result: {len(valid_extractions)} valid extractions, {len(errors)} errors"
        )

        return is_valid, parsed_response, errors

    except Exception as e:
        logger.error(f"Error parsing LLM response: {e}")
        return False, None, [f"Parsing error: {str(e)}"]


def store_kpi_response(
    file_id: str,
    analyze_id: str,
    raw_response: Dict[str, Any],
    parsed_response: Dict[str, Any],
    validation_errors: List[str] = None,
) -> bool:
    """
    Store raw and parsed responses in kpi_responses table.

    Args:
        file_id: File identifier
        analyze_id: Analyze identifier
        raw_response: Raw LLM response
        parsed_response: Parsed and validated response
        validation_errors: Any validation errors

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        response_record = {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "raw_response": raw_response,
            "parsed_response": parsed_response,
            "validation_errors": validation_errors or [],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "response_type": "kpi_extraction",
        }

        success = put_item(EnvVars.KPI_RESPONSES_TABLE, response_record)

        if success:
            kpi_count = len(parsed_response.get("kpi_extractions", []))
            logger.info(
                f"Stored KPI response for file {file_id} with {kpi_count} extractions"
            )
        else:
            logger.error(f"Failed to store KPI response for file {file_id}")

        return success

    except Exception as e:
        logger.error(f"Error storing KPI response: {e}")
        return False


def process_message(message_data: Dict[str, Any]) -> bool:
    """
    Process a message from the queue.

    Args:
        message_data: Message data

    Returns:
        bool: True if successful, False otherwise
    """
    message = message_data["message"]

    file_id = message.get("file_id")
    analyze_id = message.get("analyze_id")

    if not file_id or not analyze_id:
        logger.error(f"Missing required fields in message: {message}")
        return False

    with LogContext(logger, f"Processing KPI extraction for file {file_id}"):
        try:
            # Critical Check: Query analyze_id status → If "failed", skip processing and stop
            can_continue, analyze_record = AnalyzeStatusChecker.check_analyze_status(
                analyze_id
            )
            if not can_continue:
                logger.info(f"Skipping KPI processing for failed analyze: {analyze_id}")
                return True

            # Update file status to "kpi_processing"
            if not update_file_status(file_id, analyze_id, "kpi_processing"):
                logger.error(f"Failed to update file status to kpi_processing")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to update file status", "kpi_generation"
                )
                return False

            # Retrieve context chunks from kpi_retrieval_context table
            context = get_retrieval_context(file_id, analyze_id)
            if not context:
                logger.error(f"No retrieval context found for file {file_id}")
                update_file_status(
                    file_id,
                    analyze_id,
                    "failed",
                    {"error_message": "No retrieval context"},
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    f"No retrieval context for file {file_id}",
                    "kpi_generation",
                )
                return False

            # Retrieve original parameters and metadata from kpi_analyze_status table
            analyze_params = AnalyzeStatusChecker.get_analyze_parameters(analyze_id)
            if not analyze_params:
                logger.error(f"Failed to get analyze parameters for {analyze_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to get analyze parameters", "kpi_generation"
                )
                return False

            # Get file category for context
            file_record = get_item(
                EnvVars.KPI_FILE_STATUS_TABLE,
                {"file_id": file_id, "analyze_id": analyze_id},
            )
            file_category = (
                file_record.get("file_category", "default")
                if file_record
                else "default"
            )

            # Retrieve prompt template from DynamoDB prompt store
            bank_id = analyze_params.get("bank_id", "")
            prompt_template = get_prompt_template_for_kpi_extraction(
                bank_id, "kpi_extraction", file_category
            )

            if not prompt_template:
                logger.warning(f"No KPI extraction prompt found, using default")
                prompt_template = """Extract the requested KPIs from the provided financial document context. 
Be precise with values and include confidence scores for each extraction."""

            # Construct comprehensive prompt
            try:
                complete_prompt = construct_kpi_extraction_prompt(
                    context, analyze_params, prompt_template, file_category
                )
            except Exception as e:
                logger.error(f"Failed to construct prompt: {e}")
                update_file_status(
                    file_id,
                    analyze_id,
                    "failed",
                    {"error_message": "Prompt construction failed"},
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    f"Prompt construction failed: {str(e)}",
                    "kpi_generation",
                )
                return False

            # Call Bedrock LLM API (Claude 3) with structured prompt
            model_id = EnvVars.BEDROCK_LLM_MODEL
            llm_response = call_bedrock_llm(complete_prompt, model_id)

            if not llm_response:
                logger.error(f"Failed to get LLM response for file {file_id}")
                update_file_status(
                    file_id, analyze_id, "failed", {"error_message": "LLM API failed"}
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, f"LLM API failed for file {file_id}", "kpi_generation"
                )
                return False

            # Parse and validate LLM response
            kpi_list = analyze_params.get("kpi_list", [])
            detail_level = analyze_params.get("detail_level", "")

            is_valid, parsed_response, validation_errors = (
                parse_and_validate_llm_response(llm_response, kpi_list, detail_level)
            )

            if not is_valid:
                logger.error(f"LLM response validation failed: {validation_errors}")
                update_file_status(
                    file_id,
                    analyze_id,
                    "failed",
                    {"error_message": "Response validation failed"},
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    f"Response validation failed: {validation_errors}",
                    "kpi_generation",
                )
                return False

            # Store raw and parsed responses in kpi_responses table
            if not store_kpi_response(
                file_id, analyze_id, llm_response, parsed_response, validation_errors
            ):
                logger.error(f"Failed to store KPI response for file {file_id}")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    f"Failed to store KPI response for file {file_id}",
                    "kpi_generation",
                )
                return False

            # Update file status to "kpi_complete"
            kpi_metadata = {
                "kpis_extracted": len(parsed_response.get("kpi_extractions", [])),
                "confidence_average": parsed_response.get(
                    "processing_metadata", {}
                ).get("confidence_average", 0),
                "model_used": model_id,
                "validation_errors_count": (
                    len(validation_errors) if validation_errors else 0
                ),
            }

            if not update_file_status(
                file_id, analyze_id, "kpi_complete", kpi_metadata
            ):
                logger.error(f"Failed to update file status to kpi_complete")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    "Failed to update file status to complete",
                    "kpi_generation",
                )
                return False

            logger.info(f"Successfully processed KPI extraction for file {file_id}")
            return True

        except Exception as e:
            logger.error(f"Error processing KPI extraction: {e}")
            logger.error(f"Stack trace: {traceback.format_exc()}")
            update_file_status(file_id, analyze_id, "failed", {"error_message": str(e)})
            AnalyzeStatusChecker.mark_analyze_as_failed(
                analyze_id, f"KPI processing error: {str(e)}", "kpi_generation"
            )
            return False


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for KPI response generation.

    Args:
        event: Lambda event
        context: Lambda context

    Returns:
        Dict[str, Any]: Response
    """
    logger.info(f"🚀 Starting Stage 5: KPI Generation")
    logger.info(f"📥 Received event: {json.dumps(event)}")

    # Parse SQS messages
    messages = parse_sqs_message(event)
    if not messages:
        logger.warning("⚠️  No valid messages found")
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "No valid messages found"}),
        }

    logger.info(f"📋 Processing {len(messages)} messages")

    # Process each message
    results = []
    for i, message_data in enumerate(messages):
        logger.info(f"🔄 Processing message {i+1}/{len(messages)}")

        success = process_message(message_data)
        file_id = message_data["message"].get("file_id", "unknown")
        analyze_id = message_data["message"].get("analyze_id", "unknown")

        result = {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "success": success,
        }

        if success:
            logger.info(f"✅ Message {i+1} processed successfully: file {file_id}")
        else:
            logger.error(f"❌ Message {i+1} failed: file {file_id}")

        results.append(result)

    # Summary
    success_count = sum(1 for r in results if r["success"])
    failure_count = len(results) - success_count

    logger.info(f"📊 SUMMARY: {success_count} successful, {failure_count} failed")

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "message": "Stage 5 KPI generation completed",
                "results": results,
                "summary": {
                    "total_processed": len(results),
                    "successful": success_count,
                    "failed": failure_count,
                },
            }
        ),
    }
