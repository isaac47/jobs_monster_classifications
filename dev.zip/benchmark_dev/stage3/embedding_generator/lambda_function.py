import json
import time
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import boto3
from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.analyze_status_checker import AnalyzeStatusChecker
from common.utils.dynamodb_utils import (
    batch_write_items,
    get_item,
    query_items,
    update_item,
)
from common.utils.logger import LogContext, get_logger
from common.utils.sqs_utils import get_queue_url, send_message

logger = get_logger(__name__)


def parse_sqs_message(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Parse SQS messages from the event."""
    messages = []

    for record in event.get("Records", []):
        if record.get("eventSource") != "aws:sqs":
            continue

        body = record.get("body")
        if not body:
            continue

        try:
            message = json.loads(body)
            messages.append(
                {"message": message, "receipt_handle": record.get("receiptHandle")}
            )
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing message body: {e}")

    return messages


def update_file_status(
    file_id: str,
    analyze_id: str,
    status: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """Update file status in KPI file status table."""
    try:
        update_expression = """
        SET #status = :status,
            updated_at = :updated_at
        """

        expression_values = {
            ":status": status,
            ":updated_at": datetime.now(timezone.utc).isoformat(),
        }

        expression_names = {
            "#status": "status"  # 'status' is a reserved word in DynamoDB
        }

        # Add additional metadata if provided
        if metadata:
            for key, value in metadata.items():
                safe_key = key.replace("-", "_").replace(".", "_")  # Sanitize key
                update_expression += f", {safe_key} = :{safe_key}"
                expression_values[f":{safe_key}"] = value

        return update_item(
            EnvVars.KPI_FILE_STATUS_TABLE,
            {"file_id": file_id, "analyze_id": analyze_id},
            update_expression,
            expression_values,
            expression_names,
        )

    except Exception as e:
        logger.error(f"Error updating file status: {e}")
        return False


def get_chunks_for_file(file_id: str) -> List[Dict[str, Any]]:
    """Get all chunks for a specific file from DynamoDB."""
    try:
        chunks = query_items(
            EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
            "file_id = :file_id",
            {":file_id": file_id},
        )

        logger.info(f"Retrieved {len(chunks)} chunks for file {file_id}")
        return chunks

    except Exception as e:
        logger.error(f"Error retrieving chunks for file {file_id}: {e}")
        return []


def create_embeddings_for_texts(
    texts: List[str], model_id: str
) -> Optional[List[List[float]]]:
    """Create embeddings for a list of texts using Bedrock."""
    try:
        bedrock_runtime = boto3.client(
            service_name="bedrock-runtime", region_name=EnvVars.BEDROCK_REGION
        )

        embeddings = []
        batch_size = EnvVars.MAX_EMBEDDING_BATCH_SIZE

        # Process in batches
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i : i + batch_size]
            logger.debug(
                f"Processing embedding batch {i//batch_size + 1}/{(len(texts) + batch_size - 1)//batch_size}"
            )

            # Process each text individually since Titan Embed doesn't support batch processing
            for j, text in enumerate(batch_texts):
                try:
                    # Prepare request body based on model
                    if model_id.startswith("amazon.titan-embed"):
                        request_body = {"inputText": text}
                    elif model_id.startswith("cohere.embed"):
                        request_body = {
                            "texts": [text],
                            "input_type": "search_document",
                        }
                    else:
                        # Default format for other models
                        request_body = {"texts": [text]}

                    response = bedrock_runtime.invoke_model(
                        modelId=model_id,
                        contentType="application/json",
                        accept="application/json",
                        body=json.dumps(request_body),
                    )

                    response_body = json.loads(response.get("body").read())

                    # Extract embeddings based on model
                    if model_id.startswith("amazon.titan-embed"):
                        embedding = response_body.get("embedding")
                        if embedding:
                            embeddings.append(embedding)
                        else:
                            logger.error(f"No embedding returned for text {i+j+1}")
                            return None
                    elif model_id.startswith("cohere.embed"):
                        batch_embeddings = response_body.get("embeddings", [])
                        if batch_embeddings:
                            embeddings.extend(batch_embeddings)
                        else:
                            logger.error(f"No embeddings returned for text {i+j+1}")
                            return None
                    else:
                        batch_embeddings = response_body.get("embeddings", [])
                        embeddings.extend(batch_embeddings)

                    # Rate limiting to avoid throttling
                    time.sleep(0.1)

                except Exception as e:
                    logger.error(f"Error processing text {i+j+1}: {e}")
                    return None

            # Longer pause between batches
            if i + batch_size < len(texts):
                time.sleep(0.5)

        logger.info(
            f"Successfully created embeddings for {len(embeddings)} texts using model {model_id}"
        )
        return embeddings

    except Exception as e:
        logger.error(f"Error creating embeddings: {e}")
        return None


def update_chunks_with_embeddings(
    chunks: List[Dict[str, Any]], embeddings: List[List[float]], model_id: str
) -> bool:
    """Update chunks with embedding vectors in DynamoDB."""
    if len(chunks) != len(embeddings):
        logger.error(
            f"Mismatch between chunks and embeddings: {len(chunks)} chunks, {len(embeddings)} embeddings"
        )
        return False

    try:
        # Prepare chunks for batch update
        updated_chunks = []

        for i, chunk in enumerate(chunks):
            chunk_copy = chunk.copy()
            chunk_copy["embedding"] = embeddings[i]
            chunk_copy["embedding_model"] = model_id
            chunk_copy["embedding_timestamp"] = datetime.now(timezone.utc).isoformat()
            updated_chunks.append(chunk_copy)

        # Batch write to DynamoDB
        result = batch_write_items(EnvVars.KPI_DOCUMENT_CHUNKS_TABLE, updated_chunks)

        unprocessed_count = len(result.get("UnprocessedItems", []))
        if unprocessed_count > 0:
            logger.warning(
                f"Failed to update {unprocessed_count} chunks with embeddings"
            )
            return False

        logger.info(
            f"Successfully updated {len(updated_chunks)} chunks with embeddings"
        )
        return True

    except Exception as e:
        logger.error(f"Error updating chunks with embeddings: {e}")
        return False


def notify_retrieval_queue(message: Dict[str, Any], chunk_count: int) -> bool:
    """Notify the retrieval queue that embeddings are complete."""
    try:
        queue_url = get_queue_url(EnvVars.RETRIEVAL_QUEUE_NAME)
        if not queue_url:
            logger.error(f"Could not get URL for queue: {EnvVars.RETRIEVAL_QUEUE_NAME}")
            return False

        retrieval_message = {
            "file_id": message.get("file_id"),
            "analyze_id": message.get("analyze_id"),
            "stage": "retrieval",
            "chunk_count": chunk_count,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_stage": "embedding_complete",
        }

        message_id = send_message(queue_url, retrieval_message)
        if message_id:
            logger.info(f"Message sent to retrieval queue: {message_id}")
            return True

        return False
    except Exception as e:
        logger.error(f"Error notifying retrieval queue: {e}")
        return False


def process_message(message_data: Dict[str, Any]) -> bool:
    """Process a message from the queue with ENHANCED analyze status checking."""
    message = message_data["message"]

    file_id = message.get("file_id")
    analyze_id = message.get("analyze_id")

    if not file_id or not analyze_id:
        logger.error(f"Missing required fields in message: {message}")
        return False

    with LogContext(logger, f"Processing embeddings for file {file_id}"):
        try:
            # ENHANCED CRITICAL CHECK: Query analyze_id status → If "failed", skip processing
            logger.info(f"CRITICAL CHECK: Verifying analyze status for {analyze_id}")

            can_continue, analyze_record = AnalyzeStatusChecker.check_analyze_status(
                analyze_id
            )
            if not can_continue:
                if analyze_record and analyze_record.get("status") == "failed":
                    logger.warning(
                        f"ANALYZE FAILED: Skipping embedding processing for analyze {analyze_id}"
                    )
                    logger.warning(
                        f"    Failure reason: {analyze_record.get('failure_reason', 'Unknown')}"
                    )
                    logger.warning(
                        f"    Failure stage: {analyze_record.get('failure_stage', 'Unknown')}"
                    )
                else:
                    logger.error(
                        f"ANALYZE NOT FOUND: Analyze record not found: {analyze_id}"
                    )

                # Return True to avoid reprocessing this message
                return True

            logger.info(
                f"ANALYZE STATUS OK: Proceeding with embedding processing for {analyze_id}"
            )

            # Additional validation: Check if analyze is in a valid state for embedding
            analyze_status = (
                analyze_record.get("status") if analyze_record else "unknown"
            )
            if analyze_status not in ["processing"]:
                logger.warning(
                    f"UNEXPECTED STATUS: Analyze {analyze_id} has status '{analyze_status}', expected 'processing'"
                )
                # Continue anyway but log the concern

            # Update file status to embedding_processing
            if not update_file_status(file_id, analyze_id, "embedding_processing"):
                logger.error(f"Failed to update file status to embedding_processing")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to update file status", "embedding"
                )
                return False

            # Get analyze parameters for embedding model selection
            bank_is_french = (
                analyze_record.get("bank_is_french", False) if analyze_record else False
            )
            model_id = EnvVars.get_embedding_model(bank_is_french)

            logger.info(
                f"Using embedding model: {model_id} (French bank: {bank_is_french})"
            )

            # Query all chunks for file_id from kpi_document_chunks
            chunks = get_chunks_for_file(file_id)
            if not chunks:
                logger.error(f"No chunks found for file {file_id}")
                update_file_status(
                    file_id, analyze_id, "failed", {"error_message": "No chunks found"}
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, f"No chunks found for file {file_id}", "embedding"
                )
                return False

            logger.info(f"Processing {len(chunks)} chunks for embedding")

            # Extract text to embed
            texts_to_embed = []
            for chunk in chunks:
                # Use text_to_embed if available, otherwise use text
                text = chunk.get("text_to_embed") or chunk.get("text", "")
                if not text.strip():
                    logger.warning(
                        f"Empty text found in chunk {chunk.get('chunk_id', 'unknown')}"
                    )
                    text = "Empty content"  # Fallback for empty chunks
                texts_to_embed.append(text)

            # Create embeddings using appropriate model
            logger.info(f"Creating embeddings for {len(texts_to_embed)} texts...")
            embeddings = create_embeddings_for_texts(texts_to_embed, model_id)
            if not embeddings:
                logger.error(f"Failed to create embeddings for file {file_id}")
                update_file_status(
                    file_id,
                    analyze_id,
                    "failed",
                    {"error_message": "Failed to create embeddings"},
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    f"Failed to create embeddings for file {file_id}",
                    "embedding",
                )
                return False

            logger.info(f"Created {len(embeddings)} embeddings successfully")

            # Store embedding vectors back to chunk records
            logger.info(f"Storing embeddings in DynamoDB...")
            if not update_chunks_with_embeddings(chunks, embeddings, model_id):
                logger.error(
                    f"Failed to update chunks with embeddings for file {file_id}"
                )
                update_file_status(
                    file_id,
                    analyze_id,
                    "failed",
                    {"error_message": "Failed to update chunks"},
                )
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id,
                    f"Failed to update chunks for file {file_id}",
                    "embedding",
                )
                return False

            # Update file status to embedding_complete
            embedding_metadata = {
                "embedding_model": model_id,
                "embedded_chunks": len(chunks),
                "embedding_dimension": len(embeddings[0]) if embeddings else 0,
                "bank_is_french": bank_is_french,
            }

            if not update_file_status(
                file_id, analyze_id, "embedding_complete", embedding_metadata
            ):
                logger.error(f"Failed to update file status to embedding_complete")
                AnalyzeStatusChecker.mark_analyze_as_failed(
                    analyze_id, "Failed to update file status to complete", "embedding"
                )
                return False

            # Send message to retrieval queue
            logger.info(f"Notifying retrieval queue...")
            if not notify_retrieval_queue(message, len(chunks)):
                logger.error(f"Failed to notify retrieval queue for file {file_id}")
                return False

            logger.info(f"Successfully processed embeddings for file {file_id}")
            return True

        except Exception as e:
            logger.error(f"Error processing embeddings: {e}")
            logger.error(f"   Stack trace: {traceback.format_exc()}")

            # Enhanced error reporting
            update_file_status(file_id, analyze_id, "failed", {"error_message": str(e)})
            AnalyzeStatusChecker.mark_analyze_as_failed(
                analyze_id, f"Embedding processing error: {str(e)}", "embedding"
            )
            return False


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Lambda handler for embedding generation with enhanced status checking."""
    logger.info(f"Starting Stage 3: Embedding Generation")
    logger.info(f"Received event: {json.dumps(event)}")

    # Parse SQS messages
    messages = parse_sqs_message(event)
    if not messages:
        logger.warning("No valid messages found")
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "No valid messages found"}),
        }

    logger.info(f"Processing {len(messages)} messages")

    # Process each message
    results = []
    for i, message_data in enumerate(messages):
        logger.info(f"Processing message {i+1}/{len(messages)}")

        success = process_message(message_data)
        file_id = message_data["message"].get("file_id", "unknown")
        analyze_id = message_data["message"].get("analyze_id", "unknown")

        result = {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "success": success,
        }

        if success:
            logger.info(f"Message {i+1} processed successfully: file {file_id}")
        else:
            logger.error(f"Message {i+1} failed: file {file_id}")

        results.append(result)

    # Summary
    success_count = sum(1 for r in results if r["success"])
    failure_count = len(results) - success_count

    logger.info(f"SUMMARY: {success_count} successful, {failure_count} failed")

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "message": "Stage 3 embedding processing completed",
                "results": results,
                "summary": {
                    "total_processed": len(results),
                    "successful": success_count,
                    "failed": failure_count,
                },
            }
        ),
    }
