#!/bin/bash
# Stage 2 Setup - Part 2: SQS Queues Only
# Creates all required SQS queues with Dead Letter Queues for the KPI extraction pipeline

STACK_NAME="benchmark-bs"
REGION="eu-west-3"
ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)

print_status() {
  echo -e "\n== $1 =="
}

print_success() {
  echo -e "\n✅ $1"
}

print_error() {
  echo -e "\n❌ $1"
}

check_queue_exists() {
  local queue_name=$1
  aws sqs get-queue-url --queue-name "$queue_name" --region $REGION >/dev/null 2>&1
  return $?
}

create_queue_with_retry() {
  local queue_name=$1
  local max_attempts=3
  local attempt=1
  
  while [ $attempt -le $max_attempts ]; do
    echo "Attempt $attempt to create queue: $queue_name"
    
    if check_queue_exists "$queue_name"; then
      print_success "Queue $queue_name already exists"
      # Get the URL for existing queue
      local queue_url=$(aws sqs get-queue-url --queue-name "$queue_name" --query "QueueUrl" --output text --region $REGION)
      echo "$queue_url"
      return 0
    fi
    
    # Run the actual queue creation command passed as remaining arguments
    local result=$("${@:2}")
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
      print_success "Successfully created queue: $queue_name"
      echo "$result"
      return 0
    else
      print_error "Failed to create queue $queue_name (attempt $attempt)"
      attempt=$((attempt + 1))
      sleep 2
    fi
  done
  
  print_error "Failed to create queue $queue_name after $max_attempts attempts"
  return 1
}

print_status "Creating SQS Queues for KPI Extraction Pipeline"

# 1. Embedding Processing Queue and DLQ
print_status "Creating Embedding Processing Queues..."

EMBEDDING_DLQ_URL=$(create_queue_with_retry "${STACK_NAME}-embedding-dlq" \
aws sqs create-queue \
  --queue-name "${STACK_NAME}-embedding-dlq" \
  --attributes '{"MessageRetentionPeriod":"1209600","VisibilityTimeout":"30"}' \
  --query "QueueUrl" \
  --output text \
  --region $REGION)

if [ $? -ne 0 ]; then
  print_error "Failed to create embedding DLQ"
  exit 1
fi

EMBEDDING_DLQ_ARN=$(aws sqs get-queue-attributes \
  --queue-url "$EMBEDDING_DLQ_URL" \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text \
  --region $REGION)

EMBEDDING_QUEUE_URL=$(create_queue_with_retry "${STACK_NAME}-embedding-queue" \
aws sqs create-queue \
  --queue-name "${STACK_NAME}-embedding-queue" \
  --attributes "{\"VisibilityTimeout\":\"300\",\"MessageRetentionPeriod\":\"1209600\",\"RedrivePolicy\":\"{\\\"deadLetterTargetArn\\\":\\\"$EMBEDDING_DLQ_ARN\\\",\\\"maxReceiveCount\\\":3}\"}" \
  --query "QueueUrl" \
  --output text \
  --region $REGION)

# 2. Retrieval Processing Queue and DLQ
print_status "Creating Retrieval Processing Queues..."

RETRIEVAL_DLQ_URL=$(create_queue_with_retry "${STACK_NAME}-retrieval-dlq" \
aws sqs create-queue \
  --queue-name "${STACK_NAME}-retrieval-dlq" \
  --attributes '{"MessageRetentionPeriod":"1209600","VisibilityTimeout":"30"}' \
  --query "QueueUrl" \
  --output text \
  --region $REGION)

if [ $? -ne 0 ]; then
  print_error "Failed to create retrieval DLQ"
  exit 1
fi

RETRIEVAL_DLQ_ARN=$(aws sqs get-queue-attributes \
  --queue-url "$RETRIEVAL_DLQ_URL" \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text \
  --region $REGION)

RETRIEVAL_QUEUE_URL=$(create_queue_with_retry "${STACK_NAME}-retrieval-queue" \
aws sqs create-queue \
  --queue-name "${STACK_NAME}-retrieval-queue" \
  --attributes "{\"VisibilityTimeout\":\"300\",\"MessageRetentionPeriod\":\"1209600\",\"RedrivePolicy\":\"{\\\"deadLetterTargetArn\\\":\\\"$RETRIEVAL_DLQ_ARN\\\",\\\"maxReceiveCount\\\":3}\"}" \
  --query "QueueUrl" \
  --output text \
  --region $REGION)

# 3. KPI Generation Queue and DLQ
print_status "Creating KPI Generation Queues..."

KPI_DLQ_URL=$(create_queue_with_retry "${STACK_NAME}-kpi-generation-dlq" \
aws sqs create-queue \
  --queue-name "${STACK_NAME}-kpi-generation-dlq" \
  --attributes '{"MessageRetentionPeriod":"1209600","VisibilityTimeout":"30"}' \
  --query "QueueUrl" \
  --output text \
  --region $REGION)

if [ $? -ne 0 ]; then
  print_error "Failed to create KPI generation DLQ"
  exit 1
fi

KPI_DLQ_ARN=$(aws sqs get-queue-attributes \
  --queue-url "$KPI_DLQ_URL" \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text \
  --region $REGION)

KPI_QUEUE_URL=$(create_queue_with_retry "${STACK_NAME}-kpi-generation-queue" \
aws sqs create-queue \
  --queue-name "${STACK_NAME}-kpi-generation-queue" \
  --attributes "{\"VisibilityTimeout\":\"900\",\"MessageRetentionPeriod\":\"1209600\",\"RedrivePolicy\":\"{\\\"deadLetterTargetArn\\\":\\\"$KPI_DLQ_ARN\\\",\\\"maxReceiveCount\\\":3}\"}" \
  --query "QueueUrl" \
  --output text \
  --region $REGION)

# 4. Output Generation Queue and DLQ
print_status "Creating Output Generation Queues..."

OUTPUT_DLQ_URL=$(create_queue_with_retry "${STACK_NAME}-output-generation-dlq" \
aws sqs create-queue \
  --queue-name "${STACK_NAME}-output-generation-dlq" \
  --attributes '{"MessageRetentionPeriod":"1209600","VisibilityTimeout":"30"}' \
  --query "QueueUrl" \
  --output text \
  --region $REGION)

if [ $? -ne 0 ]; then
  print_error "Failed to create output generation DLQ"
  exit 1
fi

OUTPUT_DLQ_ARN=$(aws sqs get-queue-attributes \
  --queue-url "$OUTPUT_DLQ_URL" \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text \
  --region $REGION)

OUTPUT_QUEUE_URL=$(create_queue_with_retry "${STACK_NAME}-output-generation-queue" \
aws sqs create-queue \
  --queue-name "${STACK_NAME}-output-generation-queue" \
  --attributes "{\"VisibilityTimeout\":\"600\",\"MessageRetentionPeriod\":\"1209600\",\"RedrivePolicy\":\"{\\\"deadLetterTargetArn\\\":\\\"$OUTPUT_DLQ_ARN\\\",\\\"maxReceiveCount\\\":3}\"}" \
  --query "QueueUrl" \
  --output text \
  --region $REGION)

# Verify all queues were created successfully
print_status "Verifying Queue Creation..."

queues=(
  "embedding-queue:$EMBEDDING_QUEUE_URL"
  "embedding-dlq:$EMBEDDING_DLQ_URL"
  "retrieval-queue:$RETRIEVAL_QUEUE_URL"
  "retrieval-dlq:$RETRIEVAL_DLQ_URL"
  "kpi-generation-queue:$KPI_QUEUE_URL"
  "kpi-generation-dlq:$KPI_DLQ_URL"
  "output-generation-queue:$OUTPUT_QUEUE_URL"
  "output-generation-dlq:$OUTPUT_DLQ_URL"
)

all_success=true
for queue_info in "${queues[@]}"; do
  queue_name=$(echo "$queue_info" | cut -d: -f1)
  queue_url=$(echo "$queue_info" | cut -d: -f2-)
  
  if [ "$queue_url" != "" ] && [ "$queue_url" != "null" ]; then
    print_success "✓ $queue_name: $queue_url"
  else
    print_error "✗ Failed to create $queue_name"
    all_success=false
  fi
done

# Save queue URLs to a file for the Lambda setup script
QUEUE_URLS_FILE="/tmp/${STACK_NAME}-queue-urls.env"
cat > "$QUEUE_URLS_FILE" << EOF
EMBEDDING_QUEUE_URL="$EMBEDDING_QUEUE_URL"
RETRIEVAL_QUEUE_URL="$RETRIEVAL_QUEUE_URL"
KPI_QUEUE_URL="$KPI_QUEUE_URL"
OUTPUT_QUEUE_URL="$OUTPUT_QUEUE_URL"
EMBEDDING_DLQ_ARN="$EMBEDDING_DLQ_ARN"
RETRIEVAL_DLQ_ARN="$RETRIEVAL_DLQ_ARN"
KPI_DLQ_ARN="$KPI_DLQ_ARN"
OUTPUT_DLQ_ARN="$OUTPUT_DLQ_ARN"
EOF

print_status "SQS Queues Summary"
echo ""
echo "Main Processing Queues:"
echo "  1. Embedding Queue: $EMBEDDING_QUEUE_URL"
echo "  2. Retrieval Queue: $RETRIEVAL_QUEUE_URL"
echo "  3. KPI Generation Queue: $KPI_QUEUE_URL"
echo "  4. Output Generation Queue: $OUTPUT_QUEUE_URL"
echo ""
echo "Dead Letter Queues:"
echo "  1. Embedding DLQ: $EMBEDDING_DLQ_URL"
echo "  2. Retrieval DLQ: $RETRIEVAL_DLQ_URL"
echo "  3. KPI Generation DLQ: $KPI_DLQ_URL"
echo "  4. Output Generation DLQ: $OUTPUT_DLQ_URL"
echo ""
echo "Queue URLs saved to: $QUEUE_URLS_FILE"
echo "Source this file in the Lambda setup script: source $QUEUE_URLS_FILE"

if [ "$all_success" = true ]; then
  print_success "All SQS queues created successfully!"
  exit 0
else
  print_error "Some queues failed to create. Check the output above."
  exit 1
fi
