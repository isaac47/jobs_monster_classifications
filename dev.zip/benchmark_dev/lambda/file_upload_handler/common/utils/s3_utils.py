import json
import logging
from typing import Any, Dict, Optional
from urllib.parse import urlparse

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


def get_s3_client():
    """Get the S3 client."""
    return boto3.client("s3")


def download_from_s3(bucket: str, key: str) -> Optional[bytes]:
    """
    Download data from S3.

    Args:
        bucket: S3 bucket name
        key: S3 object key

    Returns:
        Optional[bytes]: Downloaded data or None if failed
    """
    client = get_s3_client()
    try:
        response = client.get_object(Bucket=bucket, Key=key)
        return response["Body"].read()
    except ClientError as e:
        logger.error(f"Error downloading from S3: {e}")
        return None


def upload_to_s3(
    bucket: str,
    key: str,
    data: bytes,
    metadata: Optional[Dict[str, str]] = None,
    content_type: str = "application/octet-stream",
) -> bool:
    """
    Upload data to S3.

    Args:
        bucket: S3 bucket name
        key: S3 object key
        data: Data to upload
        metadata: Optional metadata
        content_type: Content type for the object

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_s3_client()
    try:
        put_params = {
            "Bucket": bucket,
            "Key": key,
            "Body": data,
            "ContentType": content_type,
        }

        if metadata:
            put_params["Metadata"] = metadata

        client.put_object(**put_params)
        logger.info(f"Successfully uploaded to s3://{bucket}/{key}")
        return True
    except ClientError as e:
        logger.error(f"Error uploading to S3: {e}")
        return False


def upload_json_to_s3(
    bucket: str,
    key: str,
    data: Dict[str, Any],
    metadata: Optional[Dict[str, str]] = None,
) -> bool:
    """
    Upload JSON data to S3.

    Args:
        bucket: S3 bucket name
        key: S3 object key
        data: JSON-serializable data to upload
        metadata: Optional metadata

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        json_str = json.dumps(data, indent=2, default=str)
        json_bytes = json_str.encode("utf-8")

        return upload_to_s3(
            bucket, key, json_bytes, metadata, content_type="application/json"
        )
    except (TypeError, ValueError) as e:
        logger.error(f"Error serializing JSON: {e}")
        return False


def upload_string_to_s3(
    bucket: str,
    key: str,
    content: str,
    metadata: Optional[Dict[str, str]] = None,
    content_type: str = "text/plain",
) -> bool:
    """
    Upload string content to S3.

    Args:
        bucket: S3 bucket name
        key: S3 object key
        content: String content to upload
        metadata: Optional metadata
        content_type: Content type for the object

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        content_bytes = content.encode("utf-8")
        return upload_to_s3(bucket, key, content_bytes, metadata, content_type)
    except Exception as e:
        logger.error(f"Error uploading string to S3: {e}")
        return False


def get_s3_object_metadata(bucket: str, key: str) -> Optional[Dict[str, Any]]:
    """
    Get S3 object metadata.

    Args:
        bucket: S3 bucket name
        key: S3 object key

    Returns:
        Optional[Dict[str, Any]]: Object metadata or None if failed
    """
    client = get_s3_client()
    try:
        response = client.head_object(Bucket=bucket, Key=key)
        return {
            "metadata": response.get("Metadata", {}),
            "content_type": response.get("ContentType"),
            "content_length": response.get("ContentLength"),
            "last_modified": response.get("LastModified"),
            "e_tag": response.get("ETag"),
        }
    except ClientError as e:
        logger.error(f"Error getting S3 object metadata: {e}")
        return None


def check_file_exists(bucket: str, key: str) -> bool:
    """
    Check if a file exists in S3.

    Args:
        bucket: S3 bucket name
        key: S3 object key

    Returns:
        bool: True if file exists, False otherwise
    """
    client = get_s3_client()
    try:
        client.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            return False
        logger.error(f"Error checking file existence: {e}")
        return False


def parse_s3_url(s3_url: str) -> Dict[str, str]:
    """
    Parse an S3 URL into bucket and key.

    Args:
        s3_url: S3 URL (s3://bucket/key)

    Returns:
        Dict[str, str]: Dictionary with 'bucket' and 'key'
    """
    parsed_url = urlparse(s3_url)
    if parsed_url.scheme != "s3":
        raise ValueError(f"Not an S3 URL: {s3_url}")

    bucket = parsed_url.netloc
    # Remove leading slash from key
    key = parsed_url.path.lstrip("/")

    return {"bucket": bucket, "key": key}


def list_objects(
    bucket: str, prefix: str = "", max_keys: int = 1000
) -> List[Dict[str, Any]]:
    """
    List objects in S3 bucket with optional prefix.

    Args:
        bucket: S3 bucket name
        prefix: Optional prefix to filter objects
        max_keys: Maximum number of keys to return

    Returns:
        List[Dict[str, Any]]: List of objects
    """
    client = get_s3_client()
    try:
        params = {"Bucket": bucket, "MaxKeys": max_keys}

        if prefix:
            params["Prefix"] = prefix

        response = client.list_objects_v2(**params)
        return response.get("Contents", [])
    except ClientError as e:
        logger.error(f"Error listing objects: {e}")
        return []


def delete_object(bucket: str, key: str) -> bool:
    """
    Delete an object from S3.

    Args:
        bucket: S3 bucket name
        key: S3 object key

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_s3_client()
    try:
        client.delete_object(Bucket=bucket, Key=key)
        logger.info(f"Successfully deleted s3://{bucket}/{key}")
        return True
    except ClientError as e:
        logger.error(f"Error deleting S3 object: {e}")
        return False


def copy_object(
    source_bucket: str,
    source_key: str,
    dest_bucket: str,
    dest_key: str,
    metadata: Optional[Dict[str, str]] = None,
) -> bool:
    """
    Copy an object within S3.

    Args:
        source_bucket: Source bucket name
        source_key: Source object key
        dest_bucket: Destination bucket name
        dest_key: Destination object key
        metadata: Optional metadata for the destination object

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_s3_client()
    try:
        copy_source = {"Bucket": source_bucket, "Key": source_key}

        copy_params = {
            "CopySource": copy_source,
            "Bucket": dest_bucket,
            "Key": dest_key,
        }

        if metadata:
            copy_params["Metadata"] = metadata
            copy_params["MetadataDirective"] = "REPLACE"

        client.copy_object(**copy_params)
        logger.info(
            f"Successfully copied s3://{source_bucket}/{source_key} to s3://{dest_bucket}/{dest_key}"
        )
        return True
    except ClientError as e:
        logger.error(f"Error copying S3 object: {e}")
        return False


def generate_presigned_url(
    bucket: str, key: str, expiration: int = 3600, http_method: str = "GET"
) -> Optional[str]:
    """
    Generate a presigned URL for S3 object access.

    Args:
        bucket: S3 bucket name
        key: S3 object key
        expiration: URL expiration time in seconds
        http_method: HTTP method for the URL

    Returns:
        Optional[str]: Presigned URL or None if failed
    """
    client = get_s3_client()
    try:
        url = client.generate_presigned_url(
            http_method.lower() + "_object",
            Params={"Bucket": bucket, "Key": key},
            ExpiresIn=expiration,
        )
        return url
    except ClientError as e:
        logger.error(f"Error generating presigned URL: {e}")
        return None
