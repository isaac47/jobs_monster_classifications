import hashlib
import json
import urllib.parse
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests
from common.config.env_vars import EnvironmentVariables as EnvVars
from common.models.kpi_models import (
    AnalyzeStatus,
    DocumentType,
    FileCategory,
    FileStatus,
    KPIAnalyzeStatus,
    KPIFileStatus,
    create_file_record,
)
from common.utils.dynamodb_utils import (
    get_item,
    put_item,
    scan_table_with_filter,
    update_item,
)
from common.utils.logger import LogContext, get_logger
from common.utils.s3_utils import download_from_s3, get_s3_object_metadata

logger = get_logger(__name__)


def parse_s3_event(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Parse the S3 event record for KPI extraction.

    Args:
        event: S3 event

    Returns:
        List[Dict[str, Any]]: List of parsed records
    """
    records = []

    for record in event.get("Records", []):
        if record.get("eventSource") != "aws:s3" or record.get(
            "eventName", ""
        ).startswith("ObjectRemoved:"):
            continue

        bucket = record.get("s3", {}).get("bucket", {}).get("name")
        key = record.get("s3", {}).get("object", {}).get("key")

        if not bucket or not key:
            logger.warning(f"Invalid S3 record: {json.dumps(record)}")
            continue

        # URL decode the key
        key = urllib.parse.unquote_plus(key)

        records.append(
            {"bucket": bucket, "key": key, "event_time": record.get("eventTime")}
        )

    return records


def extract_file_metadata_from_s3_path(key: str) -> Optional[Dict[str, Any]]:
    """
    Extract metadata from S3 key path following the structure:
    input/analyze_id/file_id/file_name

    Args:
        key: S3 key path

    Returns:
        Optional[Dict[str, Any]]: Extracted metadata or None if invalid
    """
    try:
        # Parse key: input/analyze_id/file_id/file_name
        parts = key.split("/")
        if len(parts) < 4 or parts[0] != "input":
            logger.error(
                f"Invalid S3 key format, expected input/analyze_id/file_id/file_name: {key}"
            )
            return None

        analyze_id = parts[1]
        file_id = parts[2]
        file_name = parts[3]

        # Determine file category and type from file name and extension
        file_extension = file_name.lower().split(".")[-1]

        # Determine document type
        if file_extension == "pdf":
            doc_type = DocumentType.PDF
        elif file_extension in ["xlsx", "xls"]:
            doc_type = DocumentType.EXCEL
        else:
            logger.error(f"Unsupported file type: {file_extension}")
            return None

        return {
            "analyze_id": analyze_id,
            "file_id": file_id,
            "file_name": file_name,
            "file_type": doc_type.value,
        }
    except Exception as e:
        logger.error(f"Error extracting metadata from S3 path: {e}")
        return None


def validate_file_integrity(bucket: str, key: str) -> bool:
    """
    Validate file integrity by attempting to read and verify the file.

    Args:
        bucket: S3 bucket
        key: S3 key

    Returns:
        bool: True if file is valid and readable, False otherwise
    """
    try:
        with LogContext(logger, f"Validating file {key}"):
            # Download file data
            data = download_from_s3(bucket, key)
            if not data:
                logger.error(f"Could not download file: {bucket}/{key}")
                return False

            # Get file size
            file_size = len(data)

            # Check file size limits
            max_size_bytes = EnvVars.MAX_FILE_SIZE_MB * 1024 * 1024
            if file_size > max_size_bytes:
                logger.error(
                    f"File too large: {file_size} bytes > {max_size_bytes} bytes"
                )
                return False

            # Basic file type validation
            filename = key.split("/")[-1].lower()
            file_extension = filename.split(".")[-1] if "." in filename else ""

            if file_extension not in EnvVars.SUPPORTED_FILE_TYPES:
                logger.error(f"Unsupported file extension: {file_extension}")
                return False

            logger.info(f"File validation successful: {key}, size: {file_size} bytes")
            return True

    except Exception as e:
        logger.error(f"Error validating file integrity: {e}")
        return False


def calculate_checksum(bucket: str, key: str) -> Optional[str]:
    """
    Calculate SHA-256 checksum of the S3 object.

    Args:
        bucket: S3 bucket
        key: S3 key

    Returns:
        Optional[str]: Checksum or None if failed
    """
    try:
        data = download_from_s3(bucket, key)
        if data:
            return hashlib.sha256(data).hexdigest()
        return None
    except Exception as e:
        logger.error(f"Error calculating checksum: {e}")
        return None


def get_analyze_record(analyze_id: str) -> Optional[Dict[str, Any]]:
    """
    Get existing analyze record.

    Args:
        analyze_id: Analyze identifier

    Returns:
        Optional[Dict[str, Any]]: Analyze record or None if not found
    """
    try:
        record = get_item(EnvVars.KPI_ANALYZE_STATUS_TABLE, {"analyze_id": analyze_id})
        return record
    except Exception as e:
        logger.error(f"Error getting analyze record: {e}")
        return None


def update_analyze_status(
    analyze_id: str,
    status: AnalyzeStatus,
    error_message: Optional[str] = None,
    current_step: Optional[str] = None,
) -> bool:
    """
    Update analyze status.

    Args:
        analyze_id: Analyze identifier
        status: New status
        error_message: Optional error message
        current_step: Optional current step

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        update_expression = "SET #status = :status, updated_at = :updated_at"
        expression_values = {
            ":status": status.value,
            ":updated_at": datetime.now(timezone.utc).isoformat(),
        }
        expression_names = {"#status": "status"}

        if error_message:
            update_expression += ", error_message = :error_message"
            expression_values[":error_message"] = error_message

        if current_step:
            update_expression += ", current_step = :current_step"
            expression_values[":current_step"] = current_step

        return update_item(
            EnvVars.KPI_ANALYZE_STATUS_TABLE,
            {"analyze_id": analyze_id},
            update_expression,
            expression_values,
            expression_names,
        )
    except Exception as e:
        logger.error(f"Error updating analyze status: {e}")
        return False


def create_file_status_record(
    file_metadata: Dict[str, Any],
    s3_path: str,
    file_size: int,
    checksum: str,
    bank_id: str,
) -> Optional[str]:
    """
    Create a file status record in DynamoDB.

    Args:
        file_metadata: File metadata
        s3_path: S3 path to file
        file_size: File size in bytes
        checksum: File checksum
        bank_id: Bank identifier

    Returns:
        Optional[str]: File ID or None if failed
    """
    try:
        file_record = create_file_record(
            file_id=file_metadata["file_id"],
            analyze_id=file_metadata["analyze_id"],
            bank_id=bank_id,
            file_name=file_metadata["file_name"],
            file_category=file_metadata["file_category"],
            file_type=file_metadata["file_type"],
            s3_path=s3_path,
            file_size=file_size,
            checksum=checksum,
        )

        # Store in DynamoDB
        if put_item(EnvVars.KPI_FILE_STATUS_TABLE, file_record.dict()):
            return file_record.file_id
        return None
    except Exception as e:
        logger.error(f"Error creating file status record: {e}")
        return None


def update_file_status(
    file_id: str, status: FileStatus, error_message: Optional[str] = None
) -> bool:
    """
    Update file status.

    Args:
        file_id: File identifier
        status: New status
        error_message: Optional error message

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        update_expression = "SET #status = :status, updated_at = :updated_at"
        expression_values = {
            ":status": status.value,
            ":updated_at": datetime.now(timezone.utc).isoformat(),
        }
        expression_names = {"#status": "status"}

        if error_message:
            update_expression += ", error_message = :error_message"
            expression_values[":error_message"] = error_message

        return update_item(
            EnvVars.KPI_FILE_STATUS_TABLE,
            {"file_id": file_id},
            update_expression,
            expression_values,
            expression_names,
        )
    except Exception as e:
        logger.error(f"Error updating file status: {e}")
        return False


def get_uploaded_files_for_analyze(analyze_id: str) -> List[Dict[str, Any]]:
    """
    Get all uploaded files for an analyze.

    Args:
        analyze_id: Analyze identifier

    Returns:
        List[Dict[str, Any]]: List of file records
    """
    try:
        files = scan_table_with_filter(
            EnvVars.KPI_FILE_STATUS_TABLE,
            "analyze_id = :analyze_id",
            {":analyze_id": analyze_id},
        )
        return files
    except Exception as e:
        logger.error(f"Error getting uploaded files: {e}")
        return []


def check_all_files_uploaded(analyze_id: str, expected_files: List[str]) -> bool:
    """
    Check if all expected files for an analyze are uploaded.

    Args:
        analyze_id: Analyze identifier
        expected_files: List of expected file categories

    Returns:
        bool: True if all files uploaded, False otherwise
    """
    try:
        uploaded_files = get_uploaded_files_for_analyze(analyze_id)
        uploaded_categories = [f.get("file_category") for f in uploaded_files]

        # Check if all expected categories are represented
        for expected_category in expected_files:
            if expected_category not in uploaded_categories:
                logger.info(
                    f"Missing file category {expected_category} for analyze {analyze_id}"
                )
                return False

        logger.info(f"All expected files uploaded for analyze {analyze_id}")
        return True

    except Exception as e:
        logger.error(f"Error checking uploaded files: {e}")
        return False


def call_docling_endpoint(file_id: str, analyze_id: str, s3_path: str, file_category: str) -> bool:
    """
    Call the docling endpoint to process the document.

    Args:
        file_id: File identifier
        analyze_id: Analyze identifier
        s3_path: S3 path to the file

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if not EnvVars.DOCLING_ENDPOINT_URL:
            logger.error("Docling endpoint URL not configured")
            return False

        payload = {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "s3_path": s3_path,
            "file_category": file_category,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        headers = {"Content-Type": "application/json"}

        logger.info(f"Calling docling endpoint for file {file_id}")

        # Update file status to docling_processing
        update_file_status(file_id, FileStatus.DOCLING_PROCESSING)

        response = requests.post(
            EnvVars.DOCLING_ENDPOINT_URL,
            json=payload,
            headers=headers,
            timeout=EnvVars.DOCLING_TIMEOUT,
        )

        if response.status_code == 200:
            logger.info(f"Docling processing initiated for file {file_id}")
            return True
        else:
            logger.error(
                f"Docling endpoint error: {response.status_code} - {response.text}"
            )
            update_file_status(
                file_id, FileStatus.FAILED, f"Docling error: {response.status_code}"
            )
            return False

    except Exception as e:
        logger.error(f"Error calling docling endpoint: {e}")
        update_file_status(file_id, FileStatus.FAILED, f"Docling call failed: {str(e)}")
        return False


def process_record(record: Dict[str, Any]) -> bool:
    """
    Process an S3 event record for KPI extraction Stage 1.

    Args:
        record: Parsed S3 event record

    Returns:
        bool: True if successful, False otherwise
    """
    bucket = record["bucket"]
    key = record["key"]
    s3_path = f"s3://{bucket}/{key}"

    try:
        with LogContext(logger, f"Processing S3 record {key}"):

            # Extract metadata from S3 path
            file_metadata = extract_file_metadata_from_s3_path(key)
            if not file_metadata:
                logger.error(f"Could not extract metadata from S3 path: {key}")
                return False

            analyze_id = file_metadata["analyze_id"]
            file_id = file_metadata["file_id"]

            # Get analyze record
            analyze_record = get_analyze_record(analyze_id)
            if not analyze_record:
                logger.error(f"Analyze record not found: {analyze_id}")
                return False

            # Check if analyze is already failed
            if analyze_record.get("status") == AnalyzeStatus.FAILED.value:
                logger.error(f"Analyze already failed, skipping file: {analyze_id}")
                return False

            # Update analyze step to file_validation
            update_analyze_status(
                analyze_id, AnalyzeStatus.PROCESSING, current_step="file_validation"
            )

            # Validate file integrity
            if not validate_file_integrity(bucket, key):
                logger.error(f"File validation failed: {bucket}/{key}")
                # Mark file as failed and analyze as failed
                update_file_status(file_id, FileStatus.FAILED, "File validation failed")
                update_analyze_status(
                    analyze_id,
                    AnalyzeStatus.FAILED,
                    "File validation failed",
                    "file_validation",
                )
                return False

            # Calculate checksum
            checksum = calculate_checksum(bucket, key)
            if not checksum:
                logger.warning(f"Could not calculate checksum: {bucket}/{key}")
                checksum = "unknown"

            # Get file size from S3 metadata
            s3_metadata = get_s3_object_metadata(bucket, key)
            file_size = s3_metadata.get("content_length", 0) if s3_metadata else 0

            # Extract file category from S3 metadata
            file_category = s3_metadata.get("metadata", {}).get("file_category")
            file_metadata["file_category"] = file_category

            # Get bank_id from analyze record
            bank_id = analyze_record.get("bank_id", "unknown")

            # Create file status record
            created_file_id = create_file_status_record(
                file_metadata, s3_path, file_size, checksum, bank_id
            )
            if not created_file_id:
                logger.error(f"Failed to create file status record: {bucket}/{key}")
                update_analyze_status(
                    analyze_id,
                    AnalyzeStatus.FAILED,
                    "Failed to create file record",
                    "file_validation",
                )
                return False

            logger.info(f"Created file record: {created_file_id}")

            # Check if all files are uploaded
            expected_files = analyze_record.get("expected_files", [])
            all_files_uploaded = check_all_files_uploaded(analyze_id, expected_files)

            if all_files_uploaded:
                logger.info(
                    f"All files uploaded for analyze {analyze_id}, starting docling processing"
                )

                # Update analyze step to text_extraction
                update_analyze_status(
                    analyze_id, AnalyzeStatus.PROCESSING, current_step="text_extraction"
                )

                # Get all files for this analyze and call docling for each
                uploaded_files = get_uploaded_files_for_analyze(analyze_id)

                docling_success = True
                for file_record in uploaded_files:
                    file_record_id = file_record.get("file_id")
                    file_s3_path = file_record.get("s3_path")

                    if not call_docling_endpoint(
                        file_record_id, analyze_id, file_s3_path, file_category
                    ):
                        logger.error(
                            f"Failed to call docling for file: {file_record_id}"
                        )
                        docling_success = False

                if not docling_success:
                    update_analyze_status(
                        analyze_id,
                        AnalyzeStatus.FAILED,
                        "Docling processing failed",
                        "text_extraction",
                    )
                    return False
            else:
                logger.info(f"Waiting for more files for analyze {analyze_id}")

            logger.info(f"Successfully processed file upload: {file_id}")
            return True

    except Exception as e:
        logger.error(f"Error processing record: {e}")
        # Try to mark analyze as failed
        try:
            if "analyze_id" in locals():
                update_analyze_status(
                    analyze_id,
                    AnalyzeStatus.FAILED,
                    f"Processing error: {str(e)}",
                    "file_validation",
                )
        except:
            pass
        return False


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for S3 upload events in KPI extraction pipeline Stage 1.

    Args:
        event: S3 event
        context: Lambda context

    Returns:
        Dict[str, Any]: Response
    """
    logger.info(f"Received S3 event for KPI extraction Stage 1: {json.dumps(event)}")

    # Parse S3 event records
    records = parse_s3_event(event)
    if not records:
        logger.warning("No valid S3 records found")
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "No valid S3 records found"}),
        }

    # Process each record
    results = []
    for record in records:
        success = process_record(record)
        results.append(
            {"bucket": record["bucket"], "key": record["key"], "success": success}
        )

    # Check if any processing failed
    failed_count = sum(1 for result in results if not result["success"])

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "message": "File upload processing completed",
                "results": results,
                "failed_count": failed_count,
            }
        ),
    }
