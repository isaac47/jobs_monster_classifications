#!/bin/bash
# Stage 2 Setup - Part 1: DynamoDB Tables Only
# Creates all required DynamoDB tables for the KPI extraction pipeline

STACK_NAME="benchmark-bs"
REGION="eu-west-3"

print_status() {
  echo -e "\n== $1 =="
}

print_success() {
  echo -e "\n✅ $1"
}

print_error() {
  echo -e "\n❌ $1"
}

check_table_exists() {
  local table_name=$1
  aws dynamodb describe-table --table-name "$table_name" --region $REGION >/dev/null 2>&1
  return $?
}

create_table_with_retry() {
  local table_name=$1
  local max_attempts=3
  local attempt=1
  
  while [ $attempt -le $max_attempts ]; do
    echo "Attempt $attempt to create table: $table_name"
    
    if check_table_exists "$table_name"; then
      print_success "Table $table_name already exists"
      return 0
    fi
    
    # Run the actual table creation command passed as remaining arguments
    "${@:2}"
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
      print_success "Successfully created table: $table_name"
      return 0
    else
      print_error "Failed to create table $table_name (attempt $attempt)"
      attempt=$((attempt + 1))
      sleep 5
    fi
  done
  
  print_error "Failed to create table $table_name after $max_attempts attempts"
  return 1
}

print_status "Creating DynamoDB Tables for KPI Extraction Pipeline"

# 1. KPI Document Chunks Table
print_status "Creating KPI Document Chunks Table..."
create_table_with_retry "${STACK_NAME}-kpi-document-chunks" \
aws dynamodb create-table \
  --table-name "${STACK_NAME}-kpi-document-chunks" \
  --attribute-definitions \
    AttributeName=chunk_id,AttributeType=S \
    AttributeName=file_id,AttributeType=S \
    AttributeName=analyze_id,AttributeType=S \
  --key-schema \
    AttributeName=chunk_id,KeyType=HASH \
  --global-secondary-indexes '[{
    "IndexName": "file-id-index",
    "KeySchema": [{"AttributeName": "file_id", "KeyType": "HASH"}],
    "Projection": {"ProjectionType": "ALL"}
  },{
    "IndexName": "analyze-id-index",
    "KeySchema": [{"AttributeName": "analyze_id", "KeyType": "HASH"}],
    "Projection": {"ProjectionType": "ALL"}
  }]' \
  --billing-mode PAY_PER_REQUEST \
  --region $REGION

# 2. KPI Retrieval Context Table
print_status "Creating KPI Retrieval Context Table..."
create_table_with_retry "${STACK_NAME}-kpi-retrieval-context" \
aws dynamodb create-table \
  --table-name "${STACK_NAME}-kpi-retrieval-context" \
  --attribute-definitions \
    AttributeName=context_id,AttributeType=S \
    AttributeName=file_id,AttributeType=S \
    AttributeName=analyze_id,AttributeType=S \
  --key-schema \
    AttributeName=context_id,KeyType=HASH \
  --global-secondary-indexes '[{
    "IndexName": "file-id-index",
    "KeySchema": [{"AttributeName": "file_id", "KeyType": "HASH"}],
    "Projection": {"ProjectionType": "ALL"}
  },{
    "IndexName": "analyze-id-index",
    "KeySchema": [{"AttributeName": "analyze_id", "KeyType": "HASH"}],
    "Projection": {"ProjectionType": "ALL"}
  }]' \
  --billing-mode PAY_PER_REQUEST \
  --region $REGION

# 3. KPI Responses Table (with streams for completion monitoring)
print_status "Creating KPI Responses Table with Streams..."
create_table_with_retry "${STACK_NAME}-kpi-responses" \
aws dynamodb create-table \
  --table-name "${STACK_NAME}-kpi-responses" \
  --attribute-definitions \
    AttributeName=file_id,AttributeType=S \
    AttributeName=analyze_id,AttributeType=S \
  --key-schema \
    AttributeName=file_id,KeyType=HASH \
  --global-secondary-indexes '[{
    "IndexName": "analyze-id-index",
    "KeySchema": [{"AttributeName": "analyze_id", "KeyType": "HASH"}],
    "Projection": {"ProjectionType": "ALL"}
  }]' \
  --billing-mode PAY_PER_REQUEST \
  --stream-specification StreamEnabled=true,StreamViewType=NEW_AND_OLD_IMAGES \
  --region $REGION

# 4. KPI Final Output Table
print_status "Creating KPI Final Output Table..."
create_table_with_retry "${STACK_NAME}-kpi-final-output" \
aws dynamodb create-table \
  --table-name "${STACK_NAME}-kpi-final-output" \
  --attribute-definitions \
    AttributeName=analyze_id,AttributeType=S \
  --key-schema \
    AttributeName=analyze_id,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region $REGION

# Wait for all tables to be active
print_status "Waiting for all tables to become active..."

tables=("${STACK_NAME}-kpi-document-chunks" "${STACK_NAME}-kpi-retrieval-context" "${STACK_NAME}-kpi-responses" "${STACK_NAME}-kpi-final-output")

for table in "${tables[@]}"; do
  echo "Waiting for table $table to be active..."
  aws dynamodb wait table-exists --table-name "$table" --region $REGION
  if [ $? -eq 0 ]; then
    print_success "Table $table is now active"
  else
    print_error "Table $table failed to become active"
  fi
done

# Display table information
print_status "DynamoDB Tables Summary"
echo "Created the following tables:"
echo "  1. ${STACK_NAME}-kpi-document-chunks (stores processed document chunks)"
echo "  2. ${STACK_NAME}-kpi-retrieval-context (stores retrieval results)"
echo "  3. ${STACK_NAME}-kpi-responses (stores KPI extraction results - with streams)"
echo "  4. ${STACK_NAME}-kpi-final-output (stores final combined output)"
echo ""

# Get and display stream ARNs for use in Lambda setup
echo "Stream ARNs (needed for Lambda setup):"
KPI_RESPONSES_STREAM_ARN=$(aws dynamodb describe-table \
  --table-name "${STACK_NAME}-kpi-responses" \
  --query 'Table.LatestStreamArn' \
  --output text \
  --region $REGION)

FILE_STATUS_STREAM_ARN=$(aws dynamodb describe-table \
  --table-name "${STACK_NAME}-kpi-file-status" \
  --query 'Table.LatestStreamArn' \
  --output text \
  --region $REGION 2>/dev/null)

echo "  KPI Responses Stream: $KPI_RESPONSES_STREAM_ARN"
if [ "$FILE_STATUS_STREAM_ARN" != "" ] && [ "$FILE_STATUS_STREAM_ARN" != "None" ]; then
  echo "  File Status Stream: $FILE_STATUS_STREAM_ARN"
else
  echo "  File Status Stream: Not found (create in Stage 1)"
fi

print_success "DynamoDB setup completed successfully!"
