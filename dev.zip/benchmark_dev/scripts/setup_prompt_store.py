# FILE PATH: ./scripts/setup_prompt_store.py

import json
import sys
from datetime import datetime, timezone
from typing import Any, Dict, List

import boto3
from botocore.exceptions import ClientError
from common.config.env_vars import EnvironmentVariables as EnvVars
from common.schemas.prompt_store_schema import SAMPLE_PROMPT_TEMPLATES
from common.utils.logger import get_logger

logger = get_logger(__name__)


class PromptStoreSetup:
    """Setup utility for DynamoDB prompt store table and sample data."""

    def __init__(self, region_name: str = None):
        self.region_name = region_name or EnvVars.AWS_REGION
        self.dynamodb = boto3.resource("dynamodb", region_name=self.region_name)
        self.table_name = EnvVars.PROMPT_STORE_TABLE

    def create_prompt_store_table(self) -> bool:
        """
        Create the prompt store DynamoDB table with proper configuration.

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            print(f"Creating DynamoDB table: {self.table_name}")

            table = self.dynamodb.create_table(
                TableName=self.table_name,
                KeySchema=[
                    {"AttributeName": "bank_id", "KeyType": "HASH"},  # Partition key
                    {
                        "AttributeName": "document_category",
                        "KeyType": "RANGE",  # Sort key
                    },
                ],
                AttributeDefinitions=[
                    {"AttributeName": "bank_id", "AttributeType": "S"},
                    {"AttributeName": "document_category", "AttributeType": "S"},
                    {"AttributeName": "template_type", "AttributeType": "S"},
                    {"AttributeName": "language", "AttributeType": "S"},
                    {"AttributeName": "priority", "AttributeType": "N"},
                ],
                GlobalSecondaryIndexes=[
                    {
                        "IndexName": "template-type-priority-index",
                        "KeySchema": [
                            {"AttributeName": "template_type", "KeyType": "HASH"},
                            {"AttributeName": "priority", "KeyType": "RANGE"},
                        ],
                        "Projection": {"ProjectionType": "ALL"},
                        "ProvisionedThroughput": {
                            "ReadCapacityUnits": 5,
                            "WriteCapacityUnits": 5,
                        },
                    },
                    {
                        "IndexName": "language-priority-index",
                        "KeySchema": [
                            {"AttributeName": "language", "KeyType": "HASH"},
                            {"AttributeName": "priority", "KeyType": "RANGE"},
                        ],
                        "Projection": {"ProjectionType": "ALL"},
                        "ProvisionedThroughput": {
                            "ReadCapacityUnits": 5,
                            "WriteCapacityUnits": 5,
                        },
                    },
                ],
                BillingMode="PROVISIONED",
                ProvisionedThroughput={
                    "ReadCapacityUnits": 10,
                    "WriteCapacityUnits": 10,
                },
                StreamSpecification={
                    "StreamEnabled": True,
                    "StreamViewType": "NEW_AND_OLD_IMAGES",
                },
                SSESpecification={"Enabled": True},
                Tags=[
                    {"Key": "Project", "Value": "KPI-Extraction"},
                    {"Key": "Component", "Value": "PromptStore"},
                    {"Key": "Environment", "Value": EnvVars.ENVIRONMENT},
                ],
            )

            # Wait for table to be created
            print("Waiting for table to be created...")
            table.wait_until_exists()

            print(f"✅ Table {self.table_name} created successfully")
            return True

        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceInUseException":
                print(f"⚠️  Table {self.table_name} already exists")
                return True
            else:
                print(f"❌ Error creating table: {e}")
                return False
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            return False

    def populate_sample_templates(self) -> bool:
        """
        Populate the table with sample prompt templates.

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            table = self.dynamodb.Table(self.table_name)

            print(f"Populating {len(SAMPLE_PROMPT_TEMPLATES)} sample templates...")

            success_count = 0
            for i, template_data in enumerate(SAMPLE_PROMPT_TEMPLATES):
                try:
                    # Add timestamps
                    template_data["created_at"] = datetime.now(timezone.utc).isoformat()
                    template_data["updated_at"] = datetime.now(timezone.utc).isoformat()

                    # Put item in table
                    table.put_item(Item=template_data)

                    print(
                        f"✅ Created template: {template_data['bank_id']}/{template_data['document_category']}"
                    )
                    success_count += 1

                except Exception as e:
                    print(f"❌ Error creating template {i+1}: {e}")
                    continue

            print(
                f"✅ Successfully created {success_count}/{len(SAMPLE_PROMPT_TEMPLATES)} templates"
            )
            return success_count > 0

        except Exception as e:
            print(f"❌ Error populating templates: {e}")
            return False

    def validate_table_setup(self) -> Dict[str, Any]:
        """
        Validate the table setup and content.

        Returns:
            Dict[str, Any]: Validation results
        """
        try:
            table = self.dynamodb.Table(self.table_name)

            # Check table status
            table_info = table.meta.client.describe_table(TableName=self.table_name)
            table_status = table_info["Table"]["TableStatus"]

            # Count items
            response = table.scan(Select="COUNT")
            item_count = response["Count"]

            # Check for required templates
            required_templates = [
                ("default", "kpi_extraction_default"),
                ("default", "kpi_extraction_french"),
                ("default", "annual_report"),
                ("default", "serie_trimestrielle"),
            ]

            existing_templates = []
            missing_templates = []

            for bank_id, doc_category in required_templates:
                try:
                    response = table.get_item(
                        Key={"bank_id": bank_id, "document_category": doc_category}
                    )

                    if "Item" in response:
                        existing_templates.append(f"{bank_id}/{doc_category}")
                    else:
                        missing_templates.append(f"{bank_id}/{doc_category}")

                except Exception:
                    missing_templates.append(f"{bank_id}/{doc_category}")

            validation_result = {
                "table_status": table_status,
                "total_items": item_count,
                "existing_templates": existing_templates,
                "missing_templates": missing_templates,
                "validation_passed": table_status == "ACTIVE"
                and len(missing_templates) == 0,
                "gsi_status": {},
            }

            # Check GSI status
            for gsi in table_info["Table"].get("GlobalSecondaryIndexes", []):
                gsi_name = gsi["IndexName"]
                gsi_status = gsi["IndexStatus"]
                validation_result["gsi_status"][gsi_name] = gsi_status

            return validation_result

        except Exception as e:
            return {"error": str(e), "validation_passed": False}

    def cleanup_table(self) -> bool:
        """
        Delete the prompt store table (use with caution).

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            print(f"⚠️  Deleting table: {self.table_name}")

            table = self.dynamodb.Table(self.table_name)
            table.delete()

            print("Waiting for table deletion...")
            table.wait_until_not_exists()

            print(f"✅ Table {self.table_name} deleted successfully")
            return True

        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                print(f"⚠️  Table {self.table_name} does not exist")
                return True
            else:
                print(f"❌ Error deleting table: {e}")
                return False
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            return False

    def export_templates(
        self, output_file: str = "prompt_templates_backup.json"
    ) -> bool:
        """
        Export all templates to a JSON file.

        Args:
            output_file: Output file path

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            table = self.dynamodb.Table(self.table_name)

            print(f"Exporting templates to {output_file}...")

            # Scan all items
            response = table.scan()
            items = response["Items"]

            # Handle pagination
            while "LastEvaluatedKey" in response:
                response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
                items.extend(response["Items"])

            # Convert Decimal to float for JSON serialization
            def decimal_converter(obj):
                if hasattr(obj, "__float__"):
                    return float(obj)
                raise TypeError

            # Export to file
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(
                    items, f, indent=2, default=decimal_converter, ensure_ascii=False
                )

            print(f"✅ Exported {len(items)} templates to {output_file}")
            return True

        except Exception as e:
            print(f"❌ Error exporting templates: {e}")
            return False

    def import_templates(self, input_file: str) -> bool:
        """
        Import templates from a JSON file.

        Args:
            input_file: Input file path

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            table = self.dynamodb.Table(self.table_name)

            print(f"Importing templates from {input_file}...")

            # Read file
            with open(input_file, "r", encoding="utf-8") as f:
                items = json.load(f)

            success_count = 0
            for item in items:
                try:
                    # Update timestamp
                    item["updated_at"] = datetime.now(timezone.utc).isoformat()

                    table.put_item(Item=item)
                    success_count += 1

                except Exception as e:
                    print(
                        f"❌ Error importing template {item.get('bank_id')}/{item.get('document_category')}: {e}"
                    )
                    continue

            print(f"✅ Successfully imported {success_count}/{len(items)} templates")
            return success_count > 0

        except Exception as e:
            print(f"❌ Error importing templates: {e}")
            return False


def main():
    """Main setup function."""
    import argparse

    parser = argparse.ArgumentParser(description="Setup DynamoDB Prompt Store")
    parser.add_argument(
        "--action",
        choices=["create", "populate", "validate", "cleanup", "export", "import"],
        required=True,
        help="Action to perform",
    )
    parser.add_argument("--file", help="File path for export/import operations")
    parser.add_argument("--region", default=EnvVars.AWS_REGION, help="AWS region")
    parser.add_argument(
        "--force", action="store_true", help="Force operation without confirmation"
    )

    args = parser.parse_args()

    setup = PromptStoreSetup(args.region)

    if args.action == "create":
        print("🚀 Creating DynamoDB prompt store table...")
        success = setup.create_prompt_store_table()
        if success:
            print("✅ Table creation completed")
        else:
            print("❌ Table creation failed")
            sys.exit(1)

    elif args.action == "populate":
        print("📝 Populating sample prompt templates...")
        success = setup.populate_sample_templates()
        if success:
            print("✅ Template population completed")
        else:
            print("❌ Template population failed")
            sys.exit(1)

    elif args.action == "validate":
        print("🔍 Validating table setup...")
        result = setup.validate_table_setup()

        print(f"Table Status: {result.get('table_status')}")
        print(f"Total Items: {result.get('total_items')}")
        print(f"Existing Templates: {len(result.get('existing_templates', []))}")

        if result.get("missing_templates"):
            print(f"❌ Missing Templates: {result['missing_templates']}")

        if result.get("validation_passed"):
            print("✅ Validation passed")
        else:
            print("❌ Validation failed")
            sys.exit(1)

    elif args.action == "cleanup":
        if not args.force:
            confirm = input(
                "⚠️  This will DELETE the prompt store table. Are you sure? (yes/no): "
            )
            if confirm.lower() != "yes":
                print("Operation cancelled")
                sys.exit(0)

        print("🗑️  Cleaning up prompt store table...")
        success = setup.cleanup_table()
        if success:
            print("✅ Cleanup completed")
        else:
            print("❌ Cleanup failed")
            sys.exit(1)

    elif args.action == "export":
        output_file = (
            args.file
            or f"prompt_templates_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        )
        success = setup.export_templates(output_file)
        if not success:
            sys.exit(1)

    elif args.action == "import":
        if not args.file:
            print("❌ File path required for import operation")
            sys.exit(1)
        success = setup.import_templates(args.file)
        if not success:
            sys.exit(1)


if __name__ == "__main__":
    main()
