# Stage 1 Deployment Guide

## Overview
This guide covers the deployment of Stage 1: File Upload & Initial Processing for the KPI Extraction pipeline.

## Prerequisites

### AWS Setup
- AWS CLI configured with appropriate permissions
- Access to create Lambda functions, DynamoDB tables, S3 buckets, and IAM roles
- Region set to `eu-west-3` (or update scripts accordingly)

### Dependencies
- Python 3.9+
- boto3
- pydantic
- requests

## File Structure

```
stage1/
├── common/
│   ├── config/
│   │   └── env_vars.py
│   ├── models/
│   │   └── kpi_models.py
│   └── utils/
│       ├── dynamodb_utils.py
│       ├── s3_utils.py
│       └── logger.py
├── lambda_function.py
├── requirements.txt
├── setup.sh
├── test_stage1.py
└── sample_event.json
```

## Deployment Steps

### 1. Create AWS Resources

Run the setup script to create all necessary AWS resources:

```bash
chmod +x setup.sh
./setup.sh
```

This will create:
- S3 bucket: `benchmark-documents`
- DynamoDB tables:
  - `benchmark-kpi-analyze-status`
  - `benchmark-kpi-file-status`
- IAM role with appropriate permissions
- Lambda function: `benchmark-file-upload-handler-stage1`
- S3 trigger configuration

### 2. Package Lambda Function

Create a deployment package:

```bash
# Create deployment directory
mkdir -p deployment
cd deployment

# Copy source files
cp -r ../common .
cp ../lambda_function.py .
cp ../requirements.txt .

# Install dependencies
pip install -r requirements.txt -t .

# Create deployment package
zip -r ../file_upload_handler_stage1.zip .
cd ..
```

### 3. Upload to S3

Upload the deployment package to your S3 bucket:

```bash
aws s3 cp file_upload_handler_stage1.zip s3://tmp-storage-benchmark/
```

### 4. Update Lambda Function

Update the Lambda function with your deployment package:

```bash
aws lambda update-function-code \
  --function-name benchmark-file-upload-handler-stage1 \
  --s3-bucket tmp-storage-benchmark \
  --s3-key file_upload_handler_stage1.zip
```

### 5. Configure Docling Endpoint

Update the Lambda function environment variable with your actual Docling endpoint:

```bash
aws lambda update-function-configuration \
  --function-name benchmark-file-upload-handler-stage1 \
  --environment Variables='{
    "KPI_ANALYZE_STATUS_TABLE": "benchmark-kpi-analyze-status",
    "KPI_FILE_STATUS_TABLE": "benchmark-kpi-file-status", 
    "DOCLING_ENDPOINT_URL": "https://your-actual-sagemaker-endpoint.execute-api.eu-west-3.amazonaws.com/docling",
    "DOCUMENTS_BUCKET": "benchmark-documents",
    "MAX_FILE_SIZE_MB": "100",
    "SUPPORTED_FILE_TYPES": "pdf,xlsx,xls",
    "DOCLING_TIMEOUT": "600",
    "LOG_LEVEL": "INFO",
    "AWS_LAMBDA_FUNCTION_NAME": "benchmark-file-upload-handler-stage1"
  }'
```

## Testing

### 1. Unit Tests

Run the test script:

```bash
python test_stage1.py
```

### 2. Integration Testing

Create a sample analyze record in DynamoDB:

```python
import boto3
import uuid
from datetime import datetime, timezone

dynamodb = boto3.client('dynamodb')

analyze_id = str(uuid.uuid4())
record = {
    'analyze_id': {'S': analyze_id},
    'bank_id': {'S': 'TEST001'},
    'bank_is_french': {'BOOL': True},
    'status': {'S': 'processing'},
    'kpi_list': {'L': [{'S': 'Net Income'}, {'S': 'Revenue'}]},
    'taxonomy': {'M': {}},
    'kpi_detail_levels': {'M': {}},
    'expected_files': {'L': [{'S': 'serie_trimestrielle'}]},
    'total_files': {'N': '1'},
    'created_at': {'S': datetime.now(timezone.utc).isoformat()},
    'updated_at': {'S': datetime.now(timezone.utc).isoformat()},
    'current_step': {'S': 'file_validation'}
}

dynamodb.put_item(TableName='benchmark-kpi-analyze-status', Item=record)
print(f"Created test analyze record: {analyze_id}")
```

### 3. Upload Test File

Upload a test file to trigger the Lambda:

```bash
# Upload test PDF to S3
aws s3 cp test_document.pdf s3://benchmark-documents/input/${ANALYZE_ID}/${FILE_ID}/test_quarterly_report.pdf
```

Replace `${ANALYZE_ID}` and `${FILE_ID}` with actual UUIDs.

## Monitoring

### CloudWatch Logs

Monitor Lambda execution:

```bash
aws logs tail /aws/lambda/benchmark-file-upload-handler-stage1 --follow
```

### DynamoDB Items

Check analyze status:

```bash
aws dynamodb get-item \
  --table-name benchmark-kpi-analyze-status \
  --key '{"analyze_id": {"S": "YOUR_ANALYZE_ID"}}'
```

Check file status:

```bash
aws dynamodb get-item \
  --table-name benchmark-kpi-file-status \
  --key '{"file_id": {"S": "YOUR_FILE_ID"}}'
```

## Troubleshooting

### Common Issues

1. **Lambda timeout**: Increase timeout value if processing large files
2. **DynamoDB permissions**: Ensure Lambda role has read/write access
3. **S3 permissions**: Verify Lambda can read from the documents bucket
4. **Docling endpoint**: Confirm the endpoint URL is correct and accessible

### Error Messages

- `"File validation failed"`: Check file format and integrity
- `"Analyze record not found"`: Ensure analyze record exists in DynamoDB
- `"Docling processing failed"`: Verify Docling endpoint configuration

## Next Steps

After Stage 1 is deployed and tested:

1. Configure your Docling SageMaker endpoint
2. Set up monitoring and alerting
3. Proceed to Stage 2 implementation
4. Integrate with your frontend application

## Security Considerations

- Review IAM permissions (principle of least privilege)
- Enable S3 bucket encryption
- Configure VPC endpoints if required
- Set up AWS CloudTrail for audit logging

## Cost Optimization

- Monitor Lambda invocations and duration
- Review DynamoDB read/write capacity
- Set up S3 lifecycle policies
- Use reserved capacity for predictable workloads
