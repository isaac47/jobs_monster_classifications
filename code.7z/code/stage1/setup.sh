#!/bin/bash
# KPI Extraction Stage 1 Setup Commands
# This script creates the necessary AWS resources for Stage 1: File Upload & Initial Processing

# Set variables
STACK_NAME="benchmark"
REGION="eu-west-3"
ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)
BUCKET_NAME="tmp-storage-benchmark"

echo "Creating KPI Extraction Stage 1 Resources for $STACK_NAME..."

# Create S3 Bucket for documents
aws s3api create-bucket \
  --bucket "$STACK_NAME-documents" \
  --create-bucket-configuration LocationConstraint=$REGION

# Enable bucket versioning
aws s3api put-bucket-versioning \
  --bucket "$STACK_NAME-documents" \
  --versioning-configuration Status=Enabled

# Add CORS configuration
aws s3api put-bucket-cors \
  --bucket "$STACK_NAME-documents" \
  --cors-configuration '{
    "CORSRules": [
      {
        "AllowedHeaders": ["*"],
        "AllowedMethods": ["GET", "PUT", "POST", "DELETE", "HEAD"],
        "AllowedOrigins": ["*"],
        "MaxAgeSeconds": 3600
      }
    ]
  }'

# Add lifecycle configuration
aws s3api put-bucket-lifecycle-configuration \
  --bucket "$STACK_NAME-documents" \
  --lifecycle-configuration '{
    "Rules": [
      {
        "ID": "DeleteOldVersions",
        "Status": "Enabled",
        "NoncurrentVersionExpiration": {
          "NoncurrentDays": 30
        }
      },
      {
        "ID": "DeleteIncompleteMultipartUploads",
        "Status": "Enabled",
        "AbortIncompleteMultipartUpload": {
          "DaysAfterInitiation": 7
        }
      }
    ]
  }'

# Add encryption configuration
aws s3api put-bucket-encryption \
  --bucket "$STACK_NAME-documents" \
  --server-side-encryption-configuration '{
    "Rules": [
      {
        "ApplyServerSideEncryptionByDefault": {
          "SSEAlgorithm": "AES256"
        },
        "BucketKeyEnabled": true
      }
    ]
  }'

echo "Created S3 Bucket: $STACK_NAME-documents"

# Create DynamoDB Tables for Stage 1

# KPI Analyze Status Table
aws dynamodb create-table \
  --table-name "$STACK_NAME-kpi-analyze-status" \
  --attribute-definitions \
    AttributeName=analyze_id,AttributeType=S \
  --key-schema \
    AttributeName=analyze_id,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST

echo "Created DynamoDB table: $STACK_NAME-kpi-analyze-status"

# KPI File Status Table
aws dynamodb create-table \
  --table-name "$STACK_NAME-kpi-file-status" \
  --attribute-definitions \
    AttributeName=file_id,AttributeType=S \
    AttributeName=analyze_id,AttributeType=S \
  --key-schema \
    AttributeName=file_id,KeyType=HASH \
  --global-secondary-indexes \
    IndexName=analyze-id-index,KeySchema=[{AttributeName=analyze_id,KeyType=HASH}],Projection={ProjectionType=ALL} \
  --billing-mode PAY_PER_REQUEST

echo "Created DynamoDB table: $STACK_NAME-kpi-file-status"

# Create IAM Role for Lambda functions
LAMBDA_ROLE_NAME="$STACK_NAME-stage1-lambda-role"
LAMBDA_ROLE_ARN=$(aws iam create-role \
  --role-name $LAMBDA_ROLE_NAME \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Principal": {"Service": "lambda.amazonaws.com"},
      "Action": "sts:AssumeRole"
    }]
  }' \
  --query "Role.Arn" \
  --output text)

# Attach policies to the Lambda role
aws iam attach-role-policy \
  --role-name $LAMBDA_ROLE_NAME \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# Create custom policy for Stage 1 Lambda
STAGE1_POLICY_DOC=$(cat << 'EOF'
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:GetObjectMetadata",
                "s3:HeadObject"
            ],
            "Resource": [
                "arn:aws:s3:::benchmark-documents/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "dynamodb:GetItem",
                "dynamodb:PutItem",
                "dynamodb:UpdateItem",
                "dynamodb:Scan",
                "dynamodb:Query"
            ],
            "Resource": [
                "arn:aws:dynamodb:eu-west-3:*:table/benchmark-kpi-analyze-status",
                "arn:aws:dynamodb:eu-west-3:*:table/benchmark-kpi-file-status",
                "arn:aws:dynamodb:eu-west-3:*:table/benchmark-kpi-file-status/index/*"
            ]
        }
    ]
}
EOF
)

STAGE1_POLICY_ARN=$(aws iam create-policy \
  --policy-name "$STACK_NAME-stage1-lambda-policy" \
  --policy-document "$STAGE1_POLICY_DOC" \
  --query "Policy.Arn" \
  --output text)

aws iam attach-role-policy \
  --role-name $LAMBDA_ROLE_NAME \
  --policy-arn $STAGE1_POLICY_ARN

echo "Created IAM Role for Lambda functions: $LAMBDA_ROLE_ARN"

# Wait for role propagation
echo "Waiting for IAM role propagation..."
sleep 15

# Create File Upload Handler Lambda
KEY_NAME="file_upload_handler_stage1.zip"
UPLOAD_HANDLER_FUNCTION_ARN=$(aws lambda create-function \
  --function-name "$STACK_NAME-file-upload-handler-stage1" \
  --runtime python3.9 \
  --role $LAMBDA_ROLE_ARN \
  --handler lambda_function.handler \
  --code S3Bucket=$BUCKET_NAME,S3Key=$KEY_NAME \
  --environment "Variables={
    KPI_ANALYZE_STATUS_TABLE=$STACK_NAME-kpi-analyze-status,
    KPI_FILE_STATUS_TABLE=$STACK_NAME-kpi-file-status,
    DOCLING_ENDPOINT_URL=https://your-sagemaker-endpoint.execute-api.$REGION.amazonaws.com/docling,
    DOCUMENTS_BUCKET=$STACK_NAME-documents,
    MAX_FILE_SIZE_MB=100,
    SUPPORTED_FILE_TYPES=pdf,xlsx,xls,
    DOCLING_TIMEOUT=600,
    LOG_LEVEL=INFO,
    AWS_LAMBDA_FUNCTION_NAME=$STACK_NAME-file-upload-handler-stage1
  }" \
  --timeout 300 \
  --memory-size 512 \
  --query "FunctionArn" \
  --output text)

echo "Created File Upload Handler Lambda function: $UPLOAD_HANDLER_FUNCTION_ARN"

# Add S3 trigger to Lambda function
aws lambda add-permission \
  --function-name "$STACK_NAME-file-upload-handler-stage1" \
  --principal s3.amazonaws.com \
  --action lambda:InvokeFunction \
  --statement-id s3-trigger-statement \
  --source-arn "arn:aws:s3:::$STACK_NAME-documents"

# Configure S3 bucket notification
NOTIFICATION_CONFIG=$(cat << EOF
{
  "LambdaConfigurations": [
    {
      "Id": "file-upload-trigger",
      "LambdaFunctionArn": "$UPLOAD_HANDLER_FUNCTION_ARN",
      "Events": ["s3:ObjectCreated:*"],
      "Filter": {
        "Key": {
          "FilterRules": [
            {
              "Name": "prefix",
              "Value": "input/"
            }
          ]
        }
      }
    }
  ]
}
EOF
)

aws s3api put-bucket-notification-configuration \
  --bucket "$STACK_NAME-documents" \
  --notification-configuration "$NOTIFICATION_CONFIG"

echo "Configured S3 bucket notification for Lambda trigger"

echo ""
echo "=== Stage 1 Setup Complete ==="
echo "S3 Document Bucket: $STACK_NAME-documents"
echo "Analyze Status Table: $STACK_NAME-kpi-analyze-status"
echo "File Status Table: $STACK_NAME-kpi-file-status"
echo "File Upload Handler Lambda: $UPLOAD_HANDLER_FUNCTION_ARN"
echo ""
echo "Next steps:"
echo "1. Update DOCLING_ENDPOINT_URL environment variable with actual endpoint"
echo "2. Upload your Lambda deployment package to S3"
echo "3. Test with sample file uploads"
echo ""
echo "Stage 1 setup completed successfully!"
