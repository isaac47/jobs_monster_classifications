import os


class EnvironmentVariables:
    """
    Environment variable configuration for KPI Extraction Stage 2.
    """

    # DynamoDB tables for KPI extraction pipeline
    KPI_ANALYZE_STATUS_TABLE = os.environ.get(
        "KPI_ANALYZE_STATUS_TABLE", "benchmark-kpi-analyze-status"
    )
    KPI_FILE_STATUS_TABLE = os.environ.get(
        "KPI_FILE_STATUS_TABLE", "benchmark-kpi-file-status"
    )
    KPI_DOCUMENT_CHUNKS_TABLE = os.environ.get(
        "KPI_DOCUMENT_CHUNKS_TABLE", "benchmark-kpi-document-chunks"
    )

    # SQS queues for pipeline stages
    EMBEDDING_QUEUE_NAME = os.environ.get(
        "EMBEDDING_QUEUE_NAME", "benchmark-embedding-queue"
    )

    # External service endpoints
    DOCLING_ENDPOINT_URL = os.environ.get("DOCLING_ENDPOINT_URL", "")

    # Bedrock configuration for image processing
    BEDROCK_REGION = os.environ.get("BEDROCK_REGION", "us-east-1")
    BEDROCK_VISION_MODEL = os.environ.get(
        "BEDROCK_VISION_MODEL", "anthropic.claude-3-sonnet-20240229-v1:0"
    )

    # Processing configuration
    MAX_FILE_SIZE_MB = int(os.environ.get("MAX_FILE_SIZE_MB", "100"))
    SUPPORTED_FILE_TYPES = os.environ.get("SUPPORTED_FILE_TYPES", "pdf,xlsx,xls").split(
        ","
    )
    MAX_IMAGES_PER_DOCUMENT = int(os.environ.get("MAX_IMAGES_PER_DOCUMENT", "50"))

    # Retry and timeout configurations
    MAX_RETRIES = int(os.environ.get("MAX_RETRIES", "3"))
    DOCLING_TIMEOUT = int(os.environ.get("DOCLING_TIMEOUT", "600"))
    BEDROCK_TIMEOUT = int(os.environ.get("BEDROCK_TIMEOUT", "300"))

    # Logging
    LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")

    # Lambda function identification
    AWS_LAMBDA_FUNCTION_NAME = os.environ.get(
        "AWS_LAMBDA_FUNCTION_NAME", "stage2-status-handler"
    )

    # S3 configuration
    DOCUMENTS_BUCKET = os.environ.get("DOCUMENTS_BUCKET", "benchmark-documents")
