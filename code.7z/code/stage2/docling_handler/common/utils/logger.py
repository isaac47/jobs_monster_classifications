import json
import logging
import os
import sys
import traceback
from datetime import datetime


class JSONFormatter(logging.Formatter):
    """
    Formatter for JSON logging.
    """

    def format(self, record):
        log_record = {
            "timestamp": datetime.utcfromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
            "function": record.funcName,
            "line": record.lineno,
        }

        # Add exception info if present
        if record.exc_info:
            log_record["exception"] = {
                "type": record.exc_info[0].__name__,
                "message": str(record.exc_info[1]),
                "traceback": traceback.format_exception(*record.exc_info),
            }

        # Add extra fields from record
        for key, value in record.__dict__.items():
            if key not in {
                "args",
                "asctime",
                "created",
                "exc_info",
                "exc_text",
                "filename",
                "funcName",
                "id",
                "levelname",
                "levelno",
                "lineno",
                "module",
                "msecs",
                "message",
                "msg",
                "name",
                "pathname",
                "process",
                "processName",
                "relativeCreated",
                "stack_info",
                "thread",
                "threadName",
            }:
                log_record[key] = value

        return json.dumps(log_record, default=str)


def get_logger(name, level=None):
    """
    Get a configured logger.

    Args:
        name: Logger name
        level: Optional log level (if None, uses environment variable or defaults to INFO)

    Returns:
        logging.Logger: Configured logger
    """
    # Get log level from environment variable or use default
    if level is None:
        level = os.environ.get("LOG_LEVEL", "INFO").upper()

    numeric_level = getattr(logging, level, logging.INFO)

    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(numeric_level)

    # Clear existing handlers
    logger.handlers = []

    # Create and add handler
    handler = logging.StreamHandler(sys.stdout)

    # Use JSON simpler format
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger


def set_log_level(logger, level):
    """
    Set the log level for a logger.

    Args:
        logger: Logger to configure
        level: Log level (string or numeric)
    """
    if isinstance(level, str):
        numeric_level = getattr(logging, level.upper(), logging.INFO)
    else:
        numeric_level = level

    logger.setLevel(numeric_level)

    # Also update handlers
    for handler in logger.handlers:
        handler.setLevel(numeric_level)


def log_execution_time(logger, start_time, operation_name):
    """
    Log the execution time of an operation.

    Args:
        logger: Logger to use
        start_time: Start time from datetime.now()
        operation_name: Name of the operation
    """
    end_time = datetime.now()
    execution_time = (end_time - start_time).total_seconds()
    logger.info(f"{operation_name} completed in {execution_time:.2f} seconds")


class LogContext:
    """
    Context manager for logging execution time.

    Example:
        with LogContext(logger, "Processing file"):
            # Do something
    """

    def __init__(self, logger, operation_name):
        self.logger = logger
        self.operation_name = operation_name

    def __enter__(self):
        self.start_time = datetime.now()
        self.logger.info(f"Starting {self.operation_name}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        end_time = datetime.now()
        execution_time = (end_time - self.start_time).total_seconds()

        if exc_type:
            self.logger.error(
                f"{self.operation_name} failed after {execution_time:.2f} seconds: {exc_val}"
            )
        else:
            self.logger.info(
                f"{self.operation_name} completed in {execution_time:.2f} seconds"
            )
