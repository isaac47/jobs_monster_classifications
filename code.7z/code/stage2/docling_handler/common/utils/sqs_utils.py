import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


def get_sqs_client():
    """Get the SQS client."""
    return boto3.client("sqs")


def get_queue_url(queue_name: str) -> Optional[str]:
    """
    Get SQS queue URL by queue name.

    Args:
        queue_name: SQS queue name

    Returns:
        Optional[str]: Queue URL or None if not found
    """
    client = get_sqs_client()
    try:
        response = client.get_queue_url(QueueName=queue_name)
        return response["QueueUrl"]
    except ClientError as e:
        if e.response["Error"]["Code"] == "AWS.SimpleQueueService.NonExistentQueue":
            logger.error(f"Queue does not exist: {queue_name}")
        else:
            logger.error(f"Error getting queue URL: {e}")
        return None


def send_message(
    queue_url: str,
    message_body: Dict[str, Any],
    message_attributes: Optional[Dict[str, Any]] = None,
    delay_seconds: int = 0,
) -> Optional[str]:
    """
    Send a message to an SQS queue.

    Args:
        queue_url: SQS queue URL
        message_body: Message body (will be JSON serialized)
        message_attributes: Optional message attributes
        delay_seconds: Delay before message becomes available

    Returns:
        Optional[str]: Message ID or None if failed
    """
    client = get_sqs_client()
    try:
        params = {
            "QueueUrl": queue_url,
            "MessageBody": json.dumps(message_body, default=str),
        }

        if message_attributes:
            params["MessageAttributes"] = message_attributes

        if delay_seconds > 0:
            params["DelaySeconds"] = delay_seconds

        response = client.send_message(**params)
        return response["MessageId"]
    except ClientError as e:
        logger.error(f"Error sending message to queue: {e}")
        return None


def send_embedding_message(
    queue_url: str, file_id: str, analyze_id: str, delay_seconds: int = 0
) -> Optional[str]:
    """
    Send a message to the embedding processing queue.

    Args:
        queue_url: Embedding queue URL
        file_id: File identifier
        analyze_id: Analyze identifier
        delay_seconds: Delay before processing

    Returns:
        Optional[str]: Message ID or None if failed
    """
    message = {
        "file_id": file_id,
        "analyze_id": analyze_id,
        "stage": "embedding",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source_stage": "docling_complete",
    }

    return send_message(queue_url, message, delay_seconds=delay_seconds)
