from typing import Any, Dict, Optional
import json
import boto3
from urllib.parse import urlparse

from botocore.exceptions import ClientError
from utils.logger import get_logger

logger = get_logger(__name__)

def get_s3_client():
    """Get the S3 client."""
    return boto3.client('s3')

def download_from_s3(bucket: str, key: str) -> Optional[bytes]:
    """
    Download data from S3.
    
    Args:
        bucket: S3 bucket name
        key: S3 object key
        
    Returns:
        Optional[bytes]: Downloaded data or None if failed
    """
    client = get_s3_client()
    try:
        response = client.get_object(Bucket=bucket, Key=key)
        return response['Body'].read()
    except ClientError as e:
        logger.error(f"Error downloading from S3: {e}")
        return None
    


def get_s3_object_metadata(bucket: str, key: str) -> Optional[Dict[str, Any]]:
    """
    Get S3 object metadata.

    Args:
        bucket: S3 bucket name
        key: S3 object key

    Returns:
        Optional[Dict[str, Any]]: Object metadata or None if failed
    """
    client = get_s3_client()
    try:
        response = client.head_object(Bucket=bucket, Key=key)
        return {
            "metadata": response.get("Metadata", {}),
            "content_type": response.get("ContentType"),
            "content_length": response.get("ContentLength"),
            "last_modified": response.get("LastModified"),
            "e_tag": response.get("ETag"),
        }
    except ClientError as e:
        logger.error(f"Error getting S3 object metadata: {e}")
        return None


def parse_s3_url(s3_url: str) -> Dict[str, str]:
    """
    Parse an S3 URL into bucket and key.
    
    Args:
        s3_url: S3 URL (s3://bucket/key)
        
    Returns:
        Dict[str, str]: Dictionary with 'bucket' and 'key'
    """
    parsed_url = urlparse(s3_url)
    if parsed_url.scheme != 's3':
        raise ValueError(f"Not an S3 URL: {s3_url}")
    
    bucket = parsed_url.netloc
    # Remove leading slash from key
    key = parsed_url.path.lstrip('/')
    
    return {'bucket': bucket, 'key': key}


def upload_json_to_s3(bucket: str, key: str, data: Dict[str, Any], metadata: Optional[Dict[str, str]] = None) -> bool:
    """
    Upload JSON data to S3.
    
    Args:
        bucket: S3 bucket name
        key: S3 object key
        data: JSON-serializable data to upload
        metadata: Optional metadata
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        json_str = json.dumps(data)
        return upload_to_s3(bucket, key, json_str, metadata)
    except (TypeError, ValueError) as e:
        logger.error(f"Error serializing JSON: {e}")
        return False
