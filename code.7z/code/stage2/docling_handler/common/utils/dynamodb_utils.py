import json
from decimal import Decimal
from typing import Any, Dict, List, Optional, Union

import boto3
from boto3.dynamodb.conditions import Attr, Key
from botocore.exceptions import ClientError
from common.utils.logger import get_logger

logger = get_logger(__name__)


def get_dynamodb_client():
    """Get the DynamoDB client."""
    return boto3.client("dynamodb")


def get_dynamodb_resource():
    """Get the DynamoDB resource."""
    return boto3.resource("dynamodb")


def convert_to_dynamodb_format(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a Python dictionary to DynamoDB format.

    Args:
        item: Dictionary to convert

    Returns:
        Dict[str, Any]: Converted dictionary
    """
    if not item:
        return {}

    result = {}
    for key, value in item.items():
        if isinstance(value, dict):
            result[key] = {"M": convert_to_dynamodb_format(value)}
        elif isinstance(value, list):
            result[key] = {
                "L": [
                    (
                        convert_to_dynamodb_format(item)
                        if isinstance(item, dict)
                        else {"S" if isinstance(item, str) else "N": str(item)}
                    )
                    for item in value
                ]
            }
        elif isinstance(value, str):
            result[key] = {"S": value}
        elif isinstance(value, (int, float, Decimal)):
            result[key] = {"N": str(value)}
        elif isinstance(value, bool):
            result[key] = {"BOOL": value}
        elif value is None:
            result[key] = {"NULL": True}

    return result


def convert_from_dynamodb_format(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a DynamoDB format dictionary to a Python dictionary.

    Args:
        item: DynamoDB format dictionary

    Returns:
        Dict[str, Any]: Converted dictionary
    """
    if not item:
        return {}

    result = {}
    for key, value in item.items():
        if "M" in value:
            result[key] = convert_from_dynamodb_format(value["M"])
        elif "L" in value:
            result[key] = [
                (
                    convert_from_dynamodb_format(item)
                    if "M" in item
                    else item.get("S", item.get("N", item.get("BOOL", None)))
                )
                for item in value["L"]
            ]
        elif "S" in value:
            result[key] = value["S"]
        elif "N" in value:
            try:
                num = Decimal(value["N"])
                # Convert to int if it's a whole number
                if num % 1 == 0:
                    result[key] = int(num)
                else:
                    result[key] = float(num)
            except:
                result[key] = value["N"]  # Keep as string if conversion fails
        elif "BOOL" in value:
            result[key] = value["BOOL"]
        elif "NULL" in value:
            result[key] = None

    return result


def put_item(
    table_name: str, item: Dict[str, Any], condition_expression: Optional[str] = None
) -> bool:
    """
    Put an item into a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        item: Item to put
        condition_expression: Optional condition expression

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_dynamodb_client()
    try:
        params = {"TableName": table_name, "Item": convert_to_dynamodb_format(item)}

        if condition_expression:
            params["ConditionExpression"] = condition_expression

        client.put_item(**params)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            logger.info(f"Condition check failed for item: {item}")
        else:
            logger.error(f"Error putting item: {e}")
        return False


def get_item(table_name: str, key: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Get an item from a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        key: Primary key of the item to get

    Returns:
        Optional[Dict[str, Any]]: Item or None if not found or failed
    """
    client = get_dynamodb_client()
    try:
        response = client.get_item(
            TableName=table_name, Key=convert_to_dynamodb_format(key)
        )

        if "Item" in response:
            return convert_from_dynamodb_format(response["Item"])
        else:
            return None
    except ClientError as e:
        logger.error(f"Error getting item: {e}")
        return None


def update_item(
    table_name: str,
    key: Dict[str, Any],
    update_expression: str,
    expression_attribute_values: Dict[str, Any],
    expression_attribute_names: Optional[Dict[str, str]] = None,
    condition_expression: Optional[str] = None,
) -> bool:
    """
    Update an item in a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        key: Primary key of the item to update
        update_expression: Update expression
        expression_attribute_values: Expression attribute values
        expression_attribute_names: Optional expression attribute names
        condition_expression: Optional condition expression

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_dynamodb_client()
    try:
        params = {
            "TableName": table_name,
            "Key": convert_to_dynamodb_format(key),
            "UpdateExpression": update_expression,
            "ExpressionAttributeValues": convert_to_dynamodb_format(
                expression_attribute_values
            ),
        }

        if expression_attribute_names:
            params["ExpressionAttributeNames"] = expression_attribute_names

        if condition_expression:
            params["ConditionExpression"] = condition_expression

        client.update_item(**params)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            logger.info(f"Condition check failed for update: {key}")
        else:
            logger.error(f"Error updating item: {e}")
        return False


def delete_item(
    table_name: str, key: Dict[str, Any], condition_expression: Optional[str] = None
) -> bool:
    """
    Delete an item from a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        key: Primary key of the item to delete
        condition_expression: Optional condition expression

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_dynamodb_client()
    try:
        params = {"TableName": table_name, "Key": convert_to_dynamodb_format(key)}

        if condition_expression:
            params["ConditionExpression"] = condition_expression

        client.delete_item(**params)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            logger.info(f"Condition check failed for delete: {key}")
        else:
            logger.error(f"Error deleting item: {e}")
        return False


def query_items(
    table_name: str,
    key_condition_expression: str,
    expression_attribute_values: Dict[str, Any],
    index_name: Optional[str] = None,
    filter_expression: Optional[str] = None,
    expression_attribute_names: Optional[Dict[str, str]] = None,
    limit: Optional[int] = None,
    scan_index_forward: bool = True,
) -> List[Dict[str, Any]]:
    """
    Query items from a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        key_condition_expression: Key condition expression
        expression_attribute_values: Expression attribute values
        index_name: Optional index name
        filter_expression: Optional filter expression
        expression_attribute_names: Optional expression attribute names
        limit: Optional maximum number of items to return
        scan_index_forward: Whether to scan in forward direction (default: True)

    Returns:
        List[Dict[str, Any]]: List of items
    """
    client = get_dynamodb_client()
    try:
        params = {
            "TableName": table_name,
            "KeyConditionExpression": key_condition_expression,
            "ExpressionAttributeValues": convert_to_dynamodb_format(
                expression_attribute_values
            ),
            "ScanIndexForward": scan_index_forward,
        }

        if index_name:
            params["IndexName"] = index_name

        if filter_expression:
            params["FilterExpression"] = filter_expression

        if expression_attribute_names:
            params["ExpressionAttributeNames"] = expression_attribute_names

        if limit:
            params["Limit"] = limit

        paginator = client.get_paginator("query")
        page_iterator = paginator.paginate(**params)

        items = []
        for page in page_iterator:
            if "Items" in page:
                for item in page["Items"]:
                    items.append(convert_from_dynamodb_format(item))

        return items
    except ClientError as e:
        logger.error(f"Error querying items: {e}")
        return []


def scan_items(
    table_name: str,
    filter_expression: Optional[str] = None,
    expression_attribute_values: Optional[Dict[str, Any]] = None,
    expression_attribute_names: Optional[Dict[str, str]] = None,
    index_name: Optional[str] = None,
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Scan items from a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        filter_expression: Optional filter expression
        expression_attribute_values: Optional expression attribute values
        expression_attribute_names: Optional expression attribute names
        index_name: Optional index name
        limit: Optional maximum number of items to return

    Returns:
        List[Dict[str, Any]]: List of items
    """
    client = get_dynamodb_client()
    try:
        params = {"TableName": table_name}

        if filter_expression:
            params["FilterExpression"] = filter_expression

        if expression_attribute_values:
            params["ExpressionAttributeValues"] = convert_to_dynamodb_format(
                expression_attribute_values
            )

        if expression_attribute_names:
            params["ExpressionAttributeNames"] = expression_attribute_names

        if index_name:
            params["IndexName"] = index_name

        if limit:
            params["Limit"] = limit

        paginator = client.get_paginator("scan")
        page_iterator = paginator.paginate(**params)

        items = []
        for page in page_iterator:
            if "Items" in page:
                for item in page["Items"]:
                    items.append(convert_from_dynamodb_format(item))

        return items
    except ClientError as e:
        logger.error(f"Error scanning items: {e}")
        return []


def batch_write_items(
    table_name: str, items: List[Dict[str, Any]]
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Write multiple items to a DynamoDB table in batches.

    Args:
        table_name: DynamoDB table name
        items: List of items to write

    Returns:
        Dict[str, List[Dict[str, Any]]]: Unprocessed items
    """
    client = get_dynamodb_client()
    unprocessed_items = []

    try:
        # Process in batches of 25 (DynamoDB limit)
        batch_size = 25
        for i in range(0, len(items), batch_size):
            batch = items[i : i + batch_size]
            request_items = {
                table_name: [
                    {"PutRequest": {"Item": convert_to_dynamodb_format(item)}}
                    for item in batch
                ]
            }

            response = client.batch_write_item(RequestItems=request_items)

            # Handle unprocessed items
            if (
                response["UnprocessedItems"]
                and table_name in response["UnprocessedItems"]
            ):
                for item in response["UnprocessedItems"][table_name]:
                    if "PutRequest" in item:
                        unprocessed_items.append(
                            convert_from_dynamodb_format(item["PutRequest"]["Item"])
                        )

        return {"UnprocessedItems": unprocessed_items}
    except ClientError as e:
        logger.error(f"Error in batch write: {e}")
        return {"UnprocessedItems": items, "Error": str(e)}


def create_table(
    table_name: str,
    key_schema: List[Dict[str, str]],
    attribute_definitions: List[Dict[str, str]],
    provisioned_throughput: Dict[str, int],
    global_secondary_indexes: Optional[List[Dict[str, Any]]] = None,
) -> bool:
    """
    Create a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        key_schema: Key schema
        attribute_definitions: Attribute definitions
        provisioned_throughput: Provisioned throughput
        global_secondary_indexes: Optional global secondary indexes

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_dynamodb_client()
    try:
        params = {
            "TableName": table_name,
            "KeySchema": key_schema,
            "AttributeDefinitions": attribute_definitions,
            "ProvisionedThroughput": provisioned_throughput,
        }

        if global_secondary_indexes:
            params["GlobalSecondaryIndexes"] = global_secondary_indexes

        client.create_table(**params)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceInUseException":
            logger.info(f"Table {table_name} already exists")
            return True
        logger.error(f"Error creating table: {e}")
        return False
