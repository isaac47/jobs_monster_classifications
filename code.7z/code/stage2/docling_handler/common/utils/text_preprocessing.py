import re
from typing import Any, Dict, List

import tiktoken

from utils.logger import get_logger
logger = get_logger(__name__)


def remove_numbers_from_text(text, remove_type='all_digits', preserve_spaces=True):
    """
    Removes numeric characters from text with various options.
    
    Args:
        text (str): Input text string
        remove_type (str): Type of removal:
            - 'all_digits': Removes individual digits (1, 2, 3)
            - 'numbers_only': Removes only standalone numbers
            - 'numbers_with_commas': Removes numbers with commas/decimals
            - 'all_numeric': Removes anything with digits including mixed text-numbers
        preserve_spaces (bool): If True, preserves the spacing where numbers were removed
        
    Returns:
        str: Text with numbers removed according to the specified options
    """
    if not text:
        return text
        
    if remove_type == 'all_digits':
        # Remove any digit (0-9)
        pattern = r'\d'
    elif remove_type == 'numbers_only':
        # Remove standalone numbers (with optional +/- prefix)
        pattern = r'(?<!\w)[-+]?\d+(?:\.\d+)?(?!\w)'
    elif remove_type == 'numbers_with_commas':
        # Remove numbers with commas and decimals
        pattern = r'(?<!\w)[-+]?\d{1,3}(?:,\d{3})*(?:\.\d+)?(?!\w)'
    elif remove_type == 'all_numeric':
        # Remove whole words containing any digit
        pattern = r'\b\w*\d+\w*\b'
    else:
        raise ValueError("Invalid remove_type. Choose from: 'all_digits', 'numbers_only', 'numbers_with_commas', 'all_numeric'")
    
    if preserve_spaces:
        return re.sub(pattern, ' ', text)
    else:
        return re.sub(pattern, '', text)

class ChunkProcessor:
    def __init__(self, token_threshold: float = 0.3, encoding_name: str = "cl100k_base"):
        """
        Initialize the ChunkProcessor with a threshold for numeric content.
        
        Args:
        token_threshold: Maximum percentage of numeric-only tokens allowed (default: 0.3 or 30%)
        encoding_name: The name of the tiktoken encoding to use.
            - 'cl100k_base' for Claude and most models
            - 'p50k_base' for GPT-3 models
            - 'r50k_base' for CodeX models        
        """
        self.token_threshold = token_threshold
        self.encoding = tiktoken.get_encoding(encoding_name)
 
    def _get_tokens(self, text: str) -> list:
        """
        Count tokens using tiktoken encoding.
        
        Args:
        text: The input text
        
        Returns:
        The ids of tokens
        """
        if not text:
            return []
        return self.encoding.encode(text)
 
    def _is_numeric_token(self, token_bytes: bytes) -> bool:
        """
        Check if a token (in bytes) represents a numeric-only value.
        
        Args:
        token_bytes: Token bytes from tiktoken
        
        Returns:
        True if the token is numeric-only, False otherwise
        """
        # Decode the token bytes to string
        token_str = self.encoding.decode([token_bytes])
        # Check if it's a numeric token (allowing periods and commas for decimals)
        
        return bool(re.match(r'^[0-9.,]+$', token_str.strip()))
 
    def _count_numeric_tokens(self, token_ids: List) -> int:
        """
        Count tokens that contain only numeric characters using tiktoken.
        
        Args:
        token_ids: The list of tokens ids from input text
        
        Returns:
        The number of numeric-only tokens
        """
        if not len(token_ids):
            return 0
        
        # Convert token IDs back to strings and check if they're numeric
        numeric_count = 0
        for i in range(len(token_ids)):
            token_bytes = token_ids[i:i+1]
            token_str = self.encoding.decode(token_bytes)
            if token_str.strip() and re.match(r'^[0-9.,]+$', token_str.strip()):
                numeric_count += 1
        
        return numeric_count
 
    def process_chunk(self, chunk: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a single chunk to remove excessive numeric content.
        
        Args:
        chunk: A dictionary containing 'text', 'headings' and 'page_info'
        
        Returns:
        Processed chunk with filtered text
        """
        if not chunk or 'text' not in chunk:
            return chunk
        
        text = chunk['text']
        token_ids = self._get_tokens(text)
        total_tokens = len(token_ids)
        
        if total_tokens == 0:
            return chunk

        chunk["token_count"] = total_tokens

        numeric_tokens = self._count_numeric_tokens(token_ids)
        numeric_ratio = numeric_tokens / total_tokens
        logger.info(f"the percentage of numeric into the text is: {numeric_ratio*100}")
        
        processed_chunk = chunk.copy()
        
        # If numeric tokens exceed threshold, filter them out
        if numeric_ratio > self.token_threshold:
            # We need to remove numeric token via regex
            text_without_numeric = remove_numbers_from_text(text, 'all_digits')
        else:
            text_without_numeric = processed_chunk['text']
        
        # Create text_to_embed field
        if 'headings' in chunk and chunk['headings']:
            headings_text = ' > '.join(chunk['headings'])
            processed_chunk['text_to_embed'] = f"Heading: {headings_text}: \n Content: {text_without_numeric}"
        else:
            processed_chunk['text_to_embed'] = processed_chunk['text']
        
        return processed_chunk
 
    def process_chunks(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Process multiple chunks.
        
        Args:
        chunks: List of chunk dictionaries
        
        Returns:
        List of processed chunks
        """
        return [self.process_chunk(chunk) for chunk in chunks]