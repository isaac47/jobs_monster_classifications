#!/bin/bash
# Complete Docker ECR SageMaker Pipeline Script
# This script handles: ECR → Docker Build → Push → SageMaker Model Creation

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Print colored output functions
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${PURPLE}$1${NC}"
}

# Configuration
STACK_NAME="benchmark"
REGION="eu-west-3"
ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text 2>/dev/null)

# Docker and ECR Configuration
ECR_REPOSITORY_NAME="${STACK_NAME}-docling-processor"
IMAGE_TAG="v$(date +%Y%m%d-%H%M%S)"  # Timestamped tag
DOCKERFILE_PATH="./docling_handler/Dockerfile"
BUILD_CONTEXT="./docling_handler"

# SageMaker Configuration
MODEL_NAME="${STACK_NAME}-docling-model"
EXECUTION_ROLE_NAME="${STACK_NAME}-sagemaker-execution-role"

# Global variables
ECR_URI=""
EXECUTION_ROLE_ARN=""

# Validation function
validate_prerequisites() {
    print_header "🔍 Validating Prerequisites"
    print_header "=========================="
    
    # Check AWS CLI
    if ! command -v aws &> /dev/null; then
        print_error "AWS CLI not found. Please install AWS CLI."
        exit 1
    fi
    print_success "AWS CLI found"
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        print_error "Docker not found. Please install Docker."
        exit 1
    fi
    print_success "Docker found"
    
    # Check Docker daemon
    if ! docker info &> /dev/null; then
        print_error "Docker daemon not running. Please start Docker."
        exit 1
    fi
    print_success "Docker daemon running"
    
    # Check AWS credentials
    if [ -z "$ACCOUNT_ID" ]; then
        print_error "AWS credentials not configured. Please run 'aws configure'."
        exit 1
    fi
    print_success "AWS credentials validated (Account: $ACCOUNT_ID)"
    
    # Check if Dockerfile exists
    if [ ! -f "$DOCKERFILE_PATH" ]; then
        print_error "Dockerfile not found at: $DOCKERFILE_PATH"
        print_status "Please ensure the Dockerfile exists in the docling_handler directory"
        exit 1
    fi
    print_success "Dockerfile found: $DOCKERFILE_PATH"
    
    # Check if build context exists
    if [ ! -d "$BUILD_CONTEXT" ]; then
        print_error "Build context directory not found: $BUILD_CONTEXT"
        exit 1
    fi
    print_success "Build context found: $BUILD_CONTEXT"
    
    print_success "All prerequisites validated!"
}

# Step 1: Create ECR Repository
create_ecr_repository() {
    print_header "\n📦 Step 1: Creating ECR Repository"
    print_header "=================================="
    
    print_status "Checking if ECR repository exists: $ECR_REPOSITORY_NAME"
    
    # Check if repository already exists
    if aws ecr describe-repositories --repository-names "$ECR_REPOSITORY_NAME" --region "$REGION" &>/dev/null; then
        print_warning "ECR repository already exists: $ECR_REPOSITORY_NAME"
    else
        print_status "Creating ECR repository: $ECR_REPOSITORY_NAME"
        
        aws ecr create-repository \
            --repository-name "$ECR_REPOSITORY_NAME" \
            --region "$REGION" \
            --image-scanning-configuration scanOnPush=true \
            --encryption-configuration encryptionType=AES256 \
            --tags Key=Project,Value="$STACK_NAME" Key=Purpose,Value=SageMaker
            
        print_success "ECR repository created: $ECR_REPOSITORY_NAME"
    fi
    
    # Get repository URI
    ECR_URI="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ECR_REPOSITORY_NAME}:${IMAGE_TAG}"
    print_success "ECR URI: $ECR_URI"
}

# Step 2: Build Docker Image
build_docker_image() {
    print_header "\n🔨 Step 2: Building Docker Image"
    print_header "================================"
    
    print_status "Building Docker image from: $DOCKERFILE_PATH"
    print_status "Build context: $BUILD_CONTEXT"
    print_status "Image tag: $IMAGE_TAG"
    
    # Change to build context directory
    ORIGINAL_DIR=$(pwd)
    cd "$BUILD_CONTEXT"
    
    # Build Docker image with build args for optimization
    print_status "Starting Docker build..."
    
    docker build \
        --build-arg BUILDKIT_INLINE_CACHE=1 \
        --platform linux/amd64 \
        --tag "${ECR_REPOSITORY_NAME}:${IMAGE_TAG}" \
        --tag "${ECR_REPOSITORY_NAME}:latest" \
        --file Dockerfile \
        . || {
        print_error "Docker build failed"
        cd "$ORIGINAL_DIR"
        exit 1
    }
    
    cd "$ORIGINAL_DIR"
    print_success "Docker image built successfully: ${ECR_REPOSITORY_NAME}:${IMAGE_TAG}"
    
    # Show image size
    IMAGE_SIZE=$(docker images "${ECR_REPOSITORY_NAME}:${IMAGE_TAG}" --format "table {{.Size}}" | tail -1)
    print_status "Image size: $IMAGE_SIZE"
}

# Step 3: Push to ECR
push_to_ecr() {
    print_header "\n📤 Step 3: Pushing Image to ECR"
    print_header "==============================="
    
    print_status "Authenticating Docker to ECR..."
    
    # Authenticate Docker to ECR
    aws ecr get-login-password --region "$REGION" | \
        docker login --username AWS --password-stdin "${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com" || {
        print_error "ECR authentication failed"
        exit 1
    }
    
    print_success "Docker authenticated to ECR"
    
    # Tag image for ECR
    print_status "Tagging image for ECR..."
    docker tag "${ECR_REPOSITORY_NAME}:${IMAGE_TAG}" "$ECR_URI"
    docker tag "${ECR_REPOSITORY_NAME}:latest" "${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ECR_REPOSITORY_NAME}:latest"
    
    # Push image to ECR
    print_status "Pushing image to ECR..."
    docker push "$ECR_URI" || {
        print_error "Failed to push image to ECR"
        exit 1
    }
    
    # Also push latest tag
    docker push "${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ECR_REPOSITORY_NAME}:latest"
    
    print_success "Image pushed successfully to ECR: $ECR_URI"
    
    # Verify image in ECR
    print_status "Verifying image in ECR..."
    IMAGE_DIGEST=$(aws ecr describe-images \
        --repository-name "$ECR_REPOSITORY_NAME" \
        --image-ids imageTag="$IMAGE_TAG" \
        --region "$REGION" \
        --query 'imageDetails[0].imageDigest' \
        --output text)
    
    if [ "$IMAGE_DIGEST" != "None" ] && [ -n "$IMAGE_DIGEST" ]; then
        print_success "Image verified in ECR with digest: $IMAGE_DIGEST"
    else
        print_warning "Could not verify image in ECR"
    fi
}

# Helper function to create IAM execution role
create_sagemaker_execution_role() {
    print_status "Creating SageMaker execution role: $EXECUTION_ROLE_NAME"
    
    # Create trust policy for SageMaker
    TRUST_POLICY=$(cat << 'EOF'
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "sagemaker.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
)

    # Create the role
    aws iam create-role \
        --role-name "$EXECUTION_ROLE_NAME" \
        --assume-role-policy-document "$TRUST_POLICY" \
        --max-session-duration 3600

    # Attach basic SageMaker execution policy
    aws iam attach-role-policy \
        --role-name "$EXECUTION_ROLE_NAME" \
        --policy-arn arn:aws:iam::aws:policy/AmazonSageMakerFullAccess

    # Create comprehensive custom policy
    CUSTOM_POLICY=$(cat << EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject",
                "s3:ListBucket",
                "s3:GetBucketLocation"
            ],
            "Resource": [
                "arn:aws:s3:::$STACK_NAME-documents",
                "arn:aws:s3:::$STACK_NAME-documents/*",
                "arn:aws:s3:::sagemaker-*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "dynamodb:GetItem",
                "dynamodb:PutItem",
                "dynamodb:UpdateItem",
                "dynamodb:Query",
                "dynamodb:Scan",
                "dynamodb:BatchWriteItem",
                "dynamodb:BatchGetItem",
                "dynamodb:DescribeTable"
            ],
            "Resource": [
                "arn:aws:dynamodb:$REGION:$ACCOUNT_ID:table/$STACK_NAME-kpi-analyze-status",
                "arn:aws:dynamodb:$REGION:$ACCOUNT_ID:table/$STACK_NAME-kpi-file-status",
                "arn:aws:dynamodb:$REGION:$ACCOUNT_ID:table/$STACK_NAME-kpi-document-chunks",
                "arn:aws:dynamodb:$REGION:$ACCOUNT_ID:table/$STACK_NAME-kpi-document-chunks/index/*",
                "arn:aws:dynamodb:$REGION:$ACCOUNT_ID:table/$STACK_NAME-kpi-file-status/index/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModelWithResponseStream",
                "bedrock:ListFoundationModels",
                "bedrock:GetFoundationModel"
            ],
            "Resource": [
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-sonnet-20240229-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-haiku-20240307-v1:0",
                "arn:aws:bedrock:us-west-2::foundation-model/anthropic.claude-3-sonnet-20240229-v1:0",
                "arn:aws:bedrock:us-west-2::foundation-model/anthropic.claude-3-haiku-20240307-v1:0"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "ecr:GetAuthorizationToken",
                "ecr:BatchCheckLayerAvailability",
                "ecr:GetDownloadUrlForLayer",
                "ecr:BatchGetImage",
                "ecr:DescribeRepositories",
                "ecr:DescribeImages"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents",
                "logs:DescribeLogGroups",
                "logs:DescribeLogStreams"
            ],
            "Resource": "arn:aws:logs:*:*:*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudwatch:PutMetricData",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:ListMetrics"
            ],
            "Resource": "*"
        }
    ]
}
EOF
)

    # Create and attach custom policy
    CUSTOM_POLICY_ARN=$(aws iam create-policy \
        --policy-name "$STACK_NAME-sagemaker-execution-policy" \
        --policy-document "$CUSTOM_POLICY" \
        --query 'Policy.Arn' \
        --output text)

    aws iam attach-role-policy \
        --role-name "$EXECUTION_ROLE_NAME" \
        --policy-arn "$CUSTOM_POLICY_ARN"

    print_success "IAM execution role created: $EXECUTION_ROLE_NAME"
    
    # Wait for role propagation
    print_status "Waiting for IAM role propagation..."
    sleep 20
}

# Step 4: Create SageMaker Model
create_sagemaker_model() {
    print_header "\n🤖 Step 4: Creating SageMaker Model"
    print_header "==================================="
    
    print_status "Creating SageMaker model: $MODEL_NAME"
    
    # Check if IAM role exists
    print_status "Checking IAM execution role..."
    
    if aws iam get-role --role-name "$EXECUTION_ROLE_NAME" &>/dev/null; then
        EXECUTION_ROLE_ARN=$(aws iam get-role --role-name "$EXECUTION_ROLE_NAME" --query 'Role.Arn' --output text)
        print_success "Using existing IAM role: $EXECUTION_ROLE_ARN"
    else
        print_status "Creating IAM execution role for SageMaker..."
        create_sagemaker_execution_role
        EXECUTION_ROLE_ARN=$(aws iam get-role --role-name "$EXECUTION_ROLE_NAME" --query 'Role.Arn' --output text)
    fi
    
    # Delete existing model if it exists
    if aws sagemaker describe-model --model-name "$MODEL_NAME" &>/dev/null; then
        print_warning "Model already exists, deleting existing model: $MODEL_NAME"
        aws sagemaker delete-model --model-name "$MODEL_NAME"
        print_status "Waiting for model deletion to complete..."
        sleep 10
    fi
    
    # Create SageMaker model
    print_status "Creating SageMaker model with image: $ECR_URI"
    
    aws sagemaker create-model \
        --model-name "$MODEL_NAME" \
        --primary-container Image="$ECR_URI",Environment='{
            "DOCUMENTS_BUCKET":"'$STACK_NAME'-documents",
            "KPI_ANALYZE_STATUS_TABLE":"'$STACK_NAME'-kpi-analyze-status",
            "KPI_FILE_STATUS_TABLE":"'$STACK_NAME'-kpi-file-status",
            "KPI_DOCUMENT_CHUNKS_TABLE":"'$STACK_NAME'-kpi-document-chunks",
            "BEDROCK_REGION":"us-east-1",
            "BEDROCK_VISION_MODEL":"anthropic.claude-3-sonnet-20240229-v1:0",
            "MAX_IMAGES_PER_DOCUMENT":"50",
            "DOCLING_TIMEOUT":"600",
            "BEDROCK_TIMEOUT":"300",
            "LOG_LEVEL":"INFO",
            "SAGEMAKER_PROGRAM":"docling_endpoint.py",
            "SAGEMAKER_SUBMIT_DIRECTORY":"/opt/ml/code",
            "SAGEMAKER_REGION":"'$REGION'",
            "AWS_DEFAULT_REGION":"'$REGION'"
        }' \
        --execution-role-arn "$EXECUTION_ROLE_ARN" \
        --tags Key=Project,Value="$STACK_NAME" Key=Environment,Value=production Key=Stage,Value=2
    
    print_success "SageMaker model created successfully: $MODEL_NAME"
    
    # Verify model creation
    MODEL_STATUS=$(aws sagemaker describe-model --model-name "$MODEL_NAME" --query 'ModelArn' --output text)
    if [ -n "$MODEL_STATUS" ] && [ "$MODEL_STATUS" != "None" ]; then
        print_success "Model verified: $MODEL_STATUS"
    else
        print_error "Failed to verify model creation"
        return 1
    fi
}

# Cleanup function
cleanup_local_images() {
    print_status "Cleaning up local Docker images..."
    
    # Remove local images to save space (optional)
    read -p "Do you want to remove local Docker images to save space? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        docker rmi "${ECR_REPOSITORY_NAME}:${IMAGE_TAG}" 2>/dev/null || true
        docker rmi "${ECR_REPOSITORY_NAME}:latest" 2>/dev/null || true
        docker rmi "$ECR_URI" 2>/dev/null || true
        print_success "Local images cleaned up"
    else
        print_status "Keeping local images"
    fi
}

# Create endpoint configuration helper
create_endpoint_config() {
    print_header "\n⚙️ Step 5: Creating Endpoint Configuration"
    print_header "=========================================="
    
    ENDPOINT_CONFIG_NAME="${STACK_NAME}-docling-config"
    
    # Check if endpoint config already exists
    if aws sagemaker describe-endpoint-config --endpoint-config-name "$ENDPOINT_CONFIG_NAME" &>/dev/null; then
        print_warning "Endpoint configuration already exists: $ENDPOINT_CONFIG_NAME"
        return 0
    fi
    
    print_status "Creating endpoint configuration: $ENDPOINT_CONFIG_NAME"
    
    aws sagemaker create-endpoint-config \
        --endpoint-config-name "$ENDPOINT_CONFIG_NAME" \
        --production-variants \
            VariantName=primary,ModelName="$MODEL_NAME",InitialInstanceCount=1,InstanceType=ml.m5.xlarge,InitialVariantWeight=1 \
        --tags Key=Project,Value="$STACK_NAME" Key=Environment,Value=production
    
    print_success "Endpoint configuration created: $ENDPOINT_CONFIG_NAME"
}

# Create endpoint helper
create_endpoint() {
    print_header "\n🌐 Step 6: Creating SageMaker Endpoint"
    print_header "====================================="
    
    ENDPOINT_NAME="${STACK_NAME}-docling-endpoint"
    ENDPOINT_CONFIG_NAME="${STACK_NAME}-docling-config"
    
    # Check if endpoint already exists
    if aws sagemaker describe-endpoint --endpoint-name "$ENDPOINT_NAME" &>/dev/null; then
        CURRENT_STATUS=$(aws sagemaker describe-endpoint --endpoint-name "$ENDPOINT_NAME" --query 'EndpointStatus' --output text)
        print_warning "Endpoint already exists with status: $CURRENT_STATUS"
        
        if [ "$CURRENT_STATUS" = "InService" ]; then
            print_success "Endpoint is already in service: $ENDPOINT_NAME"
            return 0
        fi
    else
        print_status "Creating endpoint: $ENDPOINT_NAME"
        
        aws sagemaker create-endpoint \
            --endpoint-name "$ENDPOINT_NAME" \
            --endpoint-config-name "$ENDPOINT_CONFIG_NAME" \
            --tags Key=Project,Value="$STACK_NAME" Key=Environment,Value=production
    fi
    
    print_status "Waiting for endpoint to be in service (this may take 5-10 minutes)..."
    print_status "You can monitor progress with:"
    print_status "  aws sagemaker describe-endpoint --endpoint-name $ENDPOINT_NAME"
    
    # Optional: Wait for endpoint to be ready
    read -p "Do you want to wait for the endpoint to be ready? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        aws sagemaker wait endpoint-in-service --endpoint-name "$ENDPOINT_NAME"
        print_success "Endpoint is now in service: $ENDPOINT_NAME"
        
        # Get endpoint URL
        ENDPOINT_URL="https://runtime.sagemaker.${REGION}.amazonaws.com/endpoints/${ENDPOINT_NAME}/invocations"
        print_success "Endpoint URL: $ENDPOINT_URL"
    else
        print_status "Endpoint creation initiated. Check status manually."
    fi
}

# Test endpoint helper
test_endpoint() {
    print_header "\n🧪 Step 7: Testing Endpoint (Optional)"
    print_header "====================================="
    
    ENDPOINT_NAME="${STACK_NAME}-docling-endpoint"
    
    # Check if endpoint is ready
    if ! aws sagemaker describe-endpoint --endpoint-name "$ENDPOINT_NAME" &>/dev/null; then
        print_warning "Endpoint doesn't exist yet. Skipping test."
        return 0
    fi
    
    ENDPOINT_STATUS=$(aws sagemaker describe-endpoint --endpoint-name "$ENDPOINT_NAME" --query 'EndpointStatus' --output text)
    if [ "$ENDPOINT_STATUS" != "InService" ]; then
        print_warning "Endpoint not ready (Status: $ENDPOINT_STATUS). Skipping test."
        return 0
    fi
    
    read -p "Do you want to test the endpoint with a sample request? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        # Create test payload
        TEST_PAYLOAD=$(cat << EOF
{
    "file_id": "test-$(date +%s)",
    "analyze_id": "test-analyze-$(date +%s)",
    "s3_path": "s3://$STACK_NAME-documents/test/sample.pdf"
}
EOF
)
        
        print_status "Testing endpoint with sample payload..."
        echo "$TEST_PAYLOAD" > test_payload.json
        
        aws sagemaker-runtime invoke-endpoint \
            --endpoint-name "$ENDPOINT_NAME" \
            --content-type application/json \
            --body fileb://test_payload.json \
            test_response.json
        
        print_status "Test response saved to: test_response.json"
        print_status "Response preview:"
        head -n 10 test_response.json || cat test_response.json
        
        # Cleanup test files
        rm -f test_payload.json test_response.json
    fi
}

# Main execution function
main() {
    print_header "🚀 Complete Docker ECR SageMaker Pipeline"
    print_header "=========================================="
    print_status "Stack: $STACK_NAME"
    print_status "Region: $REGION"
    print_status "Account: $ACCOUNT_ID"
    print_status "Repository: $ECR_REPOSITORY_NAME"
    print_status "Image Tag: $IMAGE_TAG"
    print_status "Model Name: $MODEL_NAME"
    print_status "Timestamp: $(date)"
    
    # Run core pipeline steps
    validate_prerequisites
    create_ecr_repository
    build_docker_image
    push_to_ecr
    create_sagemaker_model
    
    # Optional additional steps
    print_header "\n🔧 Optional Next Steps"
    print_header "====================="
    
    read -p "Do you want to create endpoint configuration and endpoint? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        create_endpoint_config
        create_endpoint
        test_endpoint
    fi
    
    # Summary
    print_header "\n🎉 Pipeline Completion Summary"
    print_header "============================="
    print_success "✅ ECR Repository: $ECR_REPOSITORY_NAME"
    print_success "✅ Image URI: $ECR_URI"
    print_success "✅ SageMaker Model: $MODEL_NAME"
    print_success "✅ IAM Role: $EXECUTION_ROLE_NAME"
    print_success "✅ Region: $REGION"
    print_success "✅ Pipeline completed at: $(date)"
    
    # Save comprehensive deployment info
    cat > deployment_info.json << EOF
{
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "pipeline_version": "1.0",
    "stack_name": "$STACK_NAME",
    "region": "$REGION",
    "account_id": "$ACCOUNT_ID",
    "ecr_repository": "$ECR_REPOSITORY_NAME",
    "image_tag": "$IMAGE_TAG",
    "image_uri": "$ECR_URI",
    "sagemaker_model": "$MODEL_NAME",
    "execution_role": "$EXECUTION_ROLE_NAME",
    "endpoint_config": "$STACK_NAME-docling-config",
    "endpoint_name": "$STACK_NAME-docling-endpoint",
    "deployment_status": "completed",
    "next_steps": [
        "Create endpoint configuration if not done",
        "Create and deploy endpoint",
        "Test endpoint with sample data",
        "Configure monitoring and alerting"
    ]
}
EOF
    
    print_success "Deployment info saved to: deployment_info.json"
    
    # Show next steps
    print_header "\n📋 Manual Next Steps (if not automated)"
    print_header "======================================="
    print_status "1. Create endpoint configuration:"
    print_status "   aws sagemaker create-endpoint-config \\"
    print_status "     --endpoint-config-name $STACK_NAME-docling-config \\"
    print_status "     --production-variants \\"
    print_status "       VariantName=primary,ModelName=$MODEL_NAME,InitialInstanceCount=1,InstanceType=ml.m5.xlarge"
    print_status ""
    print_status "2. Create endpoint:"
    print_status "   aws sagemaker create-endpoint \\"
    print_status "     --endpoint-name $STACK_NAME-docling-endpoint \\"
    print_status "     --endpoint-config-name $STACK_NAME-docling-config"
    print_status ""
    print_status "3. Test endpoint:"
    print_status "   aws sagemaker-runtime invoke-endpoint \\"
    print_status "     --endpoint-name $STACK_NAME-docling-endpoint \\"
    print_status "     --content-type application/json \\"
    print_status "     --body '{\"file_id\":\"test\",\"analyze_id\":\"test\",\"s3_path\":\"s3://bucket/file.pdf\"}' \\"
    print_status "     response.json"
    
    # Optional cleanup
    cleanup_local_images
    
    print_header "\n✅ Complete Docker ECR SageMaker Pipeline Finished Successfully!"
}

# Error handling
trap 'print_error "Script failed on line $LINENO"' ERR

# Help function
show_help() {
    echo "Complete Docker ECR SageMaker Pipeline Script"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "This script performs the following steps:"
    echo "  1. Creates ECR repository"
    echo "  2. Builds Docker image from Dockerfile"
    echo "  3. Pushes image to ECR"
    echo "  4. Creates SageMaker model"
    echo "  5. Optionally creates endpoint configuration and endpoint"
    echo ""
    echo "Prerequisites:"
    echo "  - AWS CLI configured with appropriate permissions"
    echo "  - Docker installed and running"
    echo "  - Dockerfile in ./docling_handler/ directory"
    echo ""
    echo "Options:"
    echo "  -h, --help     Show this help message"
    echo "  --auto         Run all steps without prompts (except cleanup)"
    echo "  --stack NAME   Use custom stack name (default: benchmark)"
    echo "  --region NAME  Use custom region (default: eu-west-3)"
    echo ""
    echo "Examples:"
    echo "  $0                    # Interactive mode"
    echo "  $0 --auto             # Automated mode"
    echo "  $0 --stack mystack    # Custom stack name"
}

# Parse command line arguments
AUTO_MODE=false
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        --auto)
            AUTO_MODE=true
            shift
            ;;
        --stack)
            STACK_NAME="$2"
            shift 2
            ;;
        --region)
            REGION="$2"
            shift 2
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Update derived variables if stack name or region changed
ECR_REPOSITORY_NAME="${STACK_NAME}-docling-processor"
MODEL_NAME="${STACK_NAME}-docling-model"
EXECUTION_ROLE_NAME="${STACK_NAME}-sagemaker-execution-role"

# Run main function
main "$@"
