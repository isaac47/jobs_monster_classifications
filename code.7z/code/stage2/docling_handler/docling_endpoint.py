# FILE PATH: ./stage2/docling_handler/docling_endpoint.py

import json
import os
import traceback
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import boto3
from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.dynamodb_utils import get_item, put_item, update_item
from common.utils.logger import LogContext, get_logger
from common.utils.s3_utils import download_from_s3, parse_s3_url
from common.utils.text_preprocessing import ChunkProcessor
from docling_api.processor import DocumentProcessor

# Initialize logger
logger = get_logger(__name__)

# Global variables for model artifacts
document_processor = None
chunk_processor = None
bedrock_client = None


def model_fn(model_dir: str):
    """
    Load the model for inference (SageMaker requirement).
    This function is called once when the container starts.
    """
    global document_processor, chunk_processor, bedrock_client

    logger.info("Initializing Docling processor for Stage 2...")

    try:
        # Initialize document processor
        document_processor = DocumentProcessor()
        logger.info("Document processor initialized")

        # Initialize chunk processor
        chunk_processor = ChunkProcessor()
        logger.info("Chunk processor initialized")

        # Initialize Bedrock client for vision processing
        bedrock_region = os.environ.get("BEDROCK_REGION", "us-east-1")
        try:
            bedrock_client = boto3.client("bedrock-runtime", region_name=bedrock_region)
            logger.info(f"Bedrock client initialized for region: {bedrock_region}")
        except Exception as e:
            logger.warning(f"Failed to initialize Bedrock client: {e}")
            bedrock_client = None

        # Test DynamoDB connectivity
        try:
            dynamodb = boto3.client("dynamodb")
            logger.info("DynamoDB client initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize DynamoDB client: {e}")
            raise

        logger.info("All model components initialized successfully")

        return {
            "document_processor": document_processor,
            "chunk_processor": chunk_processor,
            "bedrock_client": bedrock_client,
            "status": "ready",
        }

    except Exception as e:
        logger.error(f"Error initializing model: {e}")
        logger.error(traceback.format_exc())
        raise RuntimeError(f"Model initialization failed: {str(e)}")


def input_fn(request_body: str, request_content_type: str):
    """
    Parse input data for inference (SageMaker requirement).
    """
    logger.info(f"Received request with content type: {request_content_type}")

    if request_content_type == "application/json":
        try:
            input_data = json.loads(request_body)

            # Validate required fields
            required_fields = ["file_id", "analyze_id", "s3_path"]
            missing_fields = [
                field for field in required_fields if field not in input_data
            ]

            if missing_fields:
                raise ValueError(f"Missing required fields: {missing_fields}")

            logger.info(
                f"Successfully parsed input: file_id={input_data.get('file_id')}"
            )
            return input_data

        except json.JSONDecodeError as e:
            logger.error(f"Error parsing JSON request: {e}")
            raise ValueError(f"Invalid JSON in request body: {e}")
    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")


def check_analyze_status(analyze_id: str) -> bool:
    """Critical Check: Query analyze_id status → If "failed", skip and return."""
    try:
        analyze_table = EnvVars.KPI_ANALYZE_STATUS_TABLE
        analyze_record = get_item(analyze_table, {"analyze_id": analyze_id})

        if not analyze_record:
            logger.error(f"Analyze record not found: {analyze_id}")
            return False

        status = analyze_record.get("status")
        if status == "failed":
            logger.info(f"Analyze already failed, skipping processing: {analyze_id}")
            return False

        logger.info(f"Analyze status is {status}, proceeding with processing")
        return True

    except Exception as e:
        logger.error(f"Error checking analyze status: {e}")
        return False


def update_file_status(
    file_id: str, status: str, error_message: Optional[str] = None
) -> bool:
    """Update file status in DynamoDB."""
    try:
        update_expression = "SET #status = :status, updated_at = :updated_at"
        expression_values = {
            ":status": status,
            ":updated_at": datetime.now(timezone.utc).isoformat(),
        }
        expression_names = {"#status": "status"}

        if error_message:
            update_expression += ", error_message = :error_message"
            expression_values[":error_message"] = error_message

        table_name = EnvVars.KPI_FILE_STATUS_TABLE

        return update_item(
            table_name,
            {"file_id": file_id},
            update_expression,
            expression_values,
            expression_names,
        )
    except Exception as e:
        logger.error(f"Error updating file status: {e}")
        return False


def update_analyze_status(
    analyze_id: str, status: str, error_message: Optional[str] = None
) -> bool:
    """Update analyze status to failed when processing errors occur."""
    try:
        update_expression = "SET #status = :status, updated_at = :updated_at"
        expression_values = {
            ":status": status,
            ":updated_at": datetime.now(timezone.utc).isoformat(),
        }
        expression_names = {"#status": "status"}

        if error_message:
            update_expression += ", error_message = :error_message"
            expression_values[":error_message"] = error_message

        analyze_table = EnvVars.KPI_ANALYZE_STATUS_TABLE

        return update_item(
            analyze_table,
            {"analyze_id": analyze_id},
            update_expression,
            expression_values,
            expression_names,
        )
    except Exception as e:
        logger.error(f"Error updating analyze status: {e}")
        return False


def process_document_images_with_bedrock(
    images: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Process images using Bedrock Claude 3 Vision API."""
    global bedrock_client

    if not bedrock_client:
        logger.warning("Bedrock client not available, skipping image processing")
        return images

    try:
        import base64

        processed_images = []

        for image in images:
            try:
                image_data = image.get("image_data") or image.get("base64_data")
                if not image_data:
                    logger.warning("No image data found, skipping vision processing")
                    processed_images.append(image)
                    continue

                if isinstance(image_data, bytes):
                    image_base64 = base64.b64encode(image_data).decode("utf-8")
                else:
                    image_base64 = image_data

                vision_prompt = """
                Analyze this financial chart, graph, or diagram. Provide a detailed description that includes:
                1. Type of visualization (bar chart, line graph, pie chart, table, etc.)
                2. Main financial metrics or KPIs shown
                3. Key trends, patterns, or notable data points
                4. Time periods covered (if applicable)
                5. Any specific values or percentages visible
                
                Focus on extracting quantitative information that would be useful for financial analysis.
                """

                request_body = {
                    "anthropic_version": "bedrock-2023-05-31",
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "image",
                                    "source": {
                                        "type": "base64",
                                        "media_type": "image/png",
                                        "data": image_base64,
                                    },
                                },
                                {"type": "text", "text": vision_prompt},
                            ],
                        }
                    ],
                    "max_tokens": 1000,
                    "temperature": 0.1,
                }

                response = bedrock_client.invoke_model(
                    modelId="anthropic.claude-3-sonnet-20240229-v1:0",
                    contentType="application/json",
                    accept="application/json",
                    body=json.dumps(request_body),
                )

                response_body = json.loads(response["body"].read())

                if "content" in response_body and len(response_body["content"]) > 0:
                    description = response_body["content"][0].get("text", "")
                    image["vision_description"] = description
                    logger.info(
                        f"Generated vision description for image: {len(description)} characters"
                    )
                else:
                    logger.warning("No vision description generated")
                    image["vision_description"] = "No description available"

                processed_images.append(image)

            except Exception as e:
                logger.warning(f"Bedrock Vision API error for image: {e}")
                image["vision_description"] = f"Vision processing failed: {str(e)}"
                processed_images.append(image)

        return processed_images

    except Exception as e:
        logger.warning(f"Error in image processing setup: {e}")
        return images


def process_document_from_s3(s3_path: str, file_type: str) -> Optional[Dict[str, Any]]:
    """Download and process document from S3 with image analysis."""
    global document_processor, chunk_processor

    try:
        s3_parts = parse_s3_url(s3_path)
        bucket = s3_parts["bucket"]
        key = s3_parts["key"]

        logger.info(f"Downloading document from s3://{bucket}/{key}")

        document_bytes = download_from_s3(bucket, key)
        if not document_bytes:
            logger.error(f"Failed to download document from {s3_path}")
            return None

        logger.info(
            f"Processing {file_type} document, size: {len(document_bytes)} bytes"
        )

        result = document_processor.process_and_chunk(
            document_bytes=document_bytes, file_type=file_type
        )

        if not result:
            logger.error(f"Failed to process {file_type} document")
            return None

        # Extract images and process with Bedrock Vision
        images = result.get("document", {}).get("images", [])
        if images:
            logger.info(f"Processing {len(images)} images with Bedrock Vision")
            processed_images = process_document_images_with_bedrock(images)
            result["document"]["images"] = processed_images

        # Post-process chunks with context preservation
        processed_chunks = chunk_processor.process_chunks(result["chunks"])

        # Integrate image descriptions into relevant chunks
        if images:
            processed_chunks = integrate_image_descriptions_into_chunks(
                processed_chunks, processed_images
            )

        return {
            "document_content": result.get("document", {}),
            "chunks": processed_chunks,
            "chunk_count": len(processed_chunks),
            "processing_metadata": {
                "file_type": file_type,
                "original_size": len(document_bytes),
                "images_processed": len(images),
                "processed_at": datetime.now(timezone.utc).isoformat(),
            },
        }

    except Exception as e:
        logger.error(f"Error processing document from S3: {e}")
        logger.error(traceback.format_exc())
        return None


def integrate_image_descriptions_into_chunks(
    chunks: List[Dict[str, Any]], images: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """Integrate image descriptions into relevant text chunks."""
    try:
        for image in images:
            vision_description = image.get("vision_description", "")
            if not vision_description or vision_description.startswith(
                "Vision processing failed"
            ):
                continue

            image_page = image.get("page_number", 0)

            for chunk in chunks:
                chunk_page = chunk.get("page_info", 0)

                if chunk_page == image_page:
                    if "image_descriptions" not in chunk:
                        chunk["image_descriptions"] = []
                    chunk["image_descriptions"].append(
                        {
                            "description": vision_description,
                            "image_id": image.get("image_id", str(uuid.uuid4())),
                        }
                    )

                    current_content = chunk.get("text", "")
                    chunk["text"] = (
                        current_content + f"\n[IMAGE DESCRIPTION: {vision_description}]"
                    )

        return chunks

    except Exception as e:
        logger.error(f"Error integrating image descriptions: {e}")
        return chunks


def store_chunks_in_dynamodb(
    chunks: List[Dict[str, Any]], file_id: str, analyze_id: str
) -> bool:
    """Store chunks in kpi_document_chunks DynamoDB table."""
    try:
        chunks_table = EnvVars.KPI_DOCUMENT_CHUNKS_TABLE

        stored_count = 0
        for i, chunk in enumerate(chunks):
            chunk_record = {
                "chunk_id": chunk.get("chunk_id", str(uuid.uuid4())),
                "file_id": file_id,
                "analyze_id": analyze_id,
                "chunk_index": i,
                "content": chunk.get("text", ""),
                "text_to_embed": chunk.get("text_to_embed", chunk.get("text", "")),
                "chunk_type": "text",
                "page_number": chunk.get("page_info"),
                "section_title": (
                    ", ".join(chunk.get("headings", []))
                    if chunk.get("headings")
                    else None
                ),
                "table_data": None,
                "image_descriptions": chunk.get("image_descriptions", []),
                "metadata": {
                    "content_type": chunk.get("content_type"),
                    "token_count": chunk.get("token_count", 0),
                    "confidence_score": chunk.get("confidence_score", 1.0),
                },
                "embedding_vector": None,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }

            if put_item(chunks_table, chunk_record):
                stored_count += 1
            else:
                logger.error(f"Failed to store chunk {chunk_record['chunk_id']}")

        logger.info(f"Stored {stored_count}/{len(chunks)} chunks in DynamoDB")
        return stored_count == len(chunks)

    except Exception as e:
        logger.error(f"Error storing chunks in DynamoDB: {e}")
        logger.error(traceback.format_exc())
        return False


def predict_fn(input_data: Dict[str, Any], model: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run inference on the input data (SageMaker requirement).
    FIXED: Complete implementation with proper status management.
    """
    start_time = datetime.now()

    try:
        # Extract required parameters
        file_id = input_data.get("file_id")
        analyze_id = input_data.get("analyze_id")
        s3_path = input_data.get("s3_path")

        logger.info(f"Processing request: file_id={file_id}, analyze_id={analyze_id}")

        # CRITICAL CHECK: Query analyze_id status → If "failed", skip and return
        if not check_analyze_status(analyze_id):
            return {
                "success": False,
                "error": "Analyze status is failed or invalid, skipping processing",
                "skipped": True,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        # Determine file type from S3 path
        file_extension = s3_path.split(".")[-1].lower()
        if file_extension == "pdf":
            file_type = "pdf"
        elif file_extension in ["xlsx", "xls"]:
            file_type = "excel"
        else:
            error_msg = f"Unsupported file type: {file_extension}"
            logger.error(error_msg)
            # FIXED: Update file status and mark analyze as failed
            update_file_status(file_id, "failed", error_msg)
            update_analyze_status(analyze_id, "failed", error_msg)
            return {
                "success": False,
                "error": error_msg,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        logger.info(f"Processing file {file_id} from {s3_path}")

        # FIXED: Update file status to "docling_processing"
        if not update_file_status(file_id, "docling_processing"):
            error_msg = "Failed to update file status to docling_processing"
            logger.error(error_msg)
            update_analyze_status(analyze_id, "failed", error_msg)
            return {
                "success": False,
                "error": error_msg,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        with LogContext(logger, f"Processing {file_type} document {file_id}"):

            # Process document with image analysis
            processing_result = process_document_from_s3(s3_path, file_type)
            if not processing_result:
                error_msg = f"Docling processing errors for document {file_id}"
                logger.error(error_msg)
                # FIXED: Update file status and mark analyze as failed
                update_file_status(file_id, "failed", error_msg)
                update_analyze_status(analyze_id, "failed", error_msg)
                return {
                    "success": False,
                    "error": error_msg,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            # Store all chunks in kpi_document_chunks DynamoDB table
            chunks_stored = store_chunks_in_dynamodb(
                processing_result["chunks"], file_id, analyze_id
            )

            if not chunks_stored:
                error_msg = f"DynamoDB storage errors for document {file_id}"
                logger.error(error_msg)
                # FIXED: Update file status and mark analyze as failed
                update_file_status(file_id, "failed", error_msg)
                update_analyze_status(analyze_id, "failed", error_msg)
                return {
                    "success": False,
                    "error": error_msg,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            # FIXED: Update file status to "docling_complete"
            if not update_file_status(file_id, "docling_complete"):
                error_msg = "Failed to update file status to docling_complete"
                logger.error(error_msg)
                update_analyze_status(analyze_id, "failed", error_msg)
                return {
                    "success": False,
                    "error": error_msg,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            # Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()

            logger.info(
                f"Successfully processed document {file_id} in {processing_time:.2f}s"
            )

            return {
                "success": True,
                "file_id": file_id,
                "analyze_id": analyze_id,
                "chunk_count": processing_result["chunk_count"],
                "images_processed": processing_result["processing_metadata"][
                    "images_processed"
                ],
                "processing_time_seconds": processing_time,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    except Exception as e:
        error_msg = f"Error during prediction: {str(e)}"
        logger.error(f"{error_msg}\n{traceback.format_exc()}")

        # FIXED: Mark analyze as failed for any processing errors
        if "analyze_id" in locals() and analyze_id:
            update_analyze_status(analyze_id, "failed", error_msg)

        # FIXED: Try to update file status if we have file_id
        if "file_id" in locals() and file_id:
            update_file_status(file_id, "failed", error_msg)

        return {
            "success": False,
            "error": error_msg,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


def output_fn(prediction: Dict[str, Any], accept: str) -> str:
    """
    Format the output for the response (SageMaker requirement).
    FIXED: Complete implementation.
    """
    if accept == "application/json":
        return json.dumps(prediction, indent=2)
    else:
        raise ValueError(f"Unsupported accept type: {accept}")


# FIXED: Health check endpoint for SageMaker
def ping():
    """Health check endpoint for SageMaker container."""
    try:
        global document_processor, chunk_processor

        if document_processor is None or chunk_processor is None:
            return {"status": "unhealthy", "error": "Model not initialized"}, 503

        return {
            "status": "healthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }, 200

    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}, 503


# FIXED: SageMaker serving infrastructure
def serve():
    """Main serving function for SageMaker inference."""
    try:
        # Initialize the model
        model = model_fn("/opt/ml/model")
        logger.info("Model loaded successfully for serving")

        # In a real SageMaker environment, this would start the HTTP server
        # For now, we just ensure the model is loaded
        return model

    except Exception as e:
        logger.error(f"Error in serve function: {e}")
        raise


# SageMaker multi-model server handler
def handler(event, context):
    """
    Handler function for SageMaker multi-model server.
    This is called by the SageMaker inference container.
    """
    try:
        # For SageMaker, we need to handle the inference request
        # The event contains the request body and headers

        # Parse the request
        request_body = event.get("body", "{}")
        content_type = event.get("headers", {}).get("Content-Type", "application/json")
        accept = event.get("headers", {}).get("Accept", "application/json")

        # Initialize model if needed
        global document_processor, chunk_processor, bedrock_client
        if document_processor is None:
            model_fn("/opt/ml/model")

        # Process the request
        input_data = input_fn(request_body, content_type)
        model_artifacts = {
            "document_processor": document_processor,
            "chunk_processor": chunk_processor,
            "bedrock_client": bedrock_client,
        }
        prediction = predict_fn(input_data, model_artifacts)
        response = output_fn(prediction, accept)

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": response,
        }

    except Exception as e:
        logger.error(f"Error in SageMaker handler: {e}")
        logger.error(traceback.format_exc())

        error_response = {
            "success": False,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(error_response),
        }


# For local testing and SageMaker entry point
if __name__ == "__main__":
    # Test the processor locally or serve for SageMaker
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "serve":
        # SageMaker serving mode
        logger.info("Starting SageMaker serving mode")
        serve()
    else:
        # Local testing mode
        test_input = {
            "file_id": "test-file-123",
            "analyze_id": "test-analyze-456",
            "s3_path": "s3://test-bucket/test-file.pdf",
        }

        try:
            model = model_fn("/tmp")
            print("Model initialized successfully")

            parsed_input = input_fn(json.dumps(test_input), "application/json")
            result = predict_fn(parsed_input, model)
            output = output_fn(result, "application/json")

            print("Local test result:")
            print(output)

        except Exception as e:
            print(f"Error in local test: {e}")
            traceback.print_exc()
