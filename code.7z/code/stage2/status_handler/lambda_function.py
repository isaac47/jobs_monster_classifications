import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.dynamodb_utils import get_item, query_items
from common.utils.logger import get_logger
from common.utils.sqs_utils import get_queue_url, send_message

logger = get_logger(__name__)


def convert_dynamodb_value(value: Dict[str, Any]) -> Any:
    """
    Convert a single DynamoDB attribute value to Python value.

    Args:
        value: DynamoDB attribute value

    Returns:
        Converted Python value
    """
    if "S" in value:
        return value["S"]
    elif "N" in value:
        try:
            # Try integer first, then float
            num_str = value["N"]
            if "." in num_str:
                return float(num_str)
            else:
                return int(num_str)
        except ValueError:
            return value["N"]  # Return as string if conversion fails
    elif "BOOL" in value:
        return value["BOOL"]
    elif "NULL" in value:
        return None
    elif "L" in value:
        return [convert_dynamodb_value({"item": item}) for item in value["L"]]
    elif "M" in value:
        return convert_dynamodb_item(value["M"])
    elif "SS" in value:
        return value["SS"]  # String set
    elif "NS" in value:
        return [float(n) if "." in n else int(n) for n in value["NS"]]  # Number set
    else:
        # Unknown type, return as-is
        return value


def convert_dynamodb_item(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a DynamoDB item to a regular Python dictionary.

    Args:
        item: DynamoDB item with typed attributes

    Returns:
        Regular Python dictionary
    """
    if not item:
        return {}

    result = {}
    for key, value in item.items():
        try:
            result[key] = convert_dynamodb_value(value)
        except Exception as e:
            logger.warning(f"Error converting DynamoDB value for key {key}: {e}")
            # Keep the original value if conversion fails
            result[key] = value

    return result


def parse_dynamodb_stream_event(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Parse DynamoDB stream event records.

    Args:
        event: DynamoDB stream event

    Returns:
        List[Dict[str, Any]]: List of parsed records
    """
    records = []

    for record in event.get("Records", []):
        try:
            if record.get("eventSource") != "aws:dynamodb":
                logger.debug("Skipping non-DynamoDB event")
                continue

            event_name = record.get("eventName")
            if event_name not in ["INSERT", "MODIFY"]:
                logger.debug(f"Skipping event type: {event_name}")
                continue

            # Extract images
            new_image = record.get("dynamodb", {}).get("NewImage", {})
            old_image = record.get("dynamodb", {}).get("OldImage", {})

            if not new_image:
                logger.warning("No NewImage found in DynamoDB stream record")
                continue

            # Convert DynamoDB format to regular dict
            new_record = convert_dynamodb_item(new_image)
            old_record = convert_dynamodb_item(old_image) if old_image else {}

            # Get table name from eventSourceARN
            table_name = ""
            event_source_arn = record.get("eventSourceARN", "")
            if "/" in event_source_arn:
                table_name = event_source_arn.split("/")[1]

            records.append(
                {
                    "eventName": event_name,
                    "newRecord": new_record,
                    "oldRecord": old_record,
                    "tableName": table_name,
                    "eventSourceARN": event_source_arn,
                }
            )

        except Exception as e:
            logger.error(f"Error parsing DynamoDB stream record: {e}")
            logger.error(f"Record: {json.dumps(record, default=str)}")
            continue

    return records


def check_analyze_status(analyze_id: str) -> bool:
    """
    Critical Check: Query analyze_id status → If "failed", skip processing.

    Args:
        analyze_id: Analyze identifier

    Returns:
        bool: True if analyze can continue, False if failed/should skip
    """
    try:
        analyze_record = get_item(
            EnvVars.KPI_ANALYZE_STATUS_TABLE, {"analyze_id": analyze_id}
        )

        if not analyze_record:
            logger.error(f"Analyze record not found: {analyze_id}")
            return False

        status = analyze_record.get("status")
        if status == "failed":
            logger.info(f"Analyze already failed, skipping processing: {analyze_id}")
            return False

        logger.info(f"Analyze status is {status}, proceeding with processing")
        return True

    except Exception as e:
        logger.error(f"Error checking analyze status: {e}")
        return False


def send_to_embedding_queue(file_id: str, analyze_id: str) -> bool:
    """
    Send message to embedding queue for files that reached "docling_complete".

    Args:
        file_id: File identifier
        analyze_id: Analyze identifier

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Get embedding queue URL
        queue_url = get_queue_url(EnvVars.EMBEDDING_QUEUE_NAME)
        if not queue_url:
            logger.error(f"Embedding queue not found: {EnvVars.EMBEDDING_QUEUE_NAME}")
            return False

        # Prepare message for embedding stage
        message = {
            "file_id": file_id,
            "analyze_id": analyze_id,
            "stage": "embedding",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_stage": "docling_complete",
        }

        # Send message to embedding queue
        message_id = send_message(queue_url, message)
        if message_id:
            logger.info(f"Sent file {file_id} to embedding queue: {message_id}")
            return True
        else:
            logger.error(f"Failed to send file {file_id} to embedding queue")
            return False

    except Exception as e:
        logger.error(f"Error sending to embedding queue: {e}")
        return False


def monitor_analyze_progress(analyze_id: str) -> Dict[str, Any]:
    """
    Monitor overall progress for the analyze_id.

    Args:
        analyze_id: Analyze identifier

    Returns:
        Dict[str, Any]: Progress information
    """
    try:
        # Get analyze record to know total expected files
        analyze_record = get_item(
            EnvVars.KPI_ANALYZE_STATUS_TABLE, {"analyze_id": analyze_id}
        )
        if not analyze_record:
            logger.error(f"Analyze record not found: {analyze_id}")
            return {"error": "Analyze record not found"}

        total_files = analyze_record.get("total_files", 0)

        # Count files that have completed docling processing using query_items
        try:
            # Using query with GSI (Global Secondary Index)
            completed_files_records = query_items(
                table_name=EnvVars.KPI_FILE_STATUS_TABLE,
                index_name="analyze-id-index",
                key_condition_expression="analyze_id = :analyze_id",
                filter_expression="#status = :status",
                expression_attribute_names={"#status": "status"},
                expression_attribute_values={
                    ":analyze_id": analyze_id,
                    ":status": "docling_complete",
                },
            )
            completed_files = len(completed_files_records)

        except Exception as e:
            logger.warning(f"Error querying with GSI, falling back to scan: {e}")
            # Fallback to scan if GSI is not available
            import boto3

            dynamodb = boto3.client("dynamodb")

            try:
                response = dynamodb.scan(
                    TableName=EnvVars.KPI_FILE_STATUS_TABLE,
                    FilterExpression="analyze_id = :analyze_id AND #status = :status",
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={
                        ":analyze_id": {"S": analyze_id},
                        ":status": {"S": "docling_complete"},
                    },
                )
                completed_files = response.get("Count", 0)
            except Exception as scan_error:
                logger.error(f"Error with scan fallback: {scan_error}")
                completed_files = 0

        progress_info = {
            "analyze_id": analyze_id,
            "total_files": total_files,
            "completed_files": completed_files,
            "progress_percentage": (
                (completed_files / total_files * 100) if total_files > 0 else 0
            ),
            "all_files_completed": completed_files >= total_files,
        }

        logger.info(
            f"Progress for analyze {analyze_id}: {completed_files}/{total_files} files completed"
        )

        return progress_info

    except Exception as e:
        logger.error(f"Error monitoring analyze progress: {e}")
        return {"error": str(e)}


def handle_docling_complete_status(record: Dict[str, Any]) -> bool:
    """
    Handle file status changes to "docling_complete".

    Args:
        record: DynamoDB stream record

    Returns:
        bool: True if handled successfully, False otherwise
    """
    try:
        new_record = record["newRecord"]
        old_record = record["oldRecord"]

        file_id = new_record.get("file_id")
        analyze_id = new_record.get("analyze_id")
        new_status = new_record.get("status")
        old_status = old_record.get("status", "")

        if not file_id or not analyze_id:
            logger.warning("Missing file_id or analyze_id in record")
            return False

        # Only process files that just reached "docling_complete"
        if new_status != "docling_complete" or old_status == "docling_complete":
            logger.debug(f"Status change not relevant: {old_status} -> {new_status}")
            return True

        logger.info(f"Processing docling_complete for file {file_id}")

        # Critical Check: Query analyze_id status → If "failed", skip processing
        if not check_analyze_status(analyze_id):
            logger.info(f"Skipping processing for failed analyze: {analyze_id}")
            return True

        # Send message to embedding queue
        if not send_to_embedding_queue(file_id, analyze_id):
            logger.error(f"Failed to send file {file_id} to embedding queue")
            return False

        # Monitor overall progress for the analyze_id
        progress = monitor_analyze_progress(analyze_id)
        if "error" in progress:
            logger.error(f"Error monitoring progress: {progress['error']}")
        else:
            logger.info(
                f"Analyze progress: {progress['completed_files']}/{progress['total_files']} files"
            )

            # Log when all files are completed
            if progress.get("all_files_completed"):
                logger.info(
                    f"All files completed docling processing for analyze {analyze_id}"
                )

        return True

    except Exception as e:
        logger.error(f"Error handling docling_complete status: {e}")
        return False


def handle_file_status_change(record: Dict[str, Any]) -> bool:
    """
    Handle file status changes in the KPI pipeline.

    Args:
        record: DynamoDB stream record

    Returns:
        bool: True if handled successfully, False otherwise
    """
    try:
        # Only handle docling_complete status changes for Stage 2
        return handle_docling_complete_status(record)

    except Exception as e:
        logger.error(f"Error handling file status change: {e}")
        return False


def process_stream_record(record: Dict[str, Any]) -> bool:
    """
    Process a DynamoDB stream record.

    Args:
        record: DynamoDB stream record

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        table_name = record.get("tableName", "")

        # Only handle file status table changes
        if "kpi-file-status" in table_name:
            return handle_file_status_change(record)
        else:
            logger.debug(f"Ignoring event from table: {table_name}")
            return True

    except Exception as e:
        logger.error(f"Error processing stream record: {e}")
        return False


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for DynamoDB stream events - Stage 2 Status Handler.

    Trigger: DynamoDB Stream on file status changes to "docling_complete"
    Purpose: Coordinate progression to embedding stage

    Args:
        event: DynamoDB stream event
        context: Lambda context

    Returns:
        Dict[str, Any]: Response
    """
    logger.info(f"Received DynamoDB stream event for Stage 2")
    logger.debug(f"Event details: {json.dumps(event, default=str)}")

    try:
        # Parse DynamoDB stream records
        records = parse_dynamodb_stream_event(event)
        if not records:
            logger.info("No valid DynamoDB records found")
            return {
                "statusCode": 200,
                "body": json.dumps({"message": "No valid DynamoDB records found"}),
            }

        logger.info(f"Processing {len(records)} DynamoDB stream records")

        # Process each record
        results = []
        for record in records:
            try:
                success = process_stream_record(record)

                # Extract relevant info for logging
                new_record = record.get("newRecord", {})
                result_info = {
                    "tableName": record.get("tableName", ""),
                    "eventName": record.get("eventName", ""),
                    "fileId": new_record.get("file_id"),
                    "analyzeId": new_record.get("analyze_id"),
                    "oldStatus": record.get("oldRecord", {}).get("status"),
                    "newStatus": new_record.get("status"),
                    "success": success,
                }

                results.append(result_info)

                if success:
                    logger.info(f"Successfully processed record: {result_info}")
                else:
                    logger.error(f"Failed to process record: {result_info}")

            except Exception as e:
                logger.error(f"Error processing individual record: {e}")
                results.append(
                    {
                        "tableName": record.get("tableName", ""),
                        "eventName": record.get("eventName", ""),
                        "error": str(e),
                        "success": False,
                    }
                )

        # Check if any processing failed
        failed_count = sum(1 for result in results if not result["success"])
        success_count = len(results) - failed_count

        if failed_count > 0:
            logger.error(
                f"Failed to process {failed_count} out of {len(results)} records"
            )
        else:
            logger.info(f"Successfully processed all {success_count} records")

        return {
            "statusCode": 200,
            "body": json.dumps(
                {
                    "message": "Stage 2 status handling completed",
                    "results": results,
                    "total_records": len(results),
                    "success_count": success_count,
                    "failed_count": failed_count,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            ),
        }

    except Exception as e:
        error_msg = f"Critical error in status handler: {str(e)}"
        logger.error(error_msg)
        logger.error(f"Event that caused error: {json.dumps(event, default=str)}")

        return {
            "statusCode": 500,
            "body": json.dumps(
                {
                    "message": "Stage 2 status handling failed",
                    "error": error_msg,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            ),
        }


# For local testing
if __name__ == "__main__":
    # Test with sample DynamoDB stream event
    test_event = {
        "Records": [
            {
                "eventID": "test-event-id",
                "eventName": "MODIFY",
                "eventVersion": "1.1",
                "eventSource": "aws:dynamodb",
                "awsRegion": "eu-west-3",
                "eventSourceARN": "arn:aws:dynamodb:eu-west-3:123456789012:table/benchmark-kpi-file-status/stream/2023-12-01T00:00:00.000",
                "dynamodb": {
                    "ApproximateCreationDateTime": 1638360000.0,
                    "Keys": {"file_id": {"S": "test-file-123"}},
                    "NewImage": {
                        "file_id": {"S": "test-file-123"},
                        "analyze_id": {"S": "test-analyze-456"},
                        "status": {"S": "docling_complete"},
                        "updated_at": {"S": "2023-12-01T10:00:00Z"},
                    },
                    "OldImage": {
                        "file_id": {"S": "test-file-123"},
                        "analyze_id": {"S": "test-analyze-456"},
                        "status": {"S": "docling_processing"},
                        "updated_at": {"S": "2023-12-01T09:00:00Z"},
                    },
                    "SequenceNumber": "12345",
                    "SizeBytes": 123,
                    "StreamViewType": "NEW_AND_OLD_IMAGES",
                },
            }
        ]
    }

    # Mock context
    class MockContext:
        def __init__(self):
            self.function_name = "test-status-handler"
            self.memory_limit_in_mb = 256
            self.invoked_function_arn = (
                "arn:aws:lambda:eu-west-3:123456789012:function:test-status-handler"
            )

    context = MockContext()

    try:
        result = handler(test_event, context)
        print("Test result:")
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Test failed: {e}")
        import traceback

        traceback.print_exc()
