import json
import logging
from typing import Any, Dict, Optional, Tuple

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.dynamodb_utils import get_item, update_item
from common.utils.logger import get_logger

logger = get_logger(__name__)


class AnalyzeStatusChecker:
    """
    Utility class for checking and updating analyze status throughout the KPI pipeline.
    Implements the critical check pattern used in all stages.
    """

    @staticmethod
    def check_analyze_status(analyze_id: str) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """
        Critical Check: Query analyze_id status → If "failed", skip processing.

        Args:
            analyze_id: Analyze identifier

        Returns:
            Tuple[bool, Optional[Dict[str, Any]]]: (can_continue, analyze_record)
                - can_continue: True if analyze can continue, False if failed/should skip
                - analyze_record: The analyze record from DynamoDB, None if not found
        """
        try:
            analyze_record = get_item(
                EnvVars.KPI_ANALYZE_STATUS_TABLE, {"analyze_id": analyze_id}
            )

            if not analyze_record:
                logger.error(f"Analyze record not found: {analyze_id}")
                return False, None

            status = analyze_record.get("status")
            if status == "failed":
                logger.info(
                    f"Analyze already failed, skipping processing: {analyze_id}"
                )
                return False, analyze_record

            logger.debug(f"Analyze status is '{status}', proceeding with processing")
            return True, analyze_record

        except Exception as e:
            logger.error(f"Error checking analyze status for {analyze_id}: {e}")
            return False, None

    @staticmethod
    def mark_analyze_as_failed(analyze_id: str, reason: str, stage: str) -> bool:
        """
        Mark an analyze as failed with detailed reason and stage information.

        Args:
            analyze_id: Analyze identifier
            reason: Reason for failure
            stage: Stage where failure occurred

        Returns:
            bool: True if successfully marked as failed, False otherwise
        """
        try:
            from datetime import datetime, timezone

            update_expression = """
            SET #status = :status,
                failure_reason = :reason,
                failure_stage = :stage,
                failure_timestamp = :timestamp,
                updated_at = :updated_at
            """

            expression_values = {
                ":status": "failed",
                ":reason": reason,
                ":stage": stage,
                ":timestamp": datetime.now(timezone.utc).isoformat(),
                ":updated_at": datetime.now(timezone.utc).isoformat(),
            }

            expression_names = {
                "#status": "status"  # 'status' is a reserved word in DynamoDB
            }

            success = update_item(
                EnvVars.KPI_ANALYZE_STATUS_TABLE,
                {"analyze_id": analyze_id},
                update_expression,
                expression_values,
                expression_names,
            )

            if success:
                logger.error(
                    f"Marked analyze {analyze_id} as failed at stage {stage}: {reason}"
                )
            else:
                logger.error(f"Failed to mark analyze {analyze_id} as failed")

            return success

        except Exception as e:
            logger.error(f"Error marking analyze as failed: {e}")
            return False

    @staticmethod
    def get_analyze_parameters(analyze_id: str) -> Optional[Dict[str, Any]]:
        """
        Get analyze parameters including KPI list, taxonomy, and configuration.

        Args:
            analyze_id: Analyze identifier

        Returns:
            Optional[Dict[str, Any]]: Analyze parameters or None if not found
        """
        try:
            can_continue, analyze_record = AnalyzeStatusChecker.check_analyze_status(
                analyze_id
            )

            if not can_continue or not analyze_record:
                return None

            # Extract key parameters
            parameters = {
                "analyze_id": analyze_id,
                "kpi_list": analyze_record.get("kpi_list", []),
                "kpi_taxonomy": analyze_record.get("kpi_taxonomy", {}),
                "bank_id": analyze_record.get("bank_id", ""),
                "bank_is_french": analyze_record.get("bank_is_french", False),
                "detail_level": analyze_record.get("detail_level", ""),
                "total_files": analyze_record.get("total_files", 0),
                "file_categories": analyze_record.get("file_categories", []),
                "status": analyze_record.get("status", "processing"),
            }

            return parameters

        except Exception as e:
            logger.error(f"Error getting analyze parameters: {e}")
            return None

    @staticmethod
    def validate_analyze_integrity(analyze_id: str) -> Dict[str, Any]:
        """
        Validate the integrity of an analyze operation by checking all related data.

        Args:
            analyze_id: Analyze identifier

        Returns:
            Dict[str, Any]: Validation results with details
        """
        try:
            results = {
                "analyze_id": analyze_id,
                "is_valid": True,
                "issues": [],
                "warnings": [],
                "file_count": 0,
                "chunk_count": 0,
                "status": "unknown",
            }

            # Check analyze record
            can_continue, analyze_record = AnalyzeStatusChecker.check_analyze_status(
                analyze_id
            )
            if not can_continue or not analyze_record:
                results["is_valid"] = False
                results["issues"].append("Analyze record not found or failed")
                return results

            results["status"] = analyze_record.get("status", "unknown")
            expected_files = analyze_record.get("total_files", 0)

            # Check file status records
            from common.utils.dynamodb_utils import query_items

            file_records = query_items(
                EnvVars.KPI_FILE_STATUS_TABLE,
                "analyze_id = :analyze_id",
                {":analyze_id": analyze_id},
            )

            results["file_count"] = len(file_records)

            if results["file_count"] != expected_files:
                results["warnings"].append(
                    f"Expected {expected_files} files, found {results['file_count']}"
                )

            # Check for failed files
            failed_files = [f for f in file_records if f.get("status") == "failed"]
            if failed_files:
                results["issues"].append(f"Found {len(failed_files)} failed files")
                results["is_valid"] = False

            # Check chunk records if any files completed docling
            completed_files = [
                f
                for f in file_records
                if f.get("status")
                in ["docling_complete", "embedding_complete", "retrieval_complete"]
            ]

            if completed_files:
                # Count chunks for completed files
                for file_record in completed_files:
                    file_id = file_record.get("file_id")
                    if file_id:
                        chunk_records = query_items(
                            EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
                            "file_id = :file_id",
                            {":file_id": file_id},
                        )
                        results["chunk_count"] += len(chunk_records)

            return results

        except Exception as e:
            logger.error(f"Error validating analyze integrity: {e}")
            return {
                "analyze_id": analyze_id,
                "is_valid": False,
                "issues": [f"Validation error: {str(e)}"],
                "warnings": [],
                "file_count": 0,
                "chunk_count": 0,
                "status": "error",
            }

    @staticmethod
    def get_processing_statistics(analyze_id: str) -> Dict[str, Any]:
        """
        Get detailed processing statistics for an analyze operation.

        Args:
            analyze_id: Analyze identifier

        Returns:
            Dict[str, Any]: Processing statistics
        """
        try:
            stats = {
                "analyze_id": analyze_id,
                "status_counts": {},
                "total_files": 0,
                "total_chunks": 0,
                "processing_times": {},
                "errors": [],
            }

            # Get all file records for this analyze
            from common.utils.dynamodb_utils import query_items

            file_records = query_items(
                EnvVars.KPI_FILE_STATUS_TABLE,
                "analyze_id = :analyze_id",
                {":analyze_id": analyze_id},
            )

            stats["total_files"] = len(file_records)

            # Count statuses
            status_counts = {}
            for file_record in file_records:
                status = file_record.get("status", "unknown")
                status_counts[status] = status_counts.get(status, 0) + 1

                # Collect errors
                if status == "failed" and "error_message" in file_record:
                    stats["errors"].append(
                        {
                            "file_id": file_record.get("file_id"),
                            "error": file_record.get("error_message"),
                        }
                    )

            stats["status_counts"] = status_counts

            # Calculate processing progress
            completed_stages = [
                "docling_complete",
                "embedding_complete",
                "retrieval_complete",
                "kpi_complete",
            ]
            progress_counts = sum(
                status_counts.get(stage, 0) for stage in completed_stages
            )
            stats["progress_percentage"] = (
                (progress_counts / stats["total_files"] * 100)
                if stats["total_files"] > 0
                else 0
            )

            return stats

        except Exception as e:
            logger.error(f"Error getting processing statistics: {e}")
            return {
                "analyze_id": analyze_id,
                "status_counts": {},
                "total_files": 0,
                "total_chunks": 0,
                "processing_times": {},
                "errors": [f"Statistics error: {str(e)}"],
            }
