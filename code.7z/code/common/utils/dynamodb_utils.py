import logging
from decimal import Decimal
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


def get_dynamodb_client():
    """Get the DynamoDB client."""
    return boto3.client("dynamodb")


def convert_to_dynamodb_format(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a Python dictionary to DynamoDB format.

    Args:
        item: Dictionary to convert

    Returns:
        Dict[str, Any]: Converted dictionary
    """
    if not item:
        return {}

    result = {}
    for key, value in item.items():
        if isinstance(value, dict):
            result[key] = {"M": convert_to_dynamodb_format(value)}
        elif isinstance(value, list):
            result[key] = {
                "L": [
                    (
                        convert_to_dynamodb_format(item)
                        if isinstance(item, dict)
                        else {"S" if isinstance(item, str) else "N": str(item)}
                    )
                    for item in value
                ]
            }
        elif isinstance(value, str):
            result[key] = {"S": value}
        elif isinstance(value, (int, float, Decimal)):
            result[key] = {"N": str(value)}
        elif isinstance(value, bool):
            result[key] = {"BOOL": value}
        elif value is None:
            result[key] = {"NULL": True}

    return result


def convert_from_dynamodb_format(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a DynamoDB format dictionary to a Python dictionary.

    Args:
        item: DynamoDB format dictionary

    Returns:
        Dict[str, Any]: Converted dictionary
    """
    if not item:
        return {}

    result = {}
    for key, value in item.items():
        if "M" in value:
            result[key] = convert_from_dynamodb_format(value["M"])
        elif "L" in value:
            result[key] = [
                (
                    convert_from_dynamodb_format(item)
                    if "M" in item
                    else item.get("S", item.get("N", item.get("BOOL", None)))
                )
                for item in value["L"]
            ]
        elif "S" in value:
            result[key] = value["S"]
        elif "N" in value:
            try:
                num = Decimal(value["N"])
                # Convert to int if it's a whole number
                if num % 1 == 0:
                    result[key] = int(num)
                else:
                    result[key] = float(num)
            except:
                result[key] = value["N"]  # Keep as string if conversion fails
        elif "BOOL" in value:
            result[key] = value["BOOL"]
        elif "NULL" in value:
            result[key] = None

    return result


def put_item(
    table_name: str, item: Dict[str, Any], condition_expression: Optional[str] = None
) -> bool:
    """
    Put an item into a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        item: Item to put
        condition_expression: Optional condition expression

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_dynamodb_client()
    try:
        params = {"TableName": table_name, "Item": convert_to_dynamodb_format(item)}

        if condition_expression:
            params["ConditionExpression"] = condition_expression

        client.put_item(**params)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            logger.info(f"Condition check failed for item: {item}")
        else:
            logger.error(f"Error putting item: {e}")
        return False


def get_item(table_name: str, key: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Get an item from a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        key: Primary key of the item to get

    Returns:
        Optional[Dict[str, Any]]: Item or None if not found or failed
    """
    client = get_dynamodb_client()
    try:
        response = client.get_item(
            TableName=table_name, Key=convert_to_dynamodb_format(key)
        )

        if "Item" in response:
            return convert_from_dynamodb_format(response["Item"])
        else:
            return None
    except ClientError as e:
        logger.error(f"Error getting item: {e}")
        return None


def update_item(
    table_name: str,
    key: Dict[str, Any],
    update_expression: str,
    expression_attribute_values: Dict[str, Any],
    expression_attribute_names: Optional[Dict[str, str]] = None,
    condition_expression: Optional[str] = None,
) -> bool:
    """
    Update an item in a DynamoDB table.

    Args:
        table_name: DynamoDB table name
        key: Primary key of the item to update
        update_expression: Update expression
        expression_attribute_values: Expression attribute values
        expression_attribute_names: Optional expression attribute names
        condition_expression: Optional condition expression

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_dynamodb_client()
    try:
        params = {
            "TableName": table_name,
            "Key": convert_to_dynamodb_format(key),
            "UpdateExpression": update_expression,
            "ExpressionAttributeValues": convert_to_dynamodb_format(
                expression_attribute_values
            ),
        }

        if expression_attribute_names:
            params["ExpressionAttributeNames"] = expression_attribute_names

        if condition_expression:
            params["ConditionExpression"] = condition_expression

        client.update_item(**params)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            logger.info(f"Condition check failed for update: {key}")
        else:
            logger.error(f"Error updating item: {e}")
        return False


def scan_table_with_filter(
    table_name: str,
    filter_expression: str,
    expression_attribute_values: Dict[str, Any],
    expression_attribute_names: Optional[Dict[str, str]] = None,
) -> List[Dict[str, Any]]:
    """
    Scan a DynamoDB table with filter expression.

    Args:
        table_name: DynamoDB table name
        filter_expression: Filter expression
        expression_attribute_values: Expression attribute values
        expression_attribute_names: Optional expression attribute names

    Returns:
        List[Dict[str, Any]]: List of items matching the filter
    """
    client = get_dynamodb_client()
    try:
        params = {
            "TableName": table_name,
            "FilterExpression": filter_expression,
            "ExpressionAttributeValues": convert_to_dynamodb_format(
                expression_attribute_values
            ),
        }

        if expression_attribute_names:
            params["ExpressionAttributeNames"] = expression_attribute_names

        response = client.scan(**params)

        items = []
        for item in response.get("Items", []):
            items.append(convert_from_dynamodb_format(item))

        return items
    except ClientError as e:
        logger.error(f"Error scanning table: {e}")
        return []
