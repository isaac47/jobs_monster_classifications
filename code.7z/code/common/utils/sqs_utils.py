import json
from decimal import Decimal
from typing import Any, Dict, List, Optional, Union

import boto3
from botocore.exceptions import ClientError
from common.utils.logger import get_logger

logger = get_logger(__name__)


class DecimalEncoder(json.JSONEncoder):
    """Custom JSON encoder for Decimal values."""

    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)


def get_sqs_client():
    """Get the SQS client."""
    return boto3.client("sqs")


def get_queue_url(queue_name: str) -> Optional[str]:
    """
    Get the URL of an SQS queue.

    Args:
        queue_name: Name of the queue

    Returns:
        Optional[str]: Queue URL or None if failed
    """
    client = get_sqs_client()
    try:
        response = client.get_queue_url(QueueName=queue_name)
        return response["QueueUrl"]
    except ClientError as e:
        logger.error(f"Error getting queue URL for {queue_name}: {e}")
        return None


def send_message(
    queue_url: str,
    message_body: Union[str, Dict[str, Any]],
    message_attributes: Optional[Dict[str, Dict[str, Any]]] = None,
    delay_seconds: int = 0,
    message_group_id: Optional[str] = None,
    message_deduplication_id: Optional[str] = None,
) -> Optional[str]:
    """
    Send a message to an SQS queue.

    Args:
        queue_url: URL of the queue
        message_body: Message body (string or JSON-serializable object)
        message_attributes: Optional message attributes
        delay_seconds: Optional delay in seconds
        message_group_id: Optional message group ID (for FIFO queues)
        message_deduplication_id: Optional message deduplication ID (for FIFO queues)

    Returns:
        Optional[str]: Message ID or None if failed
    """
    client = get_sqs_client()

    # Convert message_body to string if it's a dict
    if isinstance(message_body, dict):
        message_body = json.dumps(message_body, cls=DecimalEncoder)

    try:
        params = {
            "QueueUrl": queue_url,
            "MessageBody": message_body,
            "DelaySeconds": delay_seconds,
        }

        if message_attributes:
            params["MessageAttributes"] = message_attributes

        if message_group_id:
            params["MessageGroupId"] = message_group_id

        if message_deduplication_id:
            params["MessageDeduplicationId"] = message_deduplication_id

        response = client.send_message(**params)
        return response.get("MessageId")
    except ClientError as e:
        logger.error(f"Error sending message to SQS: {e}")
        return None


def send_message_batch(
    queue_url: str, entries: List[Dict[str, Any]]
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Send a batch of messages to an SQS queue.

    Args:
        queue_url: URL of the queue
        entries: List of message entries
            Each entry should have:
            - Id: Unique ID for the message (required)
            - MessageBody: Message body (required)
            - DelaySeconds: Optional delay in seconds
            - MessageAttributes: Optional message attributes
            - MessageGroupId: Optional message group ID (for FIFO queues)
            - MessageDeduplicationId: Optional message deduplication ID (for FIFO queues)

    Returns:
        Dict[str, List[Dict[str, Any]]]: Dictionary with 'Successful' and 'Failed' entries
    """
    client = get_sqs_client()

    # Process entries to ensure MessageBody is string
    for entry in entries:
        if isinstance(entry.get("MessageBody"), dict):
            entry["MessageBody"] = json.dumps(entry["MessageBody"], cls=DecimalEncoder)

    try:
        response = client.send_message_batch(QueueUrl=queue_url, Entries=entries)

        result = {
            "Successful": response.get("Successful", []),
            "Failed": response.get("Failed", []),
        }

        if result["Failed"]:
            logger.warning(f"Some messages failed to send: {result['Failed']}")

        return result
    except ClientError as e:
        logger.error(f"Error sending batch messages to SQS: {e}")
        return {"Successful": [], "Failed": entries}


def receive_messages(
    queue_url: str,
    max_number_of_messages: int = 1,
    visibility_timeout: int = 30,
    wait_time_seconds: int = 0,
    attribute_names: List[str] = ["All"],
    message_attribute_names: List[str] = ["All"],
) -> List[Dict[str, Any]]:
    """
    Receive messages from an SQS queue.

    Args:
        queue_url: URL of the queue
        max_number_of_messages: Maximum number of messages to receive (1-10)
        visibility_timeout: Visibility timeout in seconds
        wait_time_seconds: Wait time in seconds (0-20, 0 means no wait)
        attribute_names: Message attributes to return
        message_attribute_names: Message attribute names to return

    Returns:
        List[Dict[str, Any]]: List of messages
    """
    client = get_sqs_client()
    try:
        response = client.receive_message(
            QueueUrl=queue_url,
            MaxNumberOfMessages=max_number_of_messages,
            VisibilityTimeout=visibility_timeout,
            WaitTimeSeconds=wait_time_seconds,
            AttributeNames=attribute_names,
            MessageAttributeNames=message_attribute_names,
        )

        return response.get("Messages", [])
    except ClientError as e:
        logger.error(f"Error receiving messages from SQS: {e}")
        return []


def delete_message(queue_url: str, receipt_handle: str) -> bool:
    """
    Delete a message from an SQS queue.

    Args:
        queue_url: URL of the queue
        receipt_handle: Receipt handle of the message to delete

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_sqs_client()
    try:
        client.delete_message(QueueUrl=queue_url, ReceiptHandle=receipt_handle)
        return True
    except ClientError as e:
        logger.error(f"Error deleting message from SQS: {e}")
        return False


def delete_message_batch(
    queue_url: str, entries: List[Dict[str, str]]
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Delete a batch of messages from an SQS queue.

    Args:
        queue_url: URL of the queue
        entries: List of message entries to delete
            Each entry should have:
            - Id: Unique ID for the message (required)
            - ReceiptHandle: Receipt handle of the message (required)

    Returns:
        Dict[str, List[Dict[str, Any]]]: Dictionary with 'Successful' and 'Failed' entries
    """
    client = get_sqs_client()
    try:
        response = client.delete_message_batch(QueueUrl=queue_url, Entries=entries)

        result = {
            "Successful": response.get("Successful", []),
            "Failed": response.get("Failed", []),
        }

        if result["Failed"]:
            logger.warning(f"Some messages failed to delete: {result['Failed']}")

        return result
    except ClientError as e:
        logger.error(f"Error deleting batch messages from SQS: {e}")
        return {"Successful": [], "Failed": entries}


def change_message_visibility(
    queue_url: str, receipt_handle: str, visibility_timeout: int
) -> bool:
    """
    Change the visibility timeout of a message.

    Args:
        queue_url: URL of the queue
        receipt_handle: Receipt handle of the message
        visibility_timeout: New visibility timeout in seconds

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_sqs_client()
    try:
        client.change_message_visibility(
            QueueUrl=queue_url,
            ReceiptHandle=receipt_handle,
            VisibilityTimeout=visibility_timeout,
        )
        return True
    except ClientError as e:
        logger.error(f"Error changing message visibility: {e}")
        return False


def change_message_visibility_batch(
    queue_url: str, entries: List[Dict[str, Any]]
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Change the visibility timeout of a batch of messages.

    Args:
        queue_url: URL of the queue
        entries: List of message entries
            Each entry should have:
            - Id: Unique ID for the message (required)
            - ReceiptHandle: Receipt handle of the message (required)
            - VisibilityTimeout: New visibility timeout in seconds (required)

    Returns:
        Dict[str, List[Dict[str, Any]]]: Dictionary with 'Successful' and 'Failed' entries
    """
    client = get_sqs_client()
    try:
        response = client.change_message_visibility_batch(
            QueueUrl=queue_url, Entries=entries
        )

        result = {
            "Successful": response.get("Successful", []),
            "Failed": response.get("Failed", []),
        }

        if result["Failed"]:
            logger.warning(
                f"Some messages failed to change visibility: {result['Failed']}"
            )

        return result
    except ClientError as e:
        logger.error(f"Error changing batch message visibility: {e}")
        return {"Successful": [], "Failed": entries}


def create_queue(
    queue_name: str,
    attributes: Optional[Dict[str, str]] = None,
    tags: Optional[Dict[str, str]] = None,
) -> Optional[str]:
    """
    Create an SQS queue.

    Args:
        queue_name: Name of the queue to create
        attributes: Optional queue attributes
        tags: Optional tags

    Returns:
        Optional[str]: Queue URL or None if failed
    """
    client = get_sqs_client()
    try:
        params = {"QueueName": queue_name}

        if attributes:
            params["Attributes"] = attributes

        response = client.create_queue(**params)

        queue_url = response.get("QueueUrl")

        # Add tags if provided
        if tags and queue_url:
            client.tag_queue(QueueUrl=queue_url, Tags=tags)

        return queue_url
    except ClientError as e:
        logger.error(f"Error creating SQS queue: {e}")
        return None


def delete_queue(queue_url: str) -> bool:
    """
    Delete an SQS queue.

    Args:
        queue_url: URL of the queue to delete

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_sqs_client()
    try:
        client.delete_queue(QueueUrl=queue_url)
        return True
    except ClientError as e:
        logger.error(f"Error deleting SQS queue: {e}")
        return False


def purge_queue(queue_url: str) -> bool:
    """
    Purge all messages from an SQS queue.

    Args:
        queue_url: URL of the queue to purge

    Returns:
        bool: True if successful, False otherwise
    """
    client = get_sqs_client()
    try:
        client.purge_queue(QueueUrl=queue_url)
        return True
    except ClientError as e:
        logger.error(f"Error purging SQS queue: {e}")
        return False
