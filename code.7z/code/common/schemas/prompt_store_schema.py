# FILE PATH: ./common/schemas/prompt_store_schema.py

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class PromptTemplate(BaseModel):
    """Model for prompt templates stored in DynamoDB."""

    # Primary Keys
    bank_id: str = Field(
        ..., description="Bank identifier or 'default' for global templates"
    )
    document_category: str = Field(
        ..., description="Document category or template type"
    )

    # Template Content
    template_name: str = Field(..., description="Human-readable name for the template")
    template_type: str = Field(
        ..., description="Type of template (kpi_extraction, document_analysis, etc.)"
    )

    # Prompt Templates for Different Stages
    kpi_extraction_template: Optional[str] = Field(
        None, description="Template for KPI extraction stage"
    )
    document_analysis_template: Optional[str] = Field(
        None, description="Template for document analysis"
    )
    chunk_analysis_template: Optional[str] = Field(
        None, description="Template for chunk analysis"
    )
    context_retrieval_template: Optional[str] = Field(
        None, description="Template for context retrieval"
    )

    # Template Metadata
    language: str = Field(
        default="en", description="Language of the template (en, fr, etc.)"
    )
    version: str = Field(default="1.0", description="Template version")
    priority: int = Field(
        default=100,
        description="Priority for template selection (lower = higher priority)",
    )

    # Configuration
    model_specific_config: Dict[str, Any] = Field(
        default_factory=dict, description="Model-specific configurations"
    )
    parameters: Dict[str, Any] = Field(
        default_factory=dict, description="Template parameters and defaults"
    )

    # Metadata
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    created_by: str = Field(
        default="system", description="User who created the template"
    )
    description: str = Field(default="", description="Template description")
    tags: List[str] = Field(
        default_factory=list, description="Tags for template categorization"
    )

    # Status
    is_active: bool = Field(default=True, description="Whether template is active")

    class Config:
        use_enum_values = True


# Sample prompt templates data
SAMPLE_PROMPT_TEMPLATES = [
    # Global Default KPI Extraction Template
    {
        "bank_id": "default",
        "document_category": "kpi_extraction_default",
        "template_name": "Global KPI Extraction Template",
        "template_type": "kpi_extraction",
        "kpi_extraction_template": """You are a financial document analysis expert specializing in extracting Key Performance Indicators (KPIs) from banking and financial documents.

## Task
Extract the specified KPIs from the provided financial document context with high accuracy and precision.

## Instructions
1. **Accuracy**: Only extract KPIs that are explicitly mentioned or can be directly calculated from the provided context
2. **Precision**: Provide exact values with appropriate units and time periods
3. **Confidence**: Assign confidence scores based on clarity and explicitness of information
4. **Source Attribution**: Always reference the exact source text where each KPI was found
5. **Consistency**: Maintain consistent formatting across all extractions

## KPI Extraction Guidelines
- Look for both explicit mentions and synonymous terms
- Consider context and section headings for additional validation
- Extract values with their complete context (period, scope, units)
- Handle currency conversions and unit standardization
- Identify calculation methodologies when present

## Quality Standards
- High Confidence (0.8-1.0): Explicitly stated values with clear context
- Medium Confidence (0.5-0.8): Values requiring minor interpretation or calculation
- Low Confidence (0.3-0.5): Values requiring significant interpretation
- Below 0.3: Do not extract (insufficient evidence)

## Output Requirements
- Provide structured JSON output as specified
- Include confidence scores for each extraction
- Reference source text exactly as it appears
- Specify time periods and measurement units
- Note any assumptions or calculations made""",
        "language": "en",
        "version": "1.0",
        "priority": 100,
        "model_specific_config": {
            "claude": {"temperature": 0.1, "max_tokens": 4000, "top_p": 0.9}
        },
        "parameters": {
            "min_confidence_threshold": 0.3,
            "max_kpis_per_extraction": 50,
            "require_source_text": True,
            "standardize_units": True,
        },
        "description": "Default template for KPI extraction from financial documents",
        "tags": ["kpi", "extraction", "financial", "default"],
        "is_active": True,
    },
    # French Banks KPI Extraction Template
    {
        "bank_id": "default",
        "document_category": "kpi_extraction_french",
        "template_name": "French Banking KPI Extraction Template",
        "template_type": "kpi_extraction",
        "kpi_extraction_template": """Vous êtes un expert en analyse de documents financiers spécialisé dans l'extraction d'indicateurs clés de performance (KPI) des documents bancaires français.

## Tâche
Extraire les KPI spécifiés du contexte de document financier fourni avec une haute précision et exactitude.

## Instructions
1. **Précision**: N'extraire que les KPI explicitement mentionnés ou directement calculables à partir du contexte fourni
2. **Exactitude**: Fournir des valeurs exactes avec les unités et périodes appropriées
3. **Confiance**: Attribuer des scores de confiance basés sur la clarté et l'explicité de l'information
4. **Attribution de source**: Toujours référencer le texte source exact où chaque KPI a été trouvé
5. **Cohérence**: Maintenir un formatage cohérent pour toutes les extractions

## Directives d'extraction KPI
- Rechercher les mentions explicites et les termes synonymes
- Considérer le contexte et les en-têtes de section pour validation supplémentaire
- Extraire les valeurs avec leur contexte complet (période, portée, unités)
- Gérer les conversions de devises et la standardisation des unités
- Identifier les méthodologies de calcul quand présentes

## Termes financiers français courants
- Produit Net Bancaire (PNB) = Net Banking Income
- Résultat Net = Net Income
- Coefficient d'Exploitation = Cost Income Ratio
- Rentabilité des Capitaux Propres = ROE
- Ratio de Solvabilité = Solvency Ratio
- Provisions pour Créances Douteuses = Loan Loss Provisions

## Standards de qualité
- Confiance Élevée (0.8-1.0): Valeurs explicitement énoncées avec contexte clair
- Confiance Moyenne (0.5-0.8): Valeurs nécessitant une interprétation ou calcul mineur
- Confiance Faible (0.3-0.5): Valeurs nécessitant une interprétation significative
- En dessous de 0.3: Ne pas extraire (preuves insuffisantes)

## Exigences de sortie
- Fournir une sortie JSON structurée comme spécifié
- Inclure les scores de confiance pour chaque extraction
- Référencer le texte source exactement tel qu'il apparaît
- Spécifier les périodes de temps et unités de mesure
- Noter toute hypothèse ou calcul effectué""",
        "language": "fr",
        "version": "1.0",
        "priority": 90,
        "model_specific_config": {
            "claude": {"temperature": 0.1, "max_tokens": 4000, "top_p": 0.9}
        },
        "parameters": {
            "min_confidence_threshold": 0.3,
            "max_kpis_per_extraction": 50,
            "require_source_text": True,
            "standardize_units": True,
            "french_terminology": True,
        },
        "description": "Template optimized for French banking documents and terminology",
        "tags": ["kpi", "extraction", "financial", "french", "banking"],
        "is_active": True,
    },
    # Annual Report Specific Template
    {
        "bank_id": "default",
        "document_category": "annual_report",
        "template_name": "Annual Report KPI Extraction",
        "template_type": "kpi_extraction",
        "kpi_extraction_template": """You are analyzing an ANNUAL REPORT from a financial institution. Annual reports contain comprehensive financial data with detailed breakdowns and year-over-year comparisons.

## Document Context: Annual Report
Annual reports typically include:
- Consolidated financial statements
- Management discussion and analysis
- Risk management disclosures
- Capital adequacy information
- Segment reporting details
- Historical performance data

## Extraction Focus for Annual Reports
1. **Consolidated Metrics**: Focus on group-level consolidated figures
2. **Year-over-Year Changes**: Look for percentage changes and growth rates
3. **Segment Analysis**: Extract segment-specific KPIs when available
4. **Regulatory Metrics**: Pay special attention to regulatory capital ratios
5. **Forward-Looking Statements**: Identify guidance and targets when present

## Common Annual Report Sections
- Executive Summary / CEO Letter
- Financial Highlights
- Management Discussion & Analysis (MD&A)
- Consolidated Financial Statements
- Notes to Financial Statements
- Risk Management
- Capital Management
- Segment Performance

## Enhanced Extraction Guidelines
- Prioritize audited figures over unaudited estimates
- Look for "adjusted" or "underlying" metrics in addition to reported figures
- Extract both absolute values and percentage changes
- Pay attention to exceptional items and one-time charges
- Consider seasonal adjustments and normalization factors

## Quality Indicators for Annual Reports
- References to auditor opinions increase confidence
- Reconciliation tables provide validation opportunities
- Regulatory filing consistency enhances reliability
- Management commentary provides context validation""",
        "language": "en",
        "version": "1.0",
        "priority": 80,
        "parameters": {
            "prefer_audited_figures": True,
            "include_year_over_year": True,
            "extract_segment_data": True,
            "focus_regulatory_metrics": True,
        },
        "description": "Specialized template for annual report analysis",
        "tags": ["annual_report", "comprehensive", "audited", "regulatory"],
        "is_active": True,
    },
    # Quarterly Report Template
    {
        "bank_id": "default",
        "document_category": "serie_trimestrielle",
        "template_name": "Quarterly Results KPI Extraction",
        "template_type": "kpi_extraction",
        "kpi_extraction_template": """You are analyzing QUARTERLY FINANCIAL RESULTS from a banking institution. Quarterly reports focus on recent performance with comparisons to previous quarters and year-ago periods.

## Document Context: Quarterly Results
Quarterly reports typically include:
- Income statement highlights
- Balance sheet key metrics
- Quarter-over-quarter changes
- Year-over-year comparisons
- Seasonal adjustment factors
- Forward guidance updates

## Extraction Focus for Quarterly Results
1. **Current Quarter Performance**: Primary focus on Q[X] 20XX results
2. **Comparative Analysis**: Look for QoQ and YoY changes
3. **Seasonal Factors**: Consider seasonal business patterns
4. **Interim Metrics**: May include unaudited figures
5. **Trend Analysis**: Identify momentum and trajectory

## Common Quarterly Metrics
- Net Interest Income (NII)
- Non-Interest Income
- Operating Expenses
- Provision for Credit Losses
- Net Income
- Earnings Per Share (EPS)
- Return on Equity (ROE)
- Efficiency Ratio
- Net Interest Margin (NIM)

## Temporal Context Guidelines
- Always specify the quarter and year (e.g., "Q3 2023")
- Look for both absolute values and percentage changes
- Distinguish between quarterly and year-to-date figures
- Note any seasonal adjustments or normalization

## Quarterly Report Quality Factors
- Management commentary provides context
- Variance explanations enhance understanding
- Forward guidance indicates confidence level
- Regulatory update compliance""",
        "language": "en",
        "version": "1.0",
        "priority": 80,
        "parameters": {
            "require_quarterly_period": True,
            "include_comparatives": True,
            "seasonal_awareness": True,
            "trend_analysis": True,
        },
        "description": "Template optimized for quarterly financial results",
        "tags": ["quarterly", "serie_trimestrielle", "comparative", "trends"],
        "is_active": True,
    },
    # Press Release Template
    {
        "bank_id": "default",
        "document_category": "communique_presse",
        "template_name": "Press Release KPI Extraction",
        "template_type": "kpi_extraction",
        "kpi_extraction_template": """You are analyzing a PRESS RELEASE from a financial institution. Press releases highlight key financial results and strategic announcements with focus on headline metrics.

## Document Context: Press Release
Press releases typically include:
- Headline financial results
- Key performance highlights
- Management quotes and commentary
- Strategic announcements
- Forward-looking statements
- Contact information

## Extraction Focus for Press Releases
1. **Headline Metrics**: Focus on prominently featured KPIs
2. **Management Emphasis**: Pay attention to metrics highlighted in quotes
3. **Strategic Context**: Consider business developments and their impact
4. **Market Communication**: Understand investor-focused messaging
5. **Concise Information**: Extract from condensed, high-level summaries

## Press Release Structure
- Headline and dateline
- Lead paragraph with key results
- Supporting paragraphs with details
- Management commentary
- Forward-looking statements
- About the company section

## Communication Style Awareness
- Results are typically presented in a positive light
- Key achievements are emphasized
- Challenges may be addressed with mitigation strategies
- Forward guidance reflects management confidence
- Market-relevant metrics are prioritized

## Quality Considerations for Press Releases
- Official company communications have high reliability
- Headline figures receive priority treatment
- Management quotes provide context and confidence
- Regulatory compliance ensures accuracy
- Market timing indicates significance

## Extraction Guidelines
- Prioritize headline metrics mentioned early in the document
- Pay special attention to figures mentioned in management quotes
- Look for superlatives and record achievements
- Consider context of strategic announcements
- Extract forward guidance with appropriate confidence levels""",
        "language": "en",
        "version": "1.0",
        "priority": 80,
        "parameters": {
            "prioritize_headlines": True,
            "management_quote_boost": True,
            "strategic_context": True,
            "forward_guidance": True,
        },
        "description": "Template for press release analysis and communication",
        "tags": ["press_release", "communique_presse", "headlines", "communication"],
        "is_active": True,
    },
    # Bank-Specific Template Example (BNP Paribas)
    {
        "bank_id": "BNP001",
        "document_category": "kpi_extraction_default",
        "template_name": "BNP Paribas Specific KPI Extraction",
        "template_type": "kpi_extraction",
        "kpi_extraction_template": """You are analyzing financial documents from BNP PARIBAS, a major French international banking group.

## BNP Paribas Specific Context
BNP Paribas reports using specific terminology and business segment structure:

### Business Segments
- Retail Banking & Services (RBS)
- Corporate & Institutional Banking (CIB)  
- International Financial Services (IFS)
- Other Activities

### Common BNP Paribas Metrics
- "Revenues" (total operating income)
- "Operating expenses" (total operating expenses)
- "Gross operating income" (revenues minus operating expenses)
- "Cost of risk" (provision for credit losses)
- "Operating income" (gross operating income minus cost of risk)
- "Net income attributable to equity holders"

### BNP Paribas Terminology
- "Basis points" for changes in rates and ratios
- "Restatement" for adjusted figures
- "At constant scope and exchange rates" for normalized comparisons
- "Underlying" for adjusted metrics excluding exceptional items

### Regulatory Context
- European banking regulations (CRD IV/CRR)
- French GAAP and IFRS reporting
- ECB supervision requirements
- Basel III compliance metrics

## Enhanced Instructions for BNP Paribas
1. **Segment Focus**: Extract both consolidated and segment-level metrics
2. **Currency Considerations**: Handle EUR reporting and foreign exchange impacts  
3. **Regulatory Compliance**: Pay attention to capital adequacy ratios
4. **French Terminology**: Understand French financial terms and their English equivalents
5. **Business Model**: Consider universal banking model in analysis

## Quality Standards
- Prefer "underlying" adjusted figures when available
- Give higher confidence to audited annual figures
- Consider seasonal patterns in quarterly results
- Validate against regulatory filing requirements""",
        "language": "en",
        "version": "1.0",
        "priority": 50,  # Higher priority for BNP-specific documents
        "model_specific_config": {"claude": {"temperature": 0.1, "max_tokens": 4000}},
        "parameters": {
            "bnp_specific_terminology": True,
            "segment_analysis": True,
            "european_regulatory_context": True,
            "currency_eur_focus": True,
        },
        "description": "BNP Paribas specific template with terminology and context",
        "tags": ["bnp_paribas", "french_bank", "universal_banking", "european"],
        "is_active": True,
    },
    # Chunk Analysis Template (for Stage 4 - Retrieval)
    {
        "bank_id": "default",
        "document_category": "chunk_analysis_default",
        "template_name": "Document Chunk Analysis",
        "template_type": "chunk_analysis",
        "chunk_analysis_template": """You are analyzing document chunks to identify potential KPI-related content for improved retrieval accuracy.

## Task
Analyze document chunks and determine their relevance for KPI extraction, providing semantic understanding and context.

## Analysis Criteria
1. **Financial Content**: Identify financial data, metrics, and performance indicators
2. **Contextual Relevance**: Assess relevance to banking and financial operations
3. **Data Quality**: Evaluate clarity and completeness of information
4. **Temporal Context**: Identify time periods and reporting dates
5. **Quantitative Content**: Highlight numerical data and calculations

## Chunk Classification
- **High Priority**: Direct KPI mentions, financial tables, performance summaries
- **Medium Priority**: Contextual information, methodology descriptions, comparative data
- **Low Priority**: General commentary, disclaimers, contact information

## Output Guidelines
- Provide relevance scores (0.0-1.0)
- Extract key financial terms and concepts
- Identify temporal references
- Note quantitative data patterns
- Suggest KPI associations""",
        "language": "en",
        "version": "1.0",
        "priority": 100,
        "description": "Template for analyzing document chunks for KPI relevance",
        "tags": ["chunk_analysis", "retrieval", "relevance", "preprocessing"],
        "is_active": True,
    },
    # Document Type Classification Template
    {
        "bank_id": "default",
        "document_category": "document_classification",
        "template_name": "Financial Document Classification",
        "template_type": "document_analysis",
        "document_analysis_template": """You are a financial document classification expert. Analyze the provided document content to classify the document type and extract key metadata.

## Classification Categories
1. **Annual Report**: Comprehensive yearly financial statements with full audited results
2. **Quarterly Report**: Interim financial results for a specific quarter
3. **Press Release**: Public announcement of financial results or corporate news
4. **Investor Presentation**: Slide deck prepared for investor communications
5. **Regulatory Filing**: Official regulatory submission or disclosure

## Analysis Framework
- Document structure and format indicators
- Content depth and comprehensiveness  
- Temporal references and reporting periods
- Regulatory compliance indicators
- Target audience characteristics

## Metadata Extraction
- Reporting period identification
- Company identification
- Document publication date
- Currency and geographical scope
- Auditor involvement (if applicable)

## Output Requirements
- Primary document classification
- Confidence score for classification
- Key metadata fields
- Content quality assessment
- Processing recommendations""",
        "language": "en",
        "version": "1.0",
        "priority": 100,
        "description": "Template for classifying financial document types",
        "tags": ["classification", "document_type", "metadata", "preprocessing"],
        "is_active": True,
    },
]
