import re
from typing import Any, Dict, List, Optional, Union

import tiktoken


class TokenCounter:
    """
    Utility class for counting tokens in text.
    """

    def __init__(self, encoding_name: str = "cl100k_base"):
        """
        Initialize the TokenCounter with the specified encoding.

        Args:
            encoding_name: The name of the tiktoken encoding to use.
                - 'cl100k_base' for Claude and most models
                - 'p50k_base' for GPT-3 models
                - 'r50k_base' for CodeX models
        """
        self.encoding = tiktoken.get_encoding(encoding_name)

    def count_tokens(self, text: str) -> int:
        """
        Count the number of tokens in the text.

        Args:
            text: The text to count tokens for

        Returns:
            int: Number of tokens
        """
        if not text:
            return 0

        return len(self.encoding.encode(text))

    def count_tokens_in_dict(self, data: Dict[str, Any]) -> int:
        """
        Count the number of tokens in a dictionary's string values.

        Args:
            data: Dictionary with string values

        Returns:
            int: Total number of tokens
        """
        if not data:
            return 0

        total_tokens = 0
        for key, value in data.items():
            if isinstance(value, str):
                total_tokens += self.count_tokens(value)
            elif isinstance(value, dict):
                total_tokens += self.count_tokens_in_dict(value)
            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, str):
                        total_tokens += self.count_tokens(item)
                    elif isinstance(item, dict):
                        total_tokens += self.count_tokens_in_dict(item)

        return total_tokens

    def truncate_text_to_token_limit(self, text: str, max_tokens: int) -> str:
        """
        Truncate text to fit within a token limit.

        Args:
            text: The text to truncate
            max_tokens: Maximum number of tokens

        Returns:
            str: Truncated text
        """
        if not text:
            return ""

        tokens = self.encoding.encode(text)

        if len(tokens) <= max_tokens:
            return text

        truncated_tokens = tokens[:max_tokens]
        return self.encoding.decode(truncated_tokens)

    def is_numeric_token(self, token_bytes: List[int]) -> bool:
        """
        Check if a token represents a numeric-only value.

        Args:
            token_bytes: Token bytes from tiktoken

        Returns:
            bool: True if the token is numeric-only, False otherwise
        """
        # Decode the token bytes to string
        token_str = self.encoding.decode(token_bytes)
        # Check if it's a numeric token (allowing periods and commas for decimals)
        return bool(re.match(r"^[0-9.,]+$", token_str.strip()))

    def count_numeric_tokens(self, text: str) -> int:
        """
        Count tokens that contain only numeric characters.

        Args:
            text: The input text

        Returns:
            int: The number of numeric-only tokens
        """
        if not text:
            return 0

        # Encode the text to get token IDs
        token_ids = self.encoding.encode(text)

        # Count numeric tokens
        numeric_count = 0
        for i in range(len(token_ids)):
            token_bytes = token_ids[i : i + 1]
            token_str = self.encoding.decode(token_bytes)
            if token_str.strip() and re.match(r"^[0-9.,]+$", token_str.strip()):
                numeric_count += 1

        return numeric_count

    def get_numeric_ratio(self, text: str) -> float:
        """
        Calculate the ratio of numeric tokens to total tokens.

        Args:
            text: The input text

        Returns:
            float: Ratio of numeric tokens (0.0 to 1.0)
        """
        if not text:
            return 0.0

        total_tokens = self.count_tokens(text)

        if total_tokens == 0:
            return 0.0

        numeric_tokens = self.count_numeric_tokens(text)
        return numeric_tokens / total_tokens

    def filter_numeric_tokens(self, text: str, threshold: float = 0.3) -> str:
        """
        Filter out excessive numeric tokens from text.

        Args:
            text: The input text
            threshold: Maximum percentage of numeric tokens allowed (default: 0.3 or 30%)

        Returns:
            str: Filtered text
        """
        if not text:
            return ""

        numeric_ratio = self.get_numeric_ratio(text)

        # If numeric tokens are below threshold, return original text
        if numeric_ratio <= threshold:
            return text

        # We need to tokenize, filter, and then detokenize
        token_ids = self.encoding.encode(text)
        filtered_ids = []

        # Process each token
        i = 0
        while i < len(token_ids):
            # Take one token at a time
            token_bytes = token_ids[i : i + 1]
            token_str = self.encoding.decode(token_bytes)

            # If it's not a numeric-only token, keep it
            if not (token_str.strip() and re.match(r"^[0-9.,]+$", token_str.strip())):
                filtered_ids.extend(token_bytes)

            i += 1

        # Decode filtered tokens back to text
        return self.encoding.decode(filtered_ids)

    def split_text_by_token_limit(
        self, text: str, max_tokens_per_chunk: int
    ) -> List[str]:
        """
        Split text into chunks that each fit within the token limit.

        Args:
            text: The input text
            max_tokens_per_chunk: Maximum tokens per chunk

        Returns:
            List[str]: List of text chunks
        """
        if not text:
            return []

        tokens = self.encoding.encode(text)

        if len(tokens) <= max_tokens_per_chunk:
            return [text]

        chunks = []
        for i in range(0, len(tokens), max_tokens_per_chunk):
            chunk_tokens = tokens[i : i + max_tokens_per_chunk]
            chunks.append(self.encoding.decode(chunk_tokens))

        return chunks

    def estimate_token_cost(
        self,
        input_text: str,
        output_text: str = "",
        input_price_per_1k: float = 0.01,
        output_price_per_1k: float = 0.03,
    ) -> Dict[str, Union[int, float]]:
        """
        Estimate the cost of processing text with an AI model.

        Args:
            input_text: Input text to the model
            output_text: Output text from the model
            input_price_per_1k: Price per 1,000 input tokens
            output_price_per_1k: Price per 1,000 output tokens

        Returns:
            Dict[str, Union[int, float]]: Dictionary with token counts and cost
        """
        input_tokens = self.count_tokens(input_text)
        output_tokens = self.count_tokens(output_text)

        input_cost = (input_tokens / 1000) * input_price_per_1k
        output_cost = (output_tokens / 1000) * output_price_per_1k
        total_cost = input_cost + output_cost

        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "input_cost": input_cost,
            "output_cost": output_cost,
            "total_cost": total_cost,
        }


class ChunkProcessor:
    """
    Process document chunks to optimize them for embedding.
    """

    def __init__(
        self, token_threshold: float = 0.3, encoding_name: str = "cl100k_base"
    ):
        """
        Initialize the ChunkProcessor.

        Args:
            token_threshold: Maximum percentage of numeric-only tokens allowed (default: 0.3 or 30%)
            encoding_name: The tiktoken encoding to use (default: "cl100k_base")
        """
        self.token_counter = TokenCounter(encoding_name)
        self.token_threshold = token_threshold

    def process_chunk(self, chunk: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a single chunk to prepare it for embedding.

        Args:
            chunk: A dictionary containing 'text', 'headings' and other metadata

        Returns:
            Dict[str, Any]: Processed chunk with filtered text and embedding-ready text
        """
        if not chunk or "text" not in chunk:
            return chunk

        text = chunk["text"]
        processed_chunk = chunk.copy()

        # Check numeric token ratio
        numeric_ratio = self.token_counter.get_numeric_ratio(text)

        # If numeric tokens exceed threshold, filter them out
        if numeric_ratio > self.token_threshold:
            processed_chunk["text"] = self.token_counter.filter_numeric_tokens(
                text, self.token_threshold
            )

        # Count tokens and add to metadata
        processed_chunk["token_count"] = self.token_counter.count_tokens(
            processed_chunk["text"]
        )

        # Create text_to_embed field
        if "headings" in chunk and chunk["headings"]:
            headings_text = " > ".join(chunk["headings"])
            processed_chunk["text_to_embed"] = (
                f"{headings_text}: {processed_chunk['text']}"
            )
        else:
            processed_chunk["text_to_embed"] = processed_chunk["text"]

        return processed_chunk

    def process_chunks(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Process multiple chunks.

        Args:
            chunks: List of chunk dictionaries

        Returns:
            List[Dict[str, Any]]: List of processed chunks
        """
        return [self.process_chunk(chunk) for chunk in chunks]
