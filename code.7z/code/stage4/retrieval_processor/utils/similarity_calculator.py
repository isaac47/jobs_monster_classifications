import json
import re
import string
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
from rank_bm25 import BM25Okapi
from stop_words import get_stop_words


class SimilarityCalculator:
    """
    Lightweight utility class for calculating similarity between text chunks.
    Designed to run efficiently in AWS Lambda.
    """

    def __init__(
        self,
        bm25_weight: float = 0.7,
        vector_weight: float = 0.3,
        bm25_factor: float = 1.0,
    ):
        """
        Initialize the SimilarityCalculator with weights for different similarity methods.

        Args:
            bm25_weight: Weight for BM25 similarity (0.0-1.0)
            vector_weight: Weight for vector similarity (0.0-1.0)
            bm25_factor: Factor to boost BM25 scores (values > 1.0 increase BM25 influence)
        """
        self.bm25_weight = bm25_weight
        self.vector_weight = vector_weight
        self.bm25_factor = bm25_factor
        self.stop_words = set(get_stop_words("en"))

    def preprocess_text(self, text: str) -> List[str]:
        """
        Lightweight text preprocessing for BM25 calculation.

        Args:
            text: Input text

        Returns:
            List[str]: List of preprocessed tokens
        """
        # Convert to lowercase
        text = text.lower()

        # Remove punctuation
        text = re.sub(f"[{re.escape(string.punctuation)}]", " ", text)

        # Simple tokenization by splitting on whitespace
        tokens = text.split()

        # Remove stopwords (no stemming)
        tokens = [token for token in tokens if token not in self.stop_words]

        return tokens

    def calculate_vector_similarity(
        self, query_vector: List[float], chunk_vectors: List[List[float]]
    ) -> List[float]:
        """
        Calculate vector similarity (cosine) between query and chunks.

        Args:
            query_vector: Query embedding vector
            chunk_vectors: List of chunk embedding vectors

        Returns:
            List[float]: List of similarity scores (0.0-1.0)
        """
        # Convert to numpy arrays
        query_array = np.array(query_vector)
        chunk_arrays = np.array(chunk_vectors)

        # Normalize vectors
        query_norm = np.linalg.norm(query_array)
        if query_norm == 0:
            query_array = query_array
        else:
            query_array = query_array / query_norm

        chunk_norms = np.linalg.norm(chunk_arrays, axis=1, keepdims=True)
        chunk_norms[chunk_norms == 0] = 1.0  # Avoid division by zero
        chunk_arrays = chunk_arrays / chunk_norms

        # Calculate cosine similarity
        similarities = np.dot(chunk_arrays, query_array)

        # Return as list and ensure scores are between 0 and 1
        return np.clip(similarities, 0, 1).tolist()

    def calculate_bm25_similarity(
        self, query: str, chunk_texts: List[str]
    ) -> List[float]:
        """
        Calculate BM25 similarity between query and chunks.

        Args:
            query: Query text
            chunk_texts: List of chunk texts

        Returns:
            List[float]: List of similarity scores (0.0-1.0)
        """
        # Preprocess query and chunks
        processed_query = self.preprocess_text(query)
        processed_chunks = [self.preprocess_text(chunk) for chunk in chunk_texts]

        # Handle empty chunks case
        if not processed_chunks or all(len(chunk) == 0 for chunk in processed_chunks):
            return [0.0] * len(chunk_texts)

        # Create BM25 model
        bm25 = BM25Okapi(processed_chunks)

        # Calculate scores
        scores = bm25.get_scores(processed_query)

        # Normalize scores to 0-1 range
        max_score = max(scores) if scores and max(scores) > 0 else 1.0
        normalized_scores = [score / max_score for score in scores]

        return normalized_scores

    def calculate_hybrid_similarity(
        self, query: str, query_vector: List[float], chunks: List[Dict[str, Any]]
    ) -> List[Tuple[Dict[str, Any], float]]:
        """
        Calculate hybrid similarity (BM25 + vector) between query and chunks.

        Args:
            query: Query text
            query_vector: Query embedding vector
            chunks: List of chunks with embedding vectors

        Returns:
            List[Tuple[Dict[str, Any], float]]: List of (chunk, score) pairs
        """
        # Extract texts and embeddings
        chunk_texts = [chunk.get("text", "") for chunk in chunks]
        chunk_vectors = [chunk.get("embedding", []) for chunk in chunks]

        # Calculate individual similarities
        bm25_scores = self.calculate_bm25_similarity(query, chunk_texts)
        vector_scores = self.calculate_vector_similarity(query_vector, chunk_vectors)

        # Combine scores
        combined_scores = []
        for i, chunk in enumerate(chunks):
            bm25_score = bm25_scores[i] if i < len(bm25_scores) else 0.0
            vector_score = vector_scores[i] if i < len(vector_scores) else 0.0

            # Apply BM25 boosting factor
            boosted_bm25_score = min(1.0, bm25_score * self.bm25_factor)

            # Weighted combination with boosted BM25 score
            combined_score = (self.bm25_weight * boosted_bm25_score) + (
                self.vector_weight * vector_score
            )

            # Store both raw and boosted scores for debugging and tuning
            chunk_with_scores = chunk.copy()
            chunk_with_scores["_debug_bm25_raw"] = bm25_score
            chunk_with_scores["_debug_bm25_boosted"] = boosted_bm25_score
            chunk_with_scores["_debug_vector"] = vector_score

            combined_scores.append((chunk_with_scores, combined_score))

        # Sort by score in descending order
        combined_scores.sort(key=lambda x: x[1], reverse=True)

        return combined_scores

    def get_top_k_chunks(
        self,
        query: str,
        query_vector: List[float],
        chunks: List[Dict[str, Any]],
        k: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        Get top K chunks based on hybrid similarity.

        Args:
            query: Query text
            query_vector: Query embedding vector
            chunks: List of chunks with embedding vectors
            k: Number of top chunks to return

        Returns:
            List[Dict[str, Any]]: List of top K chunks with relevance scores
        """
        # Calculate hybrid similarity
        scored_chunks = self.calculate_hybrid_similarity(query, query_vector, chunks)

        # Get top K
        top_k = scored_chunks[:k] if k < len(scored_chunks) else scored_chunks

        # Add relevance scores to chunks
        result = []
        for chunk, score in top_k:
            chunk_with_score = chunk.copy()
            chunk_with_score["relevance_score"] = score
            result.append(chunk_with_score)

        return result

    def get_per_file_top_k(
        self,
        query: str,
        query_vector: List[float],
        chunks: List[Dict[str, Any]],
        k: int = 5,
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Get top K chunks per file.

        Args:
            query: Query text
            query_vector: Query embedding vector
            chunks: List of chunks with embedding vectors
            k: Number of top chunks to return per file

        Returns:
            Dict[str, List[Dict[str, Any]]]: Dictionary mapping document IDs to lists of top K chunks
        """
        # Group chunks by document ID
        chunks_by_doc = defaultdict(list)
        for chunk in chunks:
            doc_id = chunk.get("document_id")
            if doc_id:
                chunks_by_doc[doc_id].append(chunk)

        # Get top K for each document
        result = {}
        for doc_id, doc_chunks in chunks_by_doc.items():
            result[doc_id] = self.get_top_k_chunks(query, query_vector, doc_chunks, k)

        return result

    def create_context_object(
        self,
        job_id: str,
        bank_id: str,
        query: str,
        query_vector: List[float],
        chunks: List[Dict[str, Any]],
        top_k: int = 10,
        per_file_k: int = 5,
    ) -> Dict[str, Any]:
        """
        Create a complete context object with overall and per-file top chunks.

        Args:
            job_id: Job ID
            bank_id: Bank ID
            query: Query text
            query_vector: Query embedding vector
            chunks: List of chunks with embedding vectors
            top_k: Number of overall top chunks to include
            per_file_k: Number of top chunks to include per file

        Returns:
            Dict[str, Any]: Context object
        """
        # Get overall top K
        overall_top_k = self.get_top_k_chunks(query, query_vector, chunks, top_k)

        # Get per-file top K
        per_file_top_k = self.get_per_file_top_k(
            query, query_vector, chunks, per_file_k
        )

        # Collect document IDs
        document_ids = list(
            set(
                [
                    chunk.get("document_id")
                    for chunk in chunks
                    if chunk.get("document_id")
                ]
            )
        )

        # Create context items
        context_items = []
        for chunk in overall_top_k:
            context_items.append(
                {
                    "chunk_id": chunk.get("chunk_id"),
                    "document_id": chunk.get("document_id"),
                    "text": chunk.get("text", ""),
                    "source_page": chunk.get("page_info"),
                    "relevance_score": chunk.get("relevance_score", 0.0),
                    "headings": chunk.get("headings", []),
                }
            )

        # Create context object
        context_object = {
            "job_id": job_id,
            "bank_id": bank_id,
            "document_ids": document_ids,
            "items": context_items,
            "per_file_items": {},
        }

        # Add per-file items
        for doc_id, doc_chunks in per_file_top_k.items():
            per_file_items = []
            for chunk in doc_chunks:
                per_file_items.append(
                    {
                        "chunk_id": chunk.get("chunk_id"),
                        "document_id": chunk.get("document_id"),
                        "text": chunk.get("text", ""),
                        "source_page": chunk.get("page_info"),
                        "relevance_score": chunk.get("relevance_score", 0.0),
                        "headings": chunk.get("headings", []),
                    }
                )
            context_object["per_file_items"][doc_id] = per_file_items

        return context_object
