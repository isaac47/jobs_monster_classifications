import json
import os

# Import the module to test
import sys
from datetime import datetime, timezone
from unittest.mock import MagicMock, Mock, patch

import boto3
import pytest
from moto import mock_dynamodb, mock_sqs

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.analyze_status_checker import AnalyzeStatusChecker
from retrieval_processor import (
    generate_kpi_specific_queries,
    get_chunks_for_file,
    get_embedding_for_text,
    get_prompt_template,
    handler,
    notify_kpi_generation_queue,
    parse_sqs_message,
    process_message,
    retrieve_relevant_context_per_kpi,
    store_retrieval_context,
    update_file_status,
)


class TestRetrievalProcessor:
    """Test suite for the Retrieval Processor Lambda function."""

    @pytest.fixture
    def sample_sqs_event(self):
        """Sample SQS event for testing."""
        return {
            "Records": [
                {
                    "messageId": "test-message-id",
                    "receiptHandle": "test-receipt-handle",
                    "body": json.dumps(
                        {
                            "file_id": "test-file-123",
                            "analyze_id": "test-analyze-456",
                            "stage": "retrieval",
                            "timestamp": "2023-09-15T13:10:00.000Z",
                        }
                    ),
                    "eventSource": "aws:sqs",
                }
            ]
        }

    @pytest.fixture
    def sample_chunks_with_embeddings(self):
        """Sample chunks with embeddings for testing."""
        return [
            {
                "chunk_id": "chunk-001",
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456",
                "text": "Total revenue for Q3 2023 was $1.2 billion, representing a 15% increase year-over-year",
                "text_to_embed": "Financial Results: Total revenue for Q3 2023 was $1.2 billion",
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5] * 307,  # 1535 dimensions
                "embedding_model": "amazon.titan-embed-text-v1",
                "page_info": {"page": 1, "section": "Financial Summary"},
                "headings": ["Financial Results", "Revenue"],
                "created_at": "2023-09-15T12:00:00.000Z",
            },
            {
                "chunk_id": "chunk-002",
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456",
                "text": "Net income increased by 12% to $250 million in Q3 2023",
                "text_to_embed": "Financial Results: Net income increased by 12% to $250 million",
                "embedding": [0.5, 0.4, 0.3, 0.2, 0.1] * 307,
                "embedding_model": "amazon.titan-embed-text-v1",
                "page_info": {"page": 2, "section": "Income Statement"},
                "headings": ["Financial Results", "Net Income"],
                "created_at": "2023-09-15T12:00:00.000Z",
            },
            {
                "chunk_id": "chunk-003",
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456",
                "text": "Earnings per share (EPS) was $2.15, up from $1.95 in the previous quarter",
                "text_to_embed": "Financial Results: Earnings per share (EPS) was $2.15",
                "embedding": [0.3, 0.1, 0.4, 0.2, 0.5] * 307,
                "embedding_model": "amazon.titan-embed-text-v1",
                "page_info": {"page": 2, "section": "Per Share Data"},
                "headings": ["Financial Results", "Earnings Per Share"],
                "created_at": "2023-09-15T12:00:00.000Z",
            },
        ]

    @pytest.fixture
    def sample_kpi_list(self):
        """Sample KPI list for testing."""
        return ["revenue", "net_income", "eps", "operating_margin"]

    @pytest.fixture
    def sample_kpi_taxonomy(self):
        """Sample KPI taxonomy for testing."""
        return {
            "revenue": {
                "category": "financial",
                "subcategory": "income_statement",
                "priority": "high",
                "synonyms": ["total revenue", "net sales", "turnover"],
                "detail_level": "quarterly",
            },
            "net_income": {
                "category": "financial",
                "subcategory": "income_statement",
                "priority": "high",
                "synonyms": ["net profit", "earnings", "profit after tax"],
                "detail_level": "quarterly",
            },
            "eps": {
                "category": "financial",
                "subcategory": "per_share",
                "priority": "medium",
                "synonyms": ["earnings per share", "diluted eps", "basic eps"],
                "detail_level": "quarterly",
            },
            "operating_margin": {
                "category": "financial",
                "subcategory": "margins",
                "priority": "medium",
                "synonyms": ["operating profit margin", "EBIT margin"],
                "detail_level": "quarterly",
            },
        }

    @pytest.fixture
    def sample_analyze_params(self, sample_kpi_list, sample_kpi_taxonomy):
        """Sample analyze parameters."""
        return {
            "analyze_id": "test-analyze-456",
            "kpi_list": sample_kpi_list,
            "kpi_taxonomy": sample_kpi_taxonomy,
            "bank_id": "test-bank-123",
            "bank_is_french": False,
            "detail_level": "quarterly",
            "total_files": 3,
            "file_categories": ["annual_report", "quarterly_report"],
            "status": "processing",
        }

    def test_parse_sqs_message_valid(self, sample_sqs_event):
        """Test parsing valid SQS messages."""
        messages = parse_sqs_message(sample_sqs_event)

        assert len(messages) == 1
        assert messages[0]["message"]["file_id"] == "test-file-123"
        assert messages[0]["message"]["analyze_id"] == "test-analyze-456"
        assert messages[0]["receipt_handle"] == "test-receipt-handle"

    @mock_dynamodb
    def test_update_file_status_success(self):
        """Test successful file status update."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_FILE_STATUS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Insert initial record
        table.put_item(
            Item={
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456",
                "status": "embedding_complete",
                "created_at": "2023-09-15T12:00:00.000Z",
            }
        )

        # Test update
        success = update_file_status(
            "test-file-123",
            "test-analyze-456",
            "retrieval_processing",
            {"retrieval_model": "hybrid_search"},
        )

        assert success is True

        # Verify update
        response = table.get_item(
            Key={"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        )

        assert response["Item"]["status"] == "retrieval_processing"
        assert "retrieval_model" in response["Item"]

    @mock_dynamodb
    def test_get_chunks_for_file_with_embeddings(self, sample_chunks_with_embeddings):
        """Test successful chunk retrieval with embeddings."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "chunk_id", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "chunk_id", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Insert test chunks with embeddings
        for chunk in sample_chunks_with_embeddings:
            table.put_item(Item=chunk)

        # Insert a chunk without embedding (should be filtered out)
        table.put_item(
            Item={
                "chunk_id": "chunk-no-embedding",
                "file_id": "test-file-123",
                "text": "This chunk has no embedding",
            }
        )

        # Test retrieval
        chunks = get_chunks_for_file("test-file-123")

        assert len(chunks) == 3  # Only chunks with embeddings
        for chunk in chunks:
            assert "embedding" in chunk
            assert chunk["embedding"] is not None

    @mock_dynamodb
    def test_get_prompt_template_hierarchy(self):
        """Test prompt template retrieval hierarchy."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.PROMPT_STORE_TABLE,
            KeySchema=[
                {"AttributeName": "bank_id", "KeyType": "HASH"},
                {"AttributeName": "document_category", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "bank_id", "AttributeType": "S"},
                {"AttributeName": "document_category", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Insert test prompts
        table.put_item(
            Item={
                "bank_id": "test-bank-123",
                "document_category": "annual_report",
                "prompt_template": "Bank-specific annual report prompt",
            }
        )

        table.put_item(
            Item={
                "bank_id": "test-bank-123",
                "document_category": "default",
                "prompt_template": "Bank default prompt",
            }
        )

        table.put_item(
            Item={
                "bank_id": "default",
                "document_category": "annual_report",
                "prompt_template": "Category default prompt",
            }
        )

        table.put_item(
            Item={
                "bank_id": "default",
                "document_category": "default",
                "prompt_template": "Global default prompt",
            }
        )

        # Test specific bank + category
        prompt = get_prompt_template("test-bank-123", "annual_report")
        assert prompt == "Bank-specific annual report prompt"

        # Test bank default
        prompt = get_prompt_template("test-bank-123", "quarterly_report")
        assert prompt == "Bank default prompt"

        # Test category default
        prompt = get_prompt_template("other-bank", "annual_report")
        assert prompt == "Category default prompt"

        # Test global default
        prompt = get_prompt_template("other-bank", "quarterly_report")
        assert prompt == "Global default prompt"

    def test_generate_kpi_specific_queries(self, sample_kpi_list, sample_kpi_taxonomy):
        """Test KPI-specific query generation."""
        base_prompt = "Extract financial information from documents"

        queries = generate_kpi_specific_queries(
            sample_kpi_list, sample_kpi_taxonomy, base_prompt
        )

        assert len(queries) == len(sample_kpi_list)

        # Test revenue query
        revenue_query = next(q for q in queries if q["kpi"] == "revenue")
        assert "total revenue" in revenue_query["query"]
        assert "net sales" in revenue_query["query"]
        assert revenue_query["priority"] == "high"
        assert "financial" in revenue_query["category"]

        # Test EPS query
        eps_query = next(q for q in queries if q["kpi"] == "eps")
        assert "earnings per share" in eps_query["query"]
        assert eps_query["priority"] == "medium"

    def test_generate_kpi_specific_queries_minimal_taxonomy(self):
        """Test query generation with minimal taxonomy."""
        kpi_list = ["unknown_kpi"]
        taxonomy = {}

        queries = generate_kpi_specific_queries(kpi_list, taxonomy, "base prompt")

        assert len(queries) == 1
        assert queries[0]["kpi"] == "unknown_kpi"
        assert "Extract unknown_kpi" in queries[0]["query"]
        assert queries[0]["priority"] == "medium"  # Default

    @patch("boto3.client")
    def test_get_embedding_for_text_success(self, mock_boto_client):
        """Test successful embedding generation for text."""
        # Mock Bedrock client
        mock_bedrock = Mock()
        mock_boto_client.return_value = mock_bedrock

        mock_response = Mock()
        sample_embedding = [0.1, 0.2, 0.3, 0.4, 0.5] * 307
        mock_response.get.return_value.read.return_value = json.dumps(
            {"embedding": sample_embedding}
        ).encode()
        mock_bedrock.invoke_model.return_value = mock_response

        # Test embedding generation
        text = "Extract revenue from financial documents"
        embedding = get_embedding_for_text(text, "amazon.titan-embed-text-v1")

        assert embedding is not None
        assert len(embedding) == len(sample_embedding)
        assert embedding == sample_embedding

    @patch("boto3.client")
    def test_get_embedding_for_text_failure(self, mock_boto_client):
        """Test embedding generation failure."""
        # Mock Bedrock client that raises an exception
        mock_bedrock = Mock()
        mock_boto_client.return_value = mock_bedrock
        mock_bedrock.invoke_model.side_effect = Exception("Bedrock API error")

        # Test embedding generation failure
        text = "Test text"
        embedding = get_embedding_for_text(text, "amazon.titan-embed-text-v1")

        assert embedding is None

    @patch("retrieval_processor.get_embedding_for_text")
    def test_retrieve_relevant_context_per_kpi(
        self,
        mock_get_embedding,
        sample_chunks_with_embeddings,
        sample_kpi_list,
        sample_kpi_taxonomy,
    ):
        """Test KPI-specific context retrieval."""
        # Mock embedding generation
        mock_get_embedding.return_value = [0.2, 0.3, 0.4, 0.1, 0.5] * 307

        # Generate queries
        base_prompt = "Extract financial information"
        kpi_queries = generate_kpi_specific_queries(
            sample_kpi_list, sample_kpi_taxonomy, base_prompt
        )

        # Test context retrieval
        context = retrieve_relevant_context_per_kpi(
            kpi_queries,
            sample_chunks_with_embeddings,
            "amazon.titan-embed-text-v1",
            top_k=2,
        )

        # Verify structure
        assert "kpi_specific_context" in context
        assert "overall_context" in context
        assert "statistics" in context

        # Verify KPI-specific contexts
        kpi_context = context["kpi_specific_context"]
        assert len(kpi_context) == len(sample_kpi_list)

        for kpi in sample_kpi_list:
            assert kpi in kpi_context
            assert "query" in kpi_context[kpi]
            assert "chunks" in kpi_context[kpi]
            assert "priority" in kpi_context[kpi]

        # Verify statistics
        stats = context["statistics"]
        assert stats["total_kpis"] == len(sample_kpi_list)
        assert stats["model_used"] == "amazon.titan-embed-text-v1"

    @mock_dynamodb
    def test_store_retrieval_context_success(self):
        """Test successful context storage."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_RETRIEVAL_CONTEXT_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Test context storage
        context = {
            "kpi_specific_context": {"revenue": {"query": "test", "chunks": []}},
            "statistics": {"total_kpis": 1},
        }

        success = store_retrieval_context("test-file-123", "test-analyze-456", context)
        assert success is True

        # Verify storage
        response = table.get_item(
            Key={"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        )

        assert "Item" in response
        assert response["Item"]["context_type"] == "kpi_retrieval"
        assert "context" in response["Item"]

    @mock_sqs
    def test_notify_kpi_generation_queue_success(self):
        """Test successful notification to KPI generation queue."""
        # Setup mock SQS
        sqs = boto3.client("sqs", region_name="us-east-1")
        queue_url = sqs.create_queue(QueueName=EnvVars.KPI_GENERATION_QUEUE_NAME)[
            "QueueUrl"
        ]

        # Test notification
        message = {"file_id": "test-file-123", "analyze_id": "test-analyze-456"}

        context_stats = {"total_kpis": 4, "total_unique_chunks": 3}

        success = notify_kpi_generation_queue(message, context_stats)
        assert success is True

    @patch("retrieval_processor.AnalyzeStatusChecker.check_analyze_status")
    @patch("retrieval_processor.AnalyzeStatusChecker.get_analyze_parameters")
    @patch("retrieval_processor.update_file_status")
    @patch("retrieval_processor.get_item")
    @patch("retrieval_processor.get_prompt_template")
    @patch("retrieval_processor.get_chunks_for_file")
    @patch("retrieval_processor.generate_kpi_specific_queries")
    @patch("retrieval_processor.retrieve_relevant_context_per_kpi")
    @patch("retrieval_processor.store_retrieval_context")
    @patch("retrieval_processor.notify_kpi_generation_queue")
    def test_process_message_success(
        self,
        mock_notify,
        mock_store_context,
        mock_retrieve_context,
        mock_generate_queries,
        mock_get_chunks,
        mock_get_prompt,
        mock_get_item,
        mock_update_status,
        mock_get_params,
        mock_check_status,
        sample_analyze_params,
        sample_chunks_with_embeddings,
        sample_kpi_list,
        sample_kpi_taxonomy,
    ):
        """Test successful message processing."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_get_params.return_value = sample_analyze_params
        mock_update_status.return_value = True
        mock_get_item.return_value = {"file_category": "annual_report"}
        mock_get_prompt.return_value = "Extract financial KPIs from the document"
        mock_get_chunks.return_value = sample_chunks_with_embeddings

        # Mock query generation
        mock_queries = [
            {
                "kpi": "revenue",
                "query": "Extract revenue",
                "priority": "high",
                "category": "financial",
                "synonyms": [],
            },
            {
                "kpi": "net_income",
                "query": "Extract net income",
                "priority": "high",
                "category": "financial",
                "synonyms": [],
            },
        ]
        mock_generate_queries.return_value = mock_queries

        # Mock context retrieval
        mock_context = {
            "kpi_specific_context": {
                "revenue": {"chunks": []},
                "net_income": {"chunks": []},
            },
            "statistics": {"total_kpis": 2, "total_unique_chunks": 3},
        }
        mock_retrieve_context.return_value = mock_context
        mock_store_context.return_value = True
        mock_notify.return_value = True

        # Test message processing
        message_data = {
            "message": {"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        }

        success = process_message(message_data)
        assert success is True

        # Verify all functions were called
        mock_check_status.assert_called_once()
        mock_get_params.assert_called_once()
        mock_update_status.assert_called()
        mock_get_chunks.assert_called_once()
        mock_generate_queries.assert_called_once()
        mock_retrieve_context.assert_called_once()
        mock_store_context.assert_called_once()
        mock_notify.assert_called_once()

    @patch("retrieval_processor.AnalyzeStatusChecker.check_analyze_status")
    def test_process_message_analyze_failed(self, mock_check_status):
        """Test message processing when analyze has failed."""
        # Setup mock to return failed status
        mock_check_status.return_value = (False, None)

        # Test message processing
        message_data = {
            "message": {"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        }

        success = process_message(message_data)
        assert success is True  # Should return True to avoid reprocessing

    @patch("retrieval_processor.AnalyzeStatusChecker.check_analyze_status")
    @patch("retrieval_processor.AnalyzeStatusChecker.get_analyze_parameters")
    @patch("retrieval_processor.update_file_status")
    def test_process_message_no_kpis(
        self, mock_update_status, mock_get_params, mock_check_status
    ):
        """Test message processing when no KPIs are specified."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_get_params.return_value = {
            "analyze_id": "test-analyze-456",
            "kpi_list": [],  # No KPIs
            "kpi_taxonomy": {},
            "bank_id": "test-bank",
            "bank_is_french": False,
        }
        mock_update_status.return_value = True

        # Test message processing
        message_data = {
            "message": {"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        }

        success = process_message(message_data)
        assert success is False

    @patch("retrieval_processor.AnalyzeStatusChecker.check_analyze_status")
    @patch("retrieval_processor.AnalyzeStatusChecker.get_analyze_parameters")
    @patch("retrieval_processor.update_file_status")
    @patch("retrieval_processor.get_item")
    @patch("retrieval_processor.get_prompt_template")
    @patch("retrieval_processor.get_chunks_for_file")
    def test_process_message_no_chunks(
        self,
        mock_get_chunks,
        mock_get_prompt,
        mock_get_item,
        mock_update_status,
        mock_get_params,
        mock_check_status,
        sample_analyze_params,
    ):
        """Test message processing when no embedded chunks are found."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_get_params.return_value = sample_analyze_params
        mock_update_status.return_value = True
        mock_get_item.return_value = {"file_category": "annual_report"}
        mock_get_prompt.return_value = "Test prompt"
        mock_get_chunks.return_value = []  # No chunks

        # Test message processing
        message_data = {
            "message": {"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        }

        success = process_message(message_data)
        assert success is False

    def test_process_message_missing_fields(self):
        """Test message processing with missing required fields."""
        # Test with missing file_id
        message_data = {"message": {"analyze_id": "test-analyze-456"}}

        success = process_message(message_data)
        assert success is False

        # Test with missing analyze_id
        message_data = {"message": {"file_id": "test-file-123"}}

        success = process_message(message_data)
        assert success is False

    @patch("retrieval_processor.parse_sqs_message")
    @patch("retrieval_processor.process_message")
    def test_handler_success(self, mock_process, mock_parse, sample_sqs_event):
        """Test successful Lambda handler execution."""
        # Setup mocks
        mock_parse.return_value = [
            {"message": {"file_id": "test-file-123", "analyze_id": "test-analyze-456"}}
        ]
        mock_process.return_value = True

        # Test handler
        response = handler(sample_sqs_event, None)

        assert response["statusCode"] == 200
        response_body = json.loads(response["body"])
        assert response_body["message"] == "Retrieval processing completed"
        assert len(response_body["results"]) == 1
        assert response_body["results"][0]["success"] is True

    @patch("retrieval_processor.parse_sqs_message")
    def test_handler_no_messages(self, mock_parse, sample_sqs_event):
        """Test handler with no valid messages."""
        # Setup mock to return no messages
        mock_parse.return_value = []

        # Test handler
        response = handler(sample_sqs_event, None)

        assert response["statusCode"] == 200
        response_body = json.loads(response["body"])
        assert response_body["message"] == "No valid messages found"

    def test_french_bank_embedding_model_selection(self):
        """Test that French banks use the correct embedding model."""
        # Test French bank
        french_model = EnvVars.get_embedding_model(bank_is_french=True)
        assert french_model == EnvVars.BEDROCK_EMBEDDING_MODEL_FR

        # Test non-French bank
        english_model = EnvVars.get_embedding_model(bank_is_french=False)
        assert english_model == EnvVars.BEDROCK_EMBEDDING_MODEL_EN


class TestRetrievalProcessorIntegration:
    """Integration tests for the Retrieval Processor."""

    @mock_dynamodb
    @mock_sqs
    @patch("boto3.client")
    def test_end_to_end_retrieval_processing(
        self,
        mock_boto_client,
        sample_sqs_event,
        sample_chunks_with_embeddings,
        sample_analyze_params,
        sample_kpi_list,
        sample_kpi_taxonomy,
    ):
        """Test end-to-end retrieval processing flow."""
        # Setup DynamoDB tables
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")

        # Create analyze status table
        analyze_table = dynamodb.create_table(
            TableName=EnvVars.KPI_ANALYZE_STATUS_TABLE,
            KeySchema=[{"AttributeName": "analyze_id", "KeyType": "HASH"}],
            AttributeDefinitions=[
                {"AttributeName": "analyze_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Create file status table
        file_table = dynamodb.create_table(
            TableName=EnvVars.KPI_FILE_STATUS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Create chunks table
        chunks_table = dynamodb.create_table(
            TableName=EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "chunk_id", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "chunk_id", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Create prompt store table
        prompt_table = dynamodb.create_table(
            TableName=EnvVars.PROMPT_STORE_TABLE,
            KeySchema=[
                {"AttributeName": "bank_id", "KeyType": "HASH"},
                {"AttributeName": "document_category", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "bank_id", "AttributeType": "S"},
                {"AttributeName": "document_category", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Create retrieval context table
        context_table = dynamodb.create_table(
            TableName=EnvVars.KPI_RETRIEVAL_CONTEXT_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Setup SQS
        sqs = boto3.client("sqs", region_name="us-east-1")
        sqs.create_queue(QueueName=EnvVars.KPI_GENERATION_QUEUE_NAME)

        # Insert test data
        analyze_table.put_item(Item=sample_analyze_params)

        file_table.put_item(
            Item={
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456",
                "status": "embedding_complete",
                "file_category": "annual_report",
            }
        )

        for chunk in sample_chunks_with_embeddings:
            chunks_table.put_item(Item=chunk)

        prompt_table.put_item(
            Item={
                "bank_id": "test-bank-123",
                "document_category": "annual_report",
                "prompt_template": "Extract key financial KPIs from the annual report",
            }
        )

        # Mock Bedrock client for query embeddings
        mock_bedrock = Mock()
        mock_boto_client.return_value = mock_bedrock

        # Mock response for query embeddings
        mock_response = Mock()
        query_embedding = [0.2, 0.3, 0.4, 0.1, 0.5] * 307
        mock_response.get.return_value.read.return_value = json.dumps(
            {"embedding": query_embedding}
        ).encode()
        mock_bedrock.invoke_model.return_value = mock_response

        # Process the event
        response = handler(sample_sqs_event, None)

        # Verify success
        assert response["statusCode"] == 200
        response_body = json.loads(response["body"])
        assert response_body["results"][0]["success"] is True

        # Verify retrieval context was stored
        context_item = context_table.get_item(
            Key={"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        )["Item"]

        assert context_item["context_type"] == "kpi_retrieval"
        assert "context" in context_item

        # Verify context structure
        context = context_item["context"]
        assert "kpi_specific_context" in context
        assert "overall_context" in context
        assert "statistics" in context

        # Verify file status was updated
        updated_file = file_table.get_item(
            Key={"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        )["Item"]

        assert updated_file["status"] == "retrieval_complete"

    @mock_dynamodb
    def test_hybrid_search_functionality(self, sample_chunks_with_embeddings):
        """Test hybrid search functionality with real similarity calculation."""
        from common.utils.similarity_calculator import SimilarityCalculator

        # Test hybrid search
        calculator = SimilarityCalculator(
            bm25_weight=0.3, vector_weight=0.7, bm25_factor=1.0
        )

        query = "What is the total revenue for Q3 2023?"
        query_vector = [0.15, 0.25, 0.35, 0.3, 0.4] * 307  # Mock query embedding

        top_chunks = calculator.get_top_k_chunks(
            query, query_vector, sample_chunks_with_embeddings, k=2
        )

        assert len(top_chunks) <= 2
        assert all("relevance_score" in chunk for chunk in top_chunks)

        # Verify chunks are sorted by relevance
        if len(top_chunks) > 1:
            assert top_chunks[0]["relevance_score"] >= top_chunks[1]["relevance_score"]


class TestRetrievalProcessorErrorHandling:
    """Test error handling scenarios."""

    @patch("retrieval_processor.AnalyzeStatusChecker.check_analyze_status")
    @patch("retrieval_processor.update_file_status")
    def test_status_update_failure_handling(
        self, mock_update_status, mock_check_status
    ):
        """Test handling when status update fails."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_update_status.return_value = False  # Status update fails

        # Test message processing
        message_data = {
            "message": {"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        }

        success = process_message(message_data)
        assert success is False

    @patch("retrieval_processor.AnalyzeStatusChecker.check_analyze_status")
    @patch("retrieval_processor.AnalyzeStatusChecker.get_analyze_parameters")
    @patch("retrieval_processor.update_file_status")
    def test_analyze_parameters_failure_handling(
        self, mock_update_status, mock_get_params, mock_check_status
    ):
        """Test handling when analyze parameters retrieval fails."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_get_params.return_value = None  # Parameters retrieval fails
        mock_update_status.return_value = True

        # Test message processing
        message_data = {
            "message": {"file_id": "test-file-123", "analyze_id": "test-analyze-456"}
        }

        success = process_message(message_data)
        assert success is False


# Test configuration and fixtures
@pytest.fixture(scope="session", autouse=True)
def setup_test_environment():
    """Setup test environment variables."""
    import os

    os.environ.update(
        {
            "KPI_ANALYZE_STATUS_TABLE": "test-kpi-analyze-status",
            "KPI_FILE_STATUS_TABLE": "test-kpi-file-status",
            "KPI_DOCUMENT_CHUNKS_TABLE": "test-kpi-document-chunks",
            "KPI_RETRIEVAL_CONTEXT_TABLE": "test-kpi-retrieval-context",
            "PROMPT_STORE_TABLE": "test-prompt-store",
            "KPI_GENERATION_QUEUE_NAME": "test-kpi-generation-queue",
            "BEDROCK_REGION": "us-east-1",
            "BEDROCK_EMBEDDING_MODEL_EN": "amazon.titan-embed-text-v1",
            "BEDROCK_EMBEDDING_MODEL_FR": "amazon.titan-embed-text-v2",
            "TOP_K_CHUNKS": "10",
            "PER_KPI_TOP_K": "5",
            "BM25_WEIGHT": "0.3",
            "VECTOR_WEIGHT": "0.7",
            "BM25_FACTOR": "1.0",
            "LOG_LEVEL": "INFO",
        }
    )


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v", "--tb=short"])
