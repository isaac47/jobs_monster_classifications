import json
import pytest
import boto3
from moto import mock_dynamodb, mock_sqs
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime, timezone

# Import the module to test
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from kpi_response_generator import (
    parse_sqs_message,
    update_file_status,
    get_retrieval_context,
    get_prompt_template_for_kpi_extraction,
    construct_kpi_extraction_prompt,
    call_bedrock_llm,
    parse_and_validate_llm_response,
    store_kpi_response,
    process_message,
    handler
)

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.analyze_status_checker import AnalyzeStatusChecker


class TestKPIGenerator:
    """Test suite for the KPI Generator Lambda function."""

    @pytest.fixture
    def sample_sqs_event(self):
        """Sample SQS event for testing."""
        return {
            "Records": [
                {
                    "messageId": "test-message-id",
                    "receiptHandle": "test-receipt-handle",
                    "body": json.dumps({
                        "file_id": "test-file-123",
                        "analyze_id": "test-analyze-456",