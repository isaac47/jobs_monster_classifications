# FILE PATH: ./stage5/status_handler/lambda_function.py

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.dynamodb_utils import get_item, query_items
from common.utils.logger import get_logger
from common.utils.sqs_utils import get_queue_url, send_message

logger = get_logger(__name__)


def convert_dynamodb_value(value: Dict[str, Any]) -> Any:
    """Convert a single DynamoDB attribute value to Python value."""
    if "S" in value:
        return value["S"]
    elif "N" in value:
        try:
            num_str = value["N"]
            if "." in num_str:
                return float(num_str)
            else:
                return int(num_str)
        except ValueError:
            return value["N"]
    elif "BOOL" in value:
        return value["BOOL"]
    elif "NULL" in value:
        return None
    elif "L" in value:
        return [convert_dynamodb_value({"item": item}) for item in value["L"]]
    elif "M" in value:
        return convert_dynamodb_item(value["M"])
    elif "SS" in value:
        return value["SS"]
    elif "NS" in value:
        return [float(n) if "." in n else int(n) for n in value["NS"]]
    else:
        return value


def convert_dynamodb_item(item: Dict[str, Any]) -> Dict[str, Any]:
    """Convert a DynamoDB item to a regular Python dictionary."""
    if not item:
        return {}

    result = {}
    for key, value in item.items():
        try:
            result[key] = convert_dynamodb_value(value)
        except Exception as e:
            logger.warning(f"Error converting DynamoDB value for key {key}: {e}")
            result[key] = value

    return result


def parse_dynamodb_stream_event(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Parse DynamoDB stream event records."""
    records = []

    for record in event.get("Records", []):
        try:
            if record.get("eventSource") != "aws:dynamodb":
                logger.debug("Skipping non-DynamoDB event")
                continue

            event_name = record.get("eventName")
            if event_name not in ["INSERT", "MODIFY"]:
                logger.debug(f"Skipping event type: {event_name}")
                continue

            new_image = record.get("dynamodb", {}).get("NewImage", {})
            old_image = record.get("dynamodb", {}).get("OldImage", {})

            if not new_image:
                logger.warning("No NewImage found in DynamoDB stream record")
                continue

            new_record = convert_dynamodb_item(new_image)
            old_record = convert_dynamodb_item(old_image) if old_image else {}

            table_name = ""
            event_source_arn = record.get("eventSourceARN", "")
            if "/" in event_source_arn:
                table_name = event_source_arn.split("/")[1]

            records.append({
                "eventName": event_name,
                "newRecord": new_record,
                "oldRecord": old_record,
                "tableName": table_name,
                "eventSourceARN": event_source_arn,
            })

        except Exception as e:
            logger.error(f"Error parsing DynamoDB stream record: {e}")
            continue

    return records


def check_analyze_status(analyze_id: str) -> bool:
    """Critical Check: Query analyze_id status → If "failed", skip processing."""
    try:
        analyze_record = get_item(
            EnvVars.KPI_ANALYZE_STATUS_TABLE, {"analyze_id": analyze_id}
        )

        if not analyze_record:
            logger.error(f"Analyze record not found: {analyze_id}")
            return False

        status = analyze_record.get("status")
        if status == "failed":
            logger.info(f"Analyze already failed, skipping processing: {analyze_id}")
            return False

        return True

    except Exception as e:
        logger.error(f"Error checking analyze status for {analyze_id}: {e}")
        return False


def count_kpi_complete_files(analyze_id: str) -> int:
    """Count how many files have completed KPI processing for this analyze."""
    try:
        # Query files with kpi_complete status for this analyze_id
        completed_files = query_items(
            EnvVars.KPI_FILE_STATUS_TABLE,
            "analyze_id = :analyze_id AND #status = :status",
            {":analyze_id": analyze_id, ":status": "kpi_complete"},
            expression_attribute_names={"#status": "status"}
        )
        
        count = len(completed_files)
        logger.info(f"Found {count} files with kpi_complete status for analyze {analyze_id}")
        return count
        
    except Exception as e:
        logger.error(f"Error counting kpi_complete files for {analyze_id}: {e}")
        return 0


def get_total_expected_files(analyze_id: str) -> int:
    """Get total expected files for this analyze from analyze status table."""
    try:
        analyze_record = get_item(
            EnvVars.KPI_ANALYZE_STATUS_TABLE, {"analyze_id": analyze_id}
        )
        
        if analyze_record:
            total_files = analyze_record.get("total_files", 0)
            logger.info(f"Total expected files for analyze {analyze_id}: {total_files}")
            return total_files
        else:
            logger.error(f"Analyze record not found for {analyze_id}")
            return 0
            
    except Exception as e:
        logger.error(f"Error getting total expected files for {analyze_id}: {e}")
        return 0


def send_to_output_generation_queue(analyze_id: str) -> bool:
    """Send message to output generation queue when all files are complete."""
    try:
        queue_url = get_queue_url(EnvVars.OUTPUT_GENERATION_QUEUE_NAME)
        if not queue_url:
            logger.error(f"Output generation queue not found: {EnvVars.OUTPUT_GENERATION_QUEUE_NAME}")
            return False

        message = {
            "analyze_id": analyze_id,
            "stage": "output_generation",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_stage": "all_kpi_complete",
            "trigger": "kpi_completion_monitor"
        }

        message_id = send_message(queue_url, message)
        if message_id:
            logger.info(f"Sent analyze {analyze_id} to output generation queue: {message_id}")
            return True
        else:
            logger.error(f"Failed to send analyze {analyze_id} to output generation queue")
            return False

    except Exception as e:
        logger.error(f"Error sending to output generation queue: {e}")
        return False


def handle_kpi_complete_status(record: Dict[str, Any]) -> bool:
    """Handle file status changes to "kpi_complete"."""
    try:
        new_record = record["newRecord"]
        old_record = record["oldRecord"]

        file_id = new_record.get("file_id")
        analyze_id = new_record.get("analyze_id")
        new_status = new_record.get("status")
        old_status = old_record.get("status", "")

        if not file_id or not analyze_id:
            logger.warning("Missing file_id or analyze_id in record")
            return False

        # Only process files that just reached "kpi_complete"
        if new_status != "kpi_complete" or old_status == "kpi_complete":
            logger.debug(f"Status change not relevant: {old_status} -> {new_status}")
            return True

        logger.info(f"Processing kpi_complete for file {file_id}, analyze {analyze_id}")

        # Critical Check: Query analyze_id status → If "failed", skip processing and stop
        if not check_analyze_status(analyze_id):
            logger.info(f"Skipping processing for failed analyze: {analyze_id}")
            return True

        # Count how many KPI responses exist for this analyze_id
        kpi_complete_count = count_kpi_complete_files(analyze_id)
        
        # Get total expected document count for this analyze_id
        total_expected = get_total_expected_files(analyze_id)
        
        if total_expected == 0:
            logger.error(f"No expected files found for analyze {analyze_id}")
            return False
        
        logger.info(f"KPI completion progress for analyze {analyze_id}: {kpi_complete_count}/{total_expected}")

        # Completion Check
        if kpi_complete_count != total_expected:
            # Not all files completed yet, wait for more
            logger.info(f"Waiting for more files to complete KPI extraction: {kpi_complete_count}/{total_expected}")
            return True
        
        # All files completed KPI extraction!
        logger.info(f"🎉 All files completed KPI extraction for analyze {analyze_id}!")
        
        # Send notification to output generation queue
        if not send_to_output_generation_queue(analyze_id):
            logger.error(f"Failed to notify output generation queue for analyze {analyze_id}")
            return False

        logger.info(f"Successfully triggered output generation for analyze {analyze_id}")
        return True

    except Exception as e:
        logger.error(f"Error handling kpi_complete status: {e}")
        return False


def handle_file_status_change(record: Dict[str, Any]) -> bool:
    """Handle file status changes in the KPI pipeline."""
    try:
        return handle_kpi_complete_status(record)
    except Exception as e:
        logger.error(f"Error handling file status change: {e}")
        return False


def process_stream_record(record: Dict[str, Any]) -> bool:
    """Process a DynamoDB stream record."""
    try:
        table_name = record.get("tableName", "")

        # Only handle file status table changes
        if "kpi-file-status" in table_name:
            return handle_file_status_change(record)
        else:
            logger.debug(f"Ignoring event from table: {table_name}")
            return True

    except Exception as e:
        logger.error(f"Error processing stream record: {e}")
        return False


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for DynamoDB stream events - Stage 5 KPI Completion Monitor.

    Trigger: DynamoDB Stream on file status changes to "kpi_complete"
    Purpose: Monitor KPI completion and trigger final output when all files are done
    """
    logger.info(f"Received DynamoDB stream event for Stage 5 KPI completion monitoring")
    logger.debug(f"Event details: {json.dumps(event, default=str)}")

    try:
        records = parse_dynamodb_stream_event(event)
        if not records:
            logger.info("No valid DynamoDB records found")
            return {
                "statusCode": 200,
                "body": json.dumps({"message": "No valid DynamoDB records found"}),
            }

        logger.info(f"Processing {len(records)} DynamoDB stream records")

        results = []
        for record in records:
            try:
                success = process_stream_record(record)

                new_record = record.get("newRecord", {})
                result_info = {
                    "tableName": record.get("tableName", ""),
                    "eventName": record.get("eventName", ""),
                    "fileId": new_record.get("file_id"),
                    "analyzeId": new_record.get("analyze_id"),
                    "oldStatus": record.get("oldRecord", {}).get("status"),
                    "newStatus": new_record.get("status"),
                    "success": success,
                }

                results.append(result_info)

                if success:
                    logger.info(f"Successfully processed record: {result_info}")
                else:
                    logger.error(f"Failed to process record: {result_info}")

            except Exception as e:
                logger.error(f"Error processing individual record: {e}")
                results.append({
                    "tableName": record.get("tableName", ""),
                    "eventName": record.get("eventName", ""),
                    "error": str(e),
                    "success": False,
                })

        failed_count = sum(1 for result in results if not result["success"])
        success_count = len(results) - failed_count

        if failed_count > 0:
            logger.error(f"Failed to process {failed_count} out of {len(results)} records")
        else:
            logger.info(f"Successfully processed all {success_count} records")

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Stage 5 KPI completion monitoring completed",
                "results": results,
                "total_records": len(results),
                "success_count": success_count,
                "failed_count": failed_count,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }),
        }

    except Exception as e:
        error_msg = f"Critical error in Stage 5 KPI completion monitor: {str(e)}"
        logger.error(error_msg)
        logger.error(f"Event that caused error: {json.dumps(event, default=str)}")

        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Stage 5 KPI completion monitoring failed",
                "error": error_msg,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }),
        }


# For local testing
if __name__ == "__main__":
    # Test with sample DynamoDB stream event
    test_event = {
        "Records": [
            {
                "eventID": "test-event-id",
                "eventName": "MODIFY",
                "eventVersion": "1.1",
                "eventSource": "aws:dynamodb",
                "awsRegion": "eu-west-3",
                "eventSourceARN": "arn:aws:dynamodb:eu-west-3:123456789012:table/benchmark-kpi-file-status/stream/2023-12-01T00:00:00.000",
                "dynamodb": {
                    "ApproximateCreationDateTime": 1638360000.0,
                    "Keys": {"file_id": {"S": "test-file-123"}},
                    "NewImage": {
                        "file_id": {"S": "test-file-123"},
                        "analyze_id": {"S": "test-analyze-456"},
                        "status": {"S": "kpi_complete"},
                        "updated_at": {"S": "2023-12-01T10:00:00Z"},
                    },
                    "OldImage": {
                        "file_id": {"S": "test-file-123"},
                        "analyze_id": {"S": "test-analyze-456"},
                        "status": {"S": "kpi_processing"},
                        "updated_at": {"S": "2023-12-01T09:00:00Z"},
                    },
                    "SequenceNumber": "12345",
                    "SizeBytes": 123,
                    "StreamViewType": "NEW_AND_OLD_IMAGES",
                },
            }
        ]
    }

    class MockContext:
        def __init__(self):
            self.function_name = "test-kpi-completion-monitor"
            self.memory_limit_in_mb = 256

    context = MockContext()

    try:
        result = handler(test_event, context)
        print("Test result:")
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Test failed: {e}")
        import traceback
        traceback.print_exc()