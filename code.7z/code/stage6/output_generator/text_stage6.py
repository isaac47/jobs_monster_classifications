import json
import pytest
import boto3
from moto import mock_dynamodb, mock_s3, mock_sqs
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime, timezone

# Import the module to test
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from output_generator import (
    parse_sqs_message,
    get_all_kpi_responses,
    merge_kpi_extractions,
    resolve_duplicate_kpis,
    organize_results_by_file_category,
    calculate_processing_statistics,
    format_final_output_according_to_api_spec,
    store_output_in_s3,
    store_output_metadata,
    mark_analyze_as_complete,
    process_message,
    handler
)

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.analyze_status_checker import AnalyzeStatusChecker


class TestOutputGenerator:
    """Test suite for the Output Generator Lambda function."""

    @pytest.fixture
    def sample_sqs_event(self):
        """Sample SQS event for testing."""
        return {
            "Records": [
                {
                    "messageId": "test-message-id",
                    "receiptHandle": "test-receipt-handle",
                    "body": json.dumps({
                        "analyze_id": "test-analyze-456",
                        "stage": "output_generation",
                        "timestamp": "2023-09-15T13:30:00.000Z"
                    }),
                    "eventSource": "aws:sqs"
                }
            ]
        }

    @pytest.fixture
    def sample_kpi_responses(self):
        """Sample KPI responses for testing."""
        return [
            {
                "file_id": "file-001",
                "analyze_id": "test-analyze-456",
                "parsed_response": {
                    "kpi_extractions": [
                        {
                            "kpi_name": "revenue",
                            "value": "1.2 billion",
                            "unit": "$",
                            "period": "Q3 2023",
                            "confidence_score": 0.95,
                            "source_text": "Total revenue for Q3 2023 was $1.2 billion",
                            "detail_level": "quarterly",
                            "metadata": {
                                "page_reference": "page 1",
                                "section": "Financial Summary"
                            }
                        },
                        {
                            "kpi_name": "net_income",
                            "value": "250 million",
                            "unit": "$",
                            "period": "Q3 2023",
                            "confidence_score": 0.88,
                            "source_text": "Net income increased to $250 million",
                            "detail_level": "quarterly",
                            "metadata": {
                                "page_reference": "page 2",
                                "section": "Income Statement"
                            }
                        }
                    ],
                    "processing_metadata": {
                        "total_kpis_requested": 3,
                        "kpis_found": 2,
                        "confidence_average": 0.915
                    }
                },
                "created_at": "2023-09-15T13:20:00.000Z"
            },
            {
                "file_id": "file-002",
                "analyze_id": "test-analyze-456",
                "parsed_response": {
                    "kpi_extractions": [
                        {
                            "kpi_name": "revenue",
                            "value": "1.2 billion",
                            "unit": "$",
                            "period": "Q3 2023",
                            "confidence_score": 0.92,
                            "source_text": "Q3 2023 total revenue: $1.2B",
                            "detail_level": "quarterly",
                            "metadata": {
                                "page_reference": "page 1",
                                "section": "Executive Summary"
                            }
                        },
                        {
                            "kpi_name": "eps",
                            "value": "2.15",
                            "unit": "$",
                            "period": "Q3 2023",
                            "confidence_score": 0.85,
                            "source_text": "Earnings per share was $2.15",
                            "detail_level": "quarterly",
                            "metadata": {
                                "page_reference": "page 3",
                                "section": "Per Share Data"
                            }
                        }
                    ],
                    "processing_metadata": {
                        "total_kpis_requested": 3,
                        "kpis_found": 2,
                        "confidence_average": 0.885
                    }
                },
                "created_at": "2023-09-15T13:25:00.000Z"
            }
        ]

    @pytest.fixture
    def sample_analyze_params(self):
        """Sample analyze parameters."""
        return {
            "analyze_id": "test-analyze-456",
            "kpi_list": ["revenue", "net_income", "eps"],
            "kpi_taxonomy": {
                "revenue": {
                    "category": "financial",
                    "priority": "high",
                    "synonyms": ["total revenue", "net sales"]
                },
                "net_income": {
                    "category": "financial",
                    "priority": "high",
                    "synonyms": ["net profit", "earnings"]
                },
                "eps": {
                    "category": "financial",
                    "priority": "medium",
                    "synonyms": ["earnings per share"]
                }
            },
            "bank_id": "test-bank-123",
            "bank_is_french": False,
            "detail_level": "quarterly",
            "total_files": 2,
            "file_categories": ["annual_report", "quarterly_report"]
        }

    def test_parse_sqs_message_valid(self, sample_sqs_event):
        """Test parsing valid SQS messages."""
        messages = parse_sqs_message(sample_sqs_event)
        
        assert len(messages) == 1
        assert messages[0]["message"]["analyze_id"] == "test-analyze-456"
        assert messages[0]["message"]["stage"] == "output_generation"

    @mock_dynamodb
    def test_get_all_kpi_responses_success(self, sample_kpi_responses):
        """Test successful KPI responses retrieval."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_RESPONSES_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Insert test responses
        for response in sample_kpi_responses:
            table.put_item(Item=response)

        # Test retrieval
        responses = get_all_kpi_responses("test-analyze-456")
        
        assert len(responses) == 2
        assert responses[0]["file_id"] == "file-001"
        assert responses[1]["file_id"] == "file-002"

    def test_merge_kpi_extractions(self, sample_kpi_responses):
        """Test merging KPI extractions from multiple files."""
        merged = merge_kpi_extractions(sample_kpi_responses)
        
        assert "revenue" in merged
        assert "net_income" in merged
        assert "eps" in merged
        
        # Revenue should have 2 extractions (from both files)
        assert len(merged["revenue"]) == 2
        
        # Net income should have 1 extraction (from file-001 only)
        assert len(merged["net_income"]) == 1
        
        # EPS should have 1 extraction (from file-002 only)
        assert len(merged["eps"]) == 1
        
        # Check sorting by confidence (highest first)
        assert merged["revenue"][0]["confidence_score"] >= merged["revenue"][1]["confidence_score"]

    def test_resolve_duplicate_kpis(self, sample_kpi_responses):
        """Test resolving duplicate KPIs with confidence scoring."""
        merged = merge_kpi_extractions(sample_kpi_responses)
        resolved = resolve_duplicate_kpis(merged)
        
        assert "revenue" in resolved
        assert "net_income" in resolved
        assert "eps" in resolved
        
        # Revenue should have the highest confidence as primary
        revenue_kpi = resolved["revenue"]
        assert revenue_kpi["confidence_score"] > 0.95  # Should be boosted due to consistency
        assert revenue_kpi["validation_info"]["value_consistency"] is True
        assert revenue_kpi["validation_info"]["cross_file_agreement"] is True
        
        # Net income should have single source
        net_income_kpi = resolved["net_income"]
        assert net_income_kpi["validation_info"]["total_extractions"] == 1
        assert net_income_kpi["validation_info"]["cross_file_agreement"] is False

    @mock_dynamodb
    def test_organize_results_by_file_category(self, sample_kpi_responses, sample_analyze_params):
        """Test organizing results by file category."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_FILE_STATUS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Insert file records with categories
        table.put_item(Item={
            "file_id": "file-001",
            "analyze_id": "test-analyze-456",
            "file_category": "annual_report"
        })
        
        table.put_item(Item={
            "file_id": "file-002",
            "analyze_id": "test-analyze-456",
            "file_category": "quarterly_report"
        })

        # Test organization
        merged = merge_kpi_extractions(sample_kpi_responses)
        resolved = resolve_duplicate_kpis(merged)
        
        results_by_category = organize_results_by_file_category(
            resolved, sample_kpi_responses, sample_analyze_params
        )
        
        assert "annual_report" in results_by_category
        
        # Check statistics
        annual_report_stats = results_by_category["annual_report"]["statistics"]
        assert annual_report_stats["total_kpis"] > 0

    def test_calculate_processing_statistics(self, sample_kpi_responses, sample_analyze_params):
        """Test processing statistics calculation."""
        merged = merge_kpi_extractions(sample_kpi_responses)
        resolved = resolve_duplicate_kpis(merged)
        
        stats = calculate_processing_statistics(
            sample_analyze_params, resolved, sample_kpi_responses
        )
        
        assert "processing_summary" in stats
        assert "confidence_metrics" in stats
        assert "validation_metrics" in stats
        assert "file_processing_details" in stats
        
        # Check summary
        summary = stats["processing_summary"]
        assert summary["total_kpis_requested"] == 3
        assert summary["total_kpis_found"] == 3  # revenue, net_income, eps
        assert summary["total_files_processed"] == 2
        assert summary["coverage_percentage"] == 100.0
        
        # Check confidence metrics
        confidence = stats["confidence_metrics"]
        assert confidence["average_confidence"] > 0
        assert confidence["high_confidence_count"] >= 0
        
        # Check file details
        assert len(stats["file_processing_details"]) == 2

    def test_format_final_output_according_to_api_spec(self, sample_kpi_responses, sample_analyze_params):
        """Test final output formatting according to API specification."""
        merged = merge_kpi_extractions(sample_kpi_responses)
        resolved = resolve_duplicate_kpis(merged)
        
        # Mock organize_results_by_file_category
        results_by_category = {
            "annual_report": {
                "category": "annual_report",
                "kpis": {"revenue": resolved["revenue"], "net_income": resolved["net_income"]},
                "file_ids": ["file-001"],
                "statistics": {"total_kpis": 2, "high_confidence_kpis": 2, "cross_validated_kpis": 0}
            }
        }
        
        processing_stats = calculate_processing_statistics(
            sample_analyze_params, resolved, sample_kpi_responses
        )
        
        final_output = format_final_output_according_to_api_spec(
            sample_analyze_params, results_by_category, processing_stats
        )
        
        assert "analyze_id" in final_output
        assert "bank_id" in final_output
        assert "status" in final_output
        assert final_output["status"] == "complete"
        
        assert "request_parameters" in final_output
        assert "results" in final_output
        assert "processing_statistics" in final_output
        assert "quality_assessment" in final_output
        
        # Check results structure
        results = final_output["results"]
        assert "by_category" in results
        assert "summary" in results
        
        # Check quality assessment
        quality = final_output["quality_assessment"]
        assert "overall_confidence" in quality
        assert "data_completeness" in quality
        assert "quality_score" in quality

    @mock_s3
    def test_store_output_in_s3_success(self, sample_analyze_params):
        """Test successful output storage in S3."""
        # Setup mock S3
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=EnvVars.DOCUMENTS_BUCKET)

        # Test S3 storage
        final_output = {
            "analyze_id": "test-analyze-456",
            "status": "complete",
            "results": {"test": "data"}
        }
        
        s3_path = store_output_in_s3(
            "test-analyze-456",
            "test-bank-123", 
            final_output
        )
        
        assert s3_path is not None
        assert "s3://" in s3_path
        assert "test-bank-123" in s3_path
        assert "test-analyze-456" in s3_path

        # Verify file was stored
        objects = s3.list_objects_v2(Bucket=EnvVars.DOCUMENTS_BUCKET)
        assert "Contents" in objects
        assert len(objects["Contents"]) == 1

    @mock_dynamodb
    def test_store_output_metadata_success(self):
        """Test successful output metadata storage."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_FINAL_OUTPUT_TABLE,
            KeySchema=[{"AttributeName": "analyze_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "analyze_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST"
        )

        # Test metadata storage
        final_output = {
            "quality_assessment": {
                "overall_confidence": 0.9,
                "data_completeness": 95.0,
                "quality_score": 85.5
            },
            "processing_statistics": {
                "processing_summary": {
                    "total_kpis_found": 3
                }
            },
            "results": {
                "summary": {
                    "categories_processed": ["annual_report"]
                }
            }
        }
        
        success = store_output_metadata(
            "test-analyze-456",
            "s3://bucket/path/output.json",
            final_output
        )
        
        assert success is True

        # Verify storage
        response = table.get_item(Key={"analyze_id": "test-analyze-456"})
        assert "Item" in response
        
        metadata = response["Item"]
        assert metadata["status"] == "complete"
        assert metadata["output_path"] == "s3://bucket/path/output.json"
        assert "quality_metrics" in metadata

    @mock_dynamodb
    def test_mark_analyze_as_complete_success(self):
        """Test successful analyze completion marking."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_ANALYZE_STATUS_TABLE,
            KeySchema=[{"AttributeName": "analyze_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "analyze_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST"
        )

        # Insert initial record
        table.put_item(Item={
            "analyze_id": "test-analyze-456",
            "status": "processing",
            "created_at": "2023-09-15T12:00:00.000Z"
        })

        # Test completion marking
        success = mark_analyze_as_complete("test-analyze-456")
        assert success is True

        # Verify update
        response = table.get_item(Key={"analyze_id": "test-analyze-456"})
        assert response["Item"]["status"] == "complete"
        assert "completion_timestamp" in response["Item"]

    @patch('output_generator.AnalyzeStatusChecker.check_analyze_status')
    @patch('output_generator.AnalyzeStatusChecker.get_analyze_parameters') 
    @patch('output_generator.get_all_kpi_responses')
    @patch('output_generator.organize_results_by_file_category')
    @patch('output_generator.store_output_in_s3')
    @patch('output_generator.store_output_metadata')
    @patch('output_generator.mark_analyze_as_complete')
    def test_process_message_success(
        self,
        mock_mark_complete,
        mock_store_metadata,
        mock_store_s3,
        mock_organize_results,
        mock_get_responses,
        mock_get_params,
        mock_check_status,
        sample_kpi_responses,
        sample_analyze_params
    ):
        """Test successful message processing."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_get_responses.return_value = sample_kpi_responses
        mock_get_params.return_value = sample_analyze_params
        mock_organize_results.return_value = {"annual_report": {"kpis": {}, "statistics": {}}}
        mock_store_s3.return_value = "s3://bucket/path/output.json"
        mock_store_metadata.return_value = True
        mock_mark_complete.return_value = True

        # Test message processing
        message_data = {
            "message": {
                "analyze_id": "test-analyze-456"
            }
        }
        
        success = process_message(message_data)
        assert success is True

        # Verify all functions were called
        mock_check_status.assert_called_once()
        mock_get_responses.assert_called_once()
        mock_get_params.assert_called_once()
        mock_store_s3.assert_called_once()
        mock_store_metadata.assert_called_once()
        mock_mark_complete.assert_called_once()

    @patch('output_generator.AnalyzeStatusChecker.check_analyze_status')
    def test_process_message_analyze_failed(self, mock_check_status):
        """Test message processing when analyze has failed."""
        # Setup mock to return failed status
        mock_check_status.return_value = (False, None)

        # Test message processing
        message_data = {
            "message": {
                "analyze_id": "test-analyze-456"
            }
        }
        
        success = process_message(message_data)
        assert success is True  # Should return True to avoid reprocessing

    @patch('output_generator.AnalyzeStatusChecker.check_analyze_status')
    @patch('output_generator.get_all_kpi_responses')
    def test_process_message_no_responses(self, mock_get_responses, mock_check_status):
        """Test message processing when no KPI responses found."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_get_responses.return_value = []  # No responses

        # Test message processing
        message_data = {
            "message": {
                "analyze_id": "test-analyze-456"
            }
        }
        
        success = process_message(message_data)
        assert success is False

    @patch('output_generator.parse_sqs_message')
    @patch('output_generator.process_message')
    def test_handler_success(self, mock_process, mock_parse, sample_sqs_event):
        """Test successful Lambda handler execution."""
        # Setup mocks
        mock_parse.return_value = [
            {
                "message": {
                    "analyze_id": "test-analyze-456"
                }
            }
        ]
        mock_process.return_value = True

        # Test handler
        response = handler(sample_sqs_event, None)
        
        assert response["statusCode"] == 200
        response_body = json.loads(response["body"])
        assert response_body["message"] == "Output generation completed"
        assert len(response_body["results"]) == 1
        assert response_body["results"][0]["success"] is True

    def test_duplicate_resolution_logic(self, sample_kpi_responses):
        """Test duplicate resolution with conflicting values."""
        # Modify second file to have conflicting revenue value
        sample_kpi_responses[1]["parsed_response"]["kpi_extractions"][0]["value"] = "1.3 billion"
        sample_kpi_responses[1]["parsed_response"]["kpi_extractions"][0]["confidence_score"] = 0.85
        
        merged = merge_kpi_extractions(sample_kpi_responses)
        resolved = resolve_duplicate_kpis(merged)
        
        revenue_kpi = resolved["revenue"]
        
        # Should use higher confidence value (1.2 billion from first file)
        assert revenue_kpi["primary_value"] == "1.2 billion"
        
        # Confidence should be reduced due to disagreement
        assert revenue_kpi["confidence_score"] < 0.95
        
        # Should flag as not consistent
        assert revenue_kpi["validation_info"]["value_consistency"] is False
        assert revenue_kpi["validation_info"]["cross_file_agreement"] is False


class TestOutputGeneratorIntegration:
    """Integration tests for the Output Generator."""

    @mock_dynamodb
    @mock_s3
    def test_end_to_end_output_generation(
        self,
        sample_sqs_event,
        sample_kpi_responses,
        sample_analyze_params
    ):
        """Test end-to-end output generation flow."""
        # Setup DynamoDB tables
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        
        # Create analyze status table
        analyze_table = dynamodb.create_table(
            TableName=EnvVars.KPI_ANALYZE_STATUS_TABLE,
            KeySchema=[{"AttributeName": "analyze_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "analyze_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST"
        )

        # Create file status table
        file_table = dynamodb.create_table(
            TableName=EnvVars.KPI_FILE_STATUS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Create KPI responses table
        responses_table = dynamodb.create_table(
            TableName=EnvVars.KPI_RESPONSES_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Create final output table
        output_table = dynamodb.create_table(
            TableName=EnvVars.KPI_FINAL_OUTPUT_TABLE,
            KeySchema=[{"AttributeName": "analyze_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "analyze_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST"
        )

        # Setup S3
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=EnvVars.DOCUMENTS_BUCKET)

        # Insert test data
        analyze_table.put_item(Item=sample_analyze_params)
        
        # Insert file records
        file_table.put_item(Item={
            "file_id": "file-001",
            "analyze_id": "test-analyze-456",
            "file_category": "annual_report"
        })
        
        file_table.put_item(Item={
            "file_id": "file-002",
            "analyze_id": "test-analyze-456",
            "file_category": "quarterly_report"
        })

        # Insert KPI responses
        for response in sample_kpi_responses:
            responses_table.put_item(Item=response)

        # Process the event
        response = handler(sample_sqs_event, None)
        
        # Verify success
        assert response["statusCode"] == 200
        response_body = json.loads(response["body"])
        assert response_body["results"][0]["success"] is True

        # Verify analyze was marked as complete
        analyze_record = analyze_table.get_item(Key={"analyze_id": "test-analyze-456"})["Item"]
        assert analyze_record["status"] == "complete"
        assert "completion_timestamp" in analyze_record

        # Verify output metadata was stored
        output_record = output_table.get_item(Key={"analyze_id": "test-analyze-456"})["Item"]
        assert output_record["status"] == "complete"
        assert "quality_metrics" in output_record

        # Verify S3 file was created
        objects = s3.list_objects_v2(Bucket=EnvVars.DOCUMENTS_BUCKET)
        assert "Contents" in objects
        assert len(objects["Contents"]) == 1


# Test configuration and fixtures
@pytest.fixture(scope="session", autouse=True)
def setup_test_environment():
    """Setup test environment variables."""
    import os
    os.environ.update({
        "KPI_ANALYZE_STATUS_TABLE": "test-kpi-analyze-status",
        "KPI_FILE_STATUS_TABLE": "test-kpi-file-status",
        "KPI_RESPONSES_TABLE": "test-kpi-responses",
        "KPI_FINAL_OUTPUT_TABLE": "test-kpi-final-output",
        "DOCUMENTS_BUCKET": "test-documents-bucket",
        "LOG_LEVEL": "INFO"
    })


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v", "--tb=short"])