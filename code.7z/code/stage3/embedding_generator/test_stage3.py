import json
import pytest
import boto3
from moto import mock_dynamodb, mock_sqs, mock_bedrock
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime, timezone

# Import the module to test
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from stage3.embedding_generator.lambda_function import (
    parse_sqs_message,
    update_file_status,
    get_chunks_for_file,
    create_embeddings_for_texts,
    update_chunks_with_embeddings,
    notify_retrieval_queue,
    process_message,
    handler
)

from common.config.env_vars import EnvironmentVariables as EnvVars
from common.utils.analyze_status_checker import AnalyzeStatusChecker


class TestEmbeddingGenerator:
    """Test suite for the Embedding Generator Lambda function."""

    @pytest.fixture
    def sample_sqs_event(self):
        """Sample SQS event for testing."""
        return {
            "Records": [
                {
                    "messageId": "test-message-id",
                    "receiptHandle": "test-receipt-handle",
                    "body": json.dumps({
                        "file_id": "test-file-123",
                        "analyze_id": "test-analyze-456",
                        "stage": "embedding",
                        "timestamp": "2023-09-15T13:10:00.000Z"
                    }),
                    "attributes": {
                        "ApproximateReceiveCount": "1",
                        "SentTimestamp": "1545082650183"
                    },
                    "eventSource": "aws:sqs",
                    "eventSourceARN": "arn:aws:sqs:us-east-1:123456789012:test-queue",
                    "awsRegion": "us-east-1"
                }
            ]
        }

    @pytest.fixture
    def sample_chunks(self):
        """Sample chunks data for testing."""
        return [
            {
                "chunk_id": "chunk-001",
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456",
                "text": "Total revenue for Q3 2023 was $1.2 billion",
                "text_to_embed": "Financial Results: Total revenue for Q3 2023 was $1.2 billion",
                "page_info": {"page": 1, "section": "Financial Summary"},
                "headings": ["Financial Results", "Revenue"],
                "created_at": "2023-09-15T12:00:00.000Z"
            },
            {
                "chunk_id": "chunk-002",
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456",
                "text": "Net income increased by 15% compared to previous quarter",
                "text_to_embed": "Financial Results: Net income increased by 15% compared to previous quarter",
                "page_info": {"page": 1, "section": "Financial Summary"},
                "headings": ["Financial Results", "Net Income"],
                "created_at": "2023-09-15T12:00:00.000Z"
            }
        ]

    @pytest.fixture
    def sample_embeddings(self):
        """Sample embedding vectors for testing."""
        return [
            [0.1, 0.2, 0.3, 0.4, 0.5] * 307,  # 1535 dimensions (titan-embed-text-v1)
            [0.5, 0.4, 0.3, 0.2, 0.1] * 307
        ]

    def test_parse_sqs_message_valid(self, sample_sqs_event):
        """Test parsing valid SQS messages."""
        messages = parse_sqs_message(sample_sqs_event)
        
        assert len(messages) == 1
        assert messages[0]["message"]["file_id"] == "test-file-123"
        assert messages[0]["message"]["analyze_id"] == "test-analyze-456"
        assert messages[0]["receipt_handle"] == "test-receipt-handle"

    def test_parse_sqs_message_invalid_json(self):
        """Test parsing SQS message with invalid JSON."""
        invalid_event = {
            "Records": [
                {
                    "messageId": "test-message-id",
                    "receiptHandle": "test-receipt-handle",
                    "body": "invalid json",
                    "eventSource": "aws:sqs"
                }
            ]
        }
        
        messages = parse_sqs_message(invalid_event)
        assert len(messages) == 0

    def test_parse_sqs_message_non_sqs_source(self):
        """Test parsing message from non-SQS source."""
        non_sqs_event = {
            "Records": [
                {
                    "messageId": "test-message-id",
                    "body": json.dumps({"file_id": "test"}),
                    "eventSource": "aws:s3"
                }
            ]
        }
        
        messages = parse_sqs_message(non_sqs_event)
        assert len(messages) == 0

    @mock_dynamodb
    def test_update_file_status_success(self):
        """Test successful file status update."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_FILE_STATUS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Insert initial record
        table.put_item(Item={
            "file_id": "test-file-123",
            "analyze_id": "test-analyze-456",
            "status": "docling_complete",
            "created_at": "2023-09-15T12:00:00.000Z"
        })

        # Test update
        success = update_chunks_with_embeddings(
            sample_chunks, 
            wrong_embeddings, 
            "amazon.titan-embed-text-v1"
        )
        
        assert success is False

    @mock_sqs
    def test_notify_retrieval_queue_success(self):
        """Test successful notification to retrieval queue."""
        # Setup mock SQS
        sqs = boto3.client("sqs", region_name="us-east-1")
        queue_url = sqs.create_queue(QueueName=EnvVars.RETRIEVAL_QUEUE_NAME)["QueueUrl"]

        # Test notification
        message = {
            "file_id": "test-file-123",
            "analyze_id": "test-analyze-456"
        }
        
        success = notify_retrieval_queue(message, 5)
        assert success is True

    @mock_sqs
    def test_notify_retrieval_queue_queue_not_found(self):
        """Test notification when queue doesn't exist."""
        message = {
            "file_id": "test-file-123",
            "analyze_id": "test-analyze-456"
        }
        
        success = notify_retrieval_queue(message, 5)
        assert success is False

    @patch('embedding_generator.AnalyzeStatusChecker.check_analyze_status')
    @patch('embedding_generator.update_file_status')
    @patch('embedding_generator.get_chunks_for_file')
    @patch('embedding_generator.create_embeddings_for_texts')
    @patch('embedding_generator.update_chunks_with_embeddings')
    @patch('embedding_generator.notify_retrieval_queue')
    def test_process_message_success(
        self, 
        mock_notify, 
        mock_update_chunks, 
        mock_create_embeddings, 
        mock_get_chunks, 
        mock_update_status,
        mock_check_status,
        sample_chunks,
        sample_embeddings
    ):
        """Test successful message processing."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_update_status.return_value = True
        mock_get_chunks.return_value = sample_chunks
        mock_create_embeddings.return_value = sample_embeddings
        mock_update_chunks.return_value = True
        mock_notify.return_value = True

        # Test message processing
        message_data = {
            "message": {
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456"
            }
        }
        
        success = process_message(message_data)
        assert success is True

        # Verify all functions were called
        mock_check_status.assert_called_once()
        mock_update_status.assert_called()
        mock_get_chunks.assert_called_once()
        mock_create_embeddings.assert_called_once()
        mock_update_chunks.assert_called_once()
        mock_notify.assert_called_once()

    @patch('embedding_generator.AnalyzeStatusChecker.check_analyze_status')
    def test_process_message_analyze_failed(self, mock_check_status):
        """Test message processing when analyze has failed."""
        # Setup mock to return failed status
        mock_check_status.return_value = (False, None)

        # Test message processing
        message_data = {
            "message": {
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456"
            }
        }
        
        success = process_message(message_data)
        assert success is True  # Should return True to avoid reprocessing

    @patch('embedding_generator.AnalyzeStatusChecker.check_analyze_status')
    @patch('embedding_generator.update_file_status')
    @patch('embedding_generator.get_chunks_for_file')
    def test_process_message_no_chunks(
        self, 
        mock_get_chunks, 
        mock_update_status,
        mock_check_status
    ):
        """Test message processing when no chunks are found."""
        # Setup mocks
        mock_check_status.return_value = (True, {"bank_is_french": False})
        mock_update_status.return_value = True
        mock_get_chunks.return_value = []  # No chunks

        # Test message processing
        message_data = {
            "message": {
                "file_id": "test-file-123",
                "analyze_id": "test-analyze-456"
            }
        }
        
        success = process_message(message_data)
        assert success is False

    def test_process_message_missing_fields(self):
        """Test message processing with missing required fields."""
        # Test with missing file_id
        message_data = {
            "message": {
                "analyze_id": "test-analyze-456"
            }
        }
        
        success = process_message(message_data)
        assert success is False

        # Test with missing analyze_id
        message_data = {
            "message": {
                "file_id": "test-file-123"
            }
        }
        
        success = process_message(message_data)
        assert success is False

    @patch('embedding_generator.parse_sqs_message')
    @patch('embedding_generator.process_message')
    def test_handler_success(self, mock_process, mock_parse, sample_sqs_event):
        """Test successful Lambda handler execution."""
        # Setup mocks
        mock_parse.return_value = [
            {
                "message": {
                    "file_id": "test-file-123",
                    "analyze_id": "test-analyze-456"
                }
            }
        ]
        mock_process.return_value = True

        # Test handler
        response = handler(sample_sqs_event, None)
        
        assert response["statusCode"] == 200
        response_body = json.loads(response["body"])
        assert response_body["message"] == "Embedding processing completed"
        assert len(response_body["results"]) == 1
        assert response_body["results"][0]["success"] is True

    @patch('embedding_generator.parse_sqs_message')
    def test_handler_no_messages(self, mock_parse, sample_sqs_event):
        """Test handler with no valid messages."""
        # Setup mock to return no messages
        mock_parse.return_value = []

        # Test handler
        response = handler(sample_sqs_event, None)
        
        assert response["statusCode"] == 200
        response_body = json.loads(response["body"])
        assert response_body["message"] == "No valid messages found"

    def test_french_bank_model_selection(self):
        """Test that French banks use the correct embedding model."""
        # Test French bank
        french_model = EnvVars.get_embedding_model(bank_is_french=True)
        assert french_model == EnvVars.BEDROCK_EMBEDDING_MODEL_FR

        # Test non-French bank
        english_model = EnvVars.get_embedding_model(bank_is_french=False)
        assert english_model == EnvVars.BEDROCK_EMBEDDING_MODEL_EN


class TestEmbeddingGeneratorIntegration:
    """Integration tests for the Embedding Generator."""

    @mock_dynamodb
    @mock_sqs
    @patch('boto3.client')
    def test_end_to_end_embedding_processing(
        self, 
        mock_boto_client,
        sample_sqs_event,
        sample_chunks,
        sample_embeddings
    ):
        """Test end-to-end embedding processing flow."""
        # Setup DynamoDB tables
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        
        # Create analyze status table
        analyze_table = dynamodb.create_table(
            TableName=EnvVars.KPI_ANALYZE_STATUS_TABLE,
            KeySchema=[{"AttributeName": "analyze_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "analyze_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST"
        )
        
        # Create file status table
        file_table = dynamodb.create_table(
            TableName=EnvVars.KPI_FILE_STATUS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "analyze_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "analyze_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )
        
        # Create chunks table
        chunks_table = dynamodb.create_table(
            TableName=EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "chunk_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "chunk_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Setup SQS
        sqs = boto3.client("sqs", region_name="us-east-1")
        sqs.create_queue(QueueName=EnvVars.RETRIEVAL_QUEUE_NAME)

        # Insert test data
        analyze_table.put_item(Item={
            "analyze_id": "test-analyze-456",
            "status": "processing",
            "bank_is_french": False,
            "total_files": 1
        })
        
        file_table.put_item(Item={
            "file_id": "test-file-123",
            "analyze_id": "test-analyze-456",
            "status": "docling_complete"
        })
        
        for chunk in sample_chunks:
            chunks_table.put_item(Item=chunk)

        # Mock Bedrock client
        mock_bedrock = Mock()
        mock_boto_client.return_value = mock_bedrock
        
        mock_responses = []
        for embedding in sample_embeddings:
            mock_response = Mock()
            mock_response.get.return_value.read.return_value = json.dumps({
                "embedding": embedding
            }).encode()
            mock_responses.append(mock_response)
        
        mock_bedrock.invoke_model.side_effect = mock_responses

        # Process the event
        response = handler(sample_sqs_event, None)
        
        # Verify success
        assert response["statusCode"] == 200
        response_body = json.loads(response["body"])
        assert response_body["results"][0]["success"] is True

        # Verify chunks were updated with embeddings
        updated_chunk = chunks_table.get_item(Key={
            "file_id": "test-file-123",
            "chunk_id": "chunk-001"
        })["Item"]
        
        assert "embedding" in updated_chunk
        assert "embedding_model" in updated_chunk
        assert "embedding_timestamp" in updated_chunk

        # Verify file status was updated
        updated_file = file_table.get_item(Key={
            "file_id": "test-file-123",
            "analyze_id": "test-analyze-456"
        })["Item"]
        
        assert updated_file["status"] == "embedding_complete"


# Test configuration and fixtures
@pytest.fixture(scope="session", autouse=True)
def setup_test_environment():
    """Setup test environment variables."""
    import os
    os.environ.update({
        "KPI_ANALYZE_STATUS_TABLE": "test-kpi-analyze-status",
        "KPI_FILE_STATUS_TABLE": "test-kpi-file-status", 
        "KPI_DOCUMENT_CHUNKS_TABLE": "test-kpi-document-chunks",
        "RETRIEVAL_QUEUE_NAME": "test-retrieval-queue",
        "BEDROCK_REGION": "us-east-1",
        "BEDROCK_EMBEDDING_MODEL_EN": "amazon.titan-embed-text-v1",
        "BEDROCK_EMBEDDING_MODEL_FR": "amazon.titan-embed-text-v2",
        "MAX_EMBEDDING_BATCH_SIZE": "20",
        "LOG_LEVEL": "INFO"
    })


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v", "--tb=short"])
    file_status(
                "test-file-123",
                "test-analyze-456",
                "embedding_processing",
                {"embedding_model": "amazon.titan-embed-text-v1"}
            )

        assert success is True

        # Verify update
        response = table.get_item(Key={
            "file_id": "test-file-123",
            "analyze_id": "test-analyze-456"
        })
        
        assert response["Item"]["status"] == "embedding_processing"
        assert "embedding_model" in response["Item"]

    @mock_dynamodb
    def test_get_chunks_for_file_success(self, sample_chunks):
        """Test successful chunk retrieval."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "chunk_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "chunk_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Insert test chunks
        for chunk in sample_chunks:
            table.put_item(Item=chunk)

        # Test retrieval
        chunks = get_chunks_for_file("test-file-123")
        
        assert len(chunks) == 2
        assert chunks[0]["chunk_id"] == "chunk-001"
        assert chunks[1]["chunk_id"] == "chunk-002"

    @mock_dynamodb
    def test_get_chunks_for_file_empty(self):
        """Test chunk retrieval with no chunks."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        dynamodb.create_table(
            TableName=EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "chunk_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "chunk_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Test retrieval from empty table
        chunks = get_chunks_for_file("nonexistent-file")
        assert len(chunks) == 0

    @patch('boto3.client')
    def test_create_embeddings_for_texts_success(self, mock_boto_client, sample_embeddings):
        """Test successful embedding creation."""
        # Mock Bedrock client
        mock_bedrock = Mock()
        mock_boto_client.return_value = mock_bedrock
        
        # Mock successful responses
        mock_responses = []
        for embedding in sample_embeddings:
            mock_response = Mock()
            mock_response.get.return_value.read.return_value = json.dumps({
                "embedding": embedding
            }).encode()
            mock_responses.append(mock_response)
        
        mock_bedrock.invoke_model.side_effect = mock_responses

        # Test embedding creation
        texts = ["Test text 1", "Test text 2"]
        embeddings = create_embeddings_for_texts(texts, "amazon.titan-embed-text-v1")
        
        assert embeddings is not None
        assert len(embeddings) == 2
        assert len(embeddings[0]) == len(sample_embeddings[0])

    @patch('boto3.client')
    def test_create_embeddings_for_texts_failure(self, mock_boto_client):
        """Test embedding creation failure."""
        # Mock Bedrock client that raises an exception
        mock_bedrock = Mock()
        mock_boto_client.return_value = mock_bedrock
        mock_bedrock.invoke_model.side_effect = Exception("Bedrock API error")

        # Test embedding creation failure
        texts = ["Test text 1"]
        embeddings = create_embeddings_for_texts(texts, "amazon.titan-embed-text-v1")
        
        assert embeddings is None

    @mock_dynamodb
    def test_update_chunks_with_embeddings_success(self, sample_chunks, sample_embeddings):
        """Test successful chunk update with embeddings."""
        # Setup mock DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName=EnvVars.KPI_DOCUMENT_CHUNKS_TABLE,
            KeySchema=[
                {"AttributeName": "file_id", "KeyType": "HASH"},
                {"AttributeName": "chunk_id", "KeyType": "RANGE"}
            ],
            AttributeDefinitions=[
                {"AttributeName": "file_id", "AttributeType": "S"},
                {"AttributeName": "chunk_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST"
        )

        # Test update
        success = update_chunks_with_embeddings(
            sample_chunks, 
            sample_embeddings, 
            "amazon.titan-embed-text-v1"
        )
        
        assert success is True

    def test_update_chunks_with_embeddings_mismatch(self, sample_chunks):
        """Test chunk update with mismatched embedding count."""
        wrong_embeddings = [[0.1, 0.2]]  # Only one embedding for two chunks
        
        success = update_chunks_with_embeddings(
            sample_chunks, 
            wrong_embeddings, 
            "amazon.titan-embed-text-v1"
        )
        assert success is False  # Should return False due to mismatch
