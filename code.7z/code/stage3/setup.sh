#!/bin/bash
# Embedding Module Setup Commands
# This script contains AWS CLI commands to create the necessary Embedding resources
# Make sure to have AWS CLI installed and configured before running these commands

# Set variables
STACK_NAME="benchmark"
REGION="eu-west-3"
ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)
BUCKET_NAME="tmp-storage-benchmark"

echo "Creating Embedding Resources for $STACK_NAME..."

# SQS Queues

# Embedding Queue
EMBEDDING_QUEUE_URL=$(aws sqs create-queue \
  --queue-name "$STACK_NAME-embedding-queue" \
  --attributes '{
    "VisibilityTimeout": "900",
    "MessageRetentionPeriod": "1209600"
  }' \
  --query "QueueUrl" \
  --output text)

echo "Created Embedding Queue: $EMBEDDING_QUEUE_URL"

# Embedding Dead Letter Queue
EMBEDDING_DLQ_URL=$(aws sqs create-queue \
  --queue-name "$STACK_NAME-embedding-dlq" \
  --attributes '{
    "MessageRetentionPeriod": "1209600"
  }' \
  --query "QueueUrl" \
  --output text)

echo "Created Embedding DLQ: $EMBEDDING_DLQ_URL"

# Retriever Queue
RETRIEVER_QUEUE_URL=$(aws sqs create-queue \
  --queue-name "$STACK_NAME-retriever-queue" \
  --attributes '{
    "VisibilityTimeout": "600",
    "MessageRetentionPeriod": "1209600"
  }' \
  --query "QueueUrl" \
  --output text)

echo "Created Retriever Queue: $RETRIEVER_QUEUE_URL"

# Retriever Dead Letter Queue
RETRIEVER_DLQ_URL=$(aws sqs create-queue \
  --queue-name "$STACK_NAME-retriever-dlq" \
  --attributes '{
    "MessageRetentionPeriod": "1209600"
  }' \
  --query "QueueUrl" \
  --output text)

echo "Created Retriever DLQ: $RETRIEVER_DLQ_URL"

# Get queue ARNs
EMBEDDING_QUEUE_ARN=$(aws sqs get-queue-attributes \
  --queue-url $EMBEDDING_QUEUE_URL \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text)

EMBEDDING_DLQ_ARN=$(aws sqs get-queue-attributes \
  --queue-url $EMBEDDING_DLQ_URL \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text)

RETRIEVER_QUEUE_ARN=$(aws sqs get-queue-attributes \
  --queue-url $RETRIEVER_QUEUE_URL \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text)

RETRIEVER_DLQ_ARN=$(aws sqs get-queue-attributes \
  --queue-url $RETRIEVER_DLQ_URL \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text)

# Set redrive policy on main queues
aws sqs set-queue-attributes \
  --queue-url $EMBEDDING_QUEUE_URL \
  --attributes "{
    RedrivePolicy: {deadLetterTargetArn:$EMBEDDING_DLQ_ARN,maxReceiveCount:5}
  }"

aws sqs set-queue-attributes \
  --queue-url $RETRIEVER_QUEUE_URL \
  --attributes "{
    RedrivePolicy: {deadLetterTargetArn:$RETRIEVER_DLQ_ARN,maxReceiveCount:5}
  }"

echo "Set redrive policies for Embedding and Retriever Queues"

# Create IAM Role for Lambda functions
LAMBDA_ROLE_NAME="$STACK_NAME-embedding-role"
LAMBDA_ROLE_ARN=$(aws iam create-role \
  --role-name $LAMBDA_ROLE_NAME \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Principal": {"Service": "lambda.amazonaws.com"},
      "Action": "sts:AssumeRole"
    }]
  }' \
  --query "Role.Arn" \
  --output text)

# Attach policies to the Lambda role
aws iam attach-role-policy \
  --role-name $LAMBDA_ROLE_NAME \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

aws iam attach-role-policy \
  --role-name $LAMBDA_ROLE_NAME \
  --policy-arn arn:aws:iam::aws:policy/AmazonS3FullAccess

aws iam attach-role-policy \
  --role-name $LAMBDA_ROLE_NAME \
  --policy-arn arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess

aws iam attach-role-policy \
  --role-name $LAMBDA_ROLE_NAME \
  --policy-arn arn:aws:iam::aws:policy/AmazonSQSFullAccess

# Create Bedrock access policy
aws iam create-policy \
  --policy-name "$STACK_NAME-bedrock-policy" \
  --policy-document '{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Action": [
          "bedrock:InvokeModel",
          "bedrock:InvokeModelWithResponseStream"
        ],
        "Resource": "*"
      }
    ]
  }'

# Attach Bedrock policy to role
aws iam attach-role-policy \
  --role-name $LAMBDA_ROLE_NAME \
  --policy-arn arn:aws:iam::$ACCOUNT_ID:policy/$STACK_NAME-bedrock-policy

echo "Created IAM Role for Lambda functions: $LAMBDA_ROLE_ARN"

# Wait for role propagation
echo "Waiting for IAM role propagation..."
sleep 10

# Create Embedding Generator Lambda
KEY_NAME="embedding_generator.zip"
EMBEDDING_FUNCTION_ARN=$(aws lambda create-function \
  --function-name "$STACK_NAME-embedding-generator" \
  --runtime python3.9 \
  --role $LAMBDA_ROLE_ARN \
  --handler embedding_generator.handler \
  --code S3Bucket=$BUCKET_NAME,S3Key=$KEY_NAME \
  --environment "Variables={
    AWS_LAMBDA_FUNCTION_NAME=embedding_generator,
    DOCUMENTS_BUCKET=$STACK_NAME-documents,
    DOCUMENTS_TABLE=$STACK_NAME-documents,
    JOBS_TABLE=$STACK_NAME-jobs,
    EMBEDDING_QUEUE=$STACK_NAME-embedding-queue,
    RETRIEVER_QUEUE=$STACK_NAME-retriever-queue,
    BEDROCK_REGION=$REGION,
    BEDROCK_EMBEDDING_MODEL=amazon.titan-embed-text-v1,
    BEDROCK_LLM_MODEL=anthropic.claude-3-5-sonnet-20241022-v2:0,
    MAX_EMBEDDING_BATCH_SIZE=20,
    LOG_LEVEL=INFO
  }" \
  --timeout 900 \
  --memory-size 2048 \
  --query "FunctionArn" \
  --output text)

echo "Created Embedding Generator Lambda function: $EMBEDDING_FUNCTION_ARN"

# Configure SQS trigger for Embedding Generator Lambda
aws lambda create-event-source-mapping \
  --function-name "$STACK_NAME-embedding-generator" \
  --event-source-arn $EMBEDDING_QUEUE_ARN \
  --batch-size 1 \
  --maximum-batching-window-in-seconds 10

echo "Configured SQS trigger for Embedding Generator Lambda"

# Create DynamoDB Tables if they don't exist already

# Check if Documents table exists
DOCS_TABLE_EXISTS=$(aws dynamodb describe-table --table-name $STACK_NAME-documents 2>/dev/null || echo "not_exists")

if [[ $DOCS_TABLE_EXISTS == "not_exists" ]]; then
  # Create Documents table
  aws dynamodb create-table \
    --table-name $STACK_NAME-documents \
    --attribute-definitions \
      AttributeName=document_id,AttributeType=S \
    --key-schema \
      AttributeName=document_id,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --stream-specification StreamEnabled=true,StreamViewType=NEW_AND_OLD_IMAGES
  
  echo "Created DynamoDB table: $STACK_NAME-documents"
else
  echo "DynamoDB table already exists: $STACK_NAME-documents"
fi

# Check if Jobs table exists
JOBS_TABLE_EXISTS=$(aws dynamodb describe-table --table-name $STACK_NAME-jobs 2>/dev/null || echo "not_exists")

if [[ $JOBS_TABLE_EXISTS == "not_exists" ]]; then
  # Create Jobs table
  aws dynamodb create-table \
    --table-name $STACK_NAME-jobs \
    --attribute-definitions \
      AttributeName=job_id,AttributeType=S \
    --key-schema \
      AttributeName=job_id,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --stream-specification StreamEnabled=true,StreamViewType=NEW_AND_OLD_IMAGES
  
  echo "Created DynamoDB table: $STACK_NAME-jobs"
else
  echo "DynamoDB table already exists: $STACK_NAME-jobs"
fi

echo "Embedding Module setup complete!"
echo "Embedding Queue: $EMBEDDING_QUEUE_URL"
echo "Retriever Queue: $RETRIEVER_QUEUE_URL"
echo "Embedding Generator Lambda: $EMBEDDING_FUNCTION_ARN"
echo "DynamoDB Documents Table: $STACK_NAME-documents"
echo "DynamoDB Jobs Table: $STACK_NAME-jobs"

echo "All resources created successfully!"
